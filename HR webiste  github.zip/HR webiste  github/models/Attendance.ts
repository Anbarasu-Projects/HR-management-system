import mongoose from "mongoose";
import { IAttendance, AttendanceStatus } from "@/types";

const attendanceSessionSchema = new mongoose.Schema(
  {
    checkIn: { type: Date, required: true },
    checkOut: { type: Date, default: null },
    hoursWorked: { type: Number, default: 0 },
    workingMinutes: { type: Number, default: 0 },
    notes: { type: String, default: "", trim: true },
    location: {
      lat: { type: Number, default: null },
      lng: { type: Number, default: null },
    },
  },
  { _id: false }
);

const attendanceSchema = new mongoose.Schema<IAttendance>(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: [true, "User ID is required"],
    },
    date: {
      type: String,
      required: [true, "Date is required"],
    },
    // Daily summary fields. checkIn is the first check-in of the day;
    // checkOut is the most recent checkout, or null while a session is active.
    checkIn: { type: Date, default: null, required: false },
    checkOut: { type: Date, default: null },
    status: {
      type: String,
      enum: ["present", "absent", "late", "half-day", "on-leave"] as AttendanceStatus[],
      default: "present",
    },
    hoursWorked: { type: Number, default: 0 },
    workingMinutes: { type: Number, default: 0 },
    // Multiple work sessions are stored inside the same daily record. This
    // preserves one attendance/payroll day while allowing lunch/off-site breaks.
    sessions: { type: [attendanceSessionSchema], default: [] },
    notes: { type: String, default: "", trim: true },
    location: {
      lat: { type: Number, default: null },
      lng: { type: Number, default: null },
    },
    overriddenBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    overriddenAt: { type: Date, default: null },
    outOfOffice: { type: Boolean, default: false },
  },
  { timestamps: true }
);

// Keep exactly one DAILY attendance record per user. Individual check-in/out
// periods live in sessions[], so reports and payroll still count the day once.
attendanceSchema.index({ userId: 1, date: 1 }, { unique: true });
attendanceSchema.index({ date: 1 });
attendanceSchema.index({ userId: 1 });
attendanceSchema.index({ status: 1 });

const Attendance =
  mongoose.models.Attendance ||
  mongoose.model<IAttendance>("Attendance", attendanceSchema);

export default Attendance;
