import mongoose from "mongoose";
import { INotification } from "@/types";

const notificationSchema = new mongoose.Schema<INotification>(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: [true, "User ID is required"],
      index: true,
    },
    title: {
      type: String,
      required: [true, "Title is required"],
      trim: true,
    },
    message: {
      type: String,
      required: [true, "Message is required"],
      trim: true,
    },
    type: {
      type: String,
      enum: ["info", "success", "warning", "error"],
      default: "info",
    },
    isRead: {
      type: Boolean,
      default: false,
    },
    link: {
      type: String,
      default: null,
    },
    dedupeKey: {
      type: String,
      required: false,
    },
  },
  {
    timestamps: true,
  }
);

// Index for user + unread queries
notificationSchema.index({ userId: 1, isRead: 1 });

// Index for createdAt (for sorting)
notificationSchema.index({ createdAt: -1 });

// Prevent duplicate one-off reminders such as birthday alerts.
notificationSchema.index({ userId: 1, dedupeKey: 1 }, { unique: true, sparse: true });

const Notification =
  mongoose.models.Notification ||
  mongoose.model<INotification>("Notification", notificationSchema);

export default Notification;
