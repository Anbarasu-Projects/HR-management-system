"use client";

import { useEffect, useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import { LogOut, ChevronRight } from "lucide-react";
import { NotificationBell } from "./notification-bell";
import { cn } from "@/lib/utils";
import { clearCurrentUserCache, getCurrentUser } from "@/lib/client-user";

interface UserData {
  name: string;
  email: string;
  role: string;
}

function titleCase(segment: string) {
  return segment.charAt(0).toUpperCase() + segment.slice(1).replace(/-/g, " ");
}

export function Header() {
  const pathname = usePathname();
  const router = useRouter();
  const [user, setUser] = useState<UserData | null>(null);
  const [now, setNow] = useState<Date | null>(null);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const data = await getCurrentUser(true);
        if (data) setUser(data);
      } catch (error) {
        console.error("Failed to fetch user", error);
      }
    };
    fetchUser();
  }, []);

  // Rendered client-side only, so the server/client clock can't mismatch.
  useEffect(() => {
    setNow(new Date());
    const id = setInterval(() => setNow(new Date()), 30_000);
    return () => clearInterval(id);
  }, []);

  const handleLogout = async () => {
    try {
      await fetch("/api/auth/logout", { method: "POST" });
      clearCurrentUserCache();
      router.replace("/login");
      router.refresh();
    } catch (error) {
      console.error("Logout failed", error);
    }
  };

  // Build a breadcrumb: "Admin / Leave Requests"
  const segments = pathname.split("/").filter(Boolean);
  const root = segments[0] ? titleCase(segments[0]) : "Dashboard";
  const leaf = segments.length > 1 ? titleCase(segments[segments.length - 1]) : null;

  const initials =
    user?.name
      ?.split(" ")
      .map((n) => n[0])
      .slice(0, 2)
      .join("")
      .toUpperCase() || "U";

  return (
    <header
      className={cn(
        "sticky top-0 z-30 flex h-16 items-center justify-between gap-3 px-4 sm:px-6",
        "border-b border-white/[0.07]",
        "bg-[rgba(10,12,26,0.72)] backdrop-blur-2xl"
      )}
    >
      {/* Breadcrumb */}
      <div className="ml-12 flex min-w-0 items-center gap-2 lg:ml-0">
        <span className="hidden text-sm font-medium text-[var(--neu-text-muted)] sm:inline">
          {root}
        </span>
        {leaf && (
          <ChevronRight size={14} className="hidden shrink-0 text-[var(--neu-text-muted)] sm:inline" />
        )}
        <h1 className="truncate text-base font-bold tracking-tight text-[var(--neu-text)] sm:text-lg">
          {leaf ?? "Dashboard"}
        </h1>
      </div>

      <div className="flex shrink-0 items-center gap-2 sm:gap-3">
        {/* Live date — quiet context, hidden on small screens */}
        {now && (
          <span className="hidden rounded-lg border border-white/[0.08] bg-white/[0.04] px-3 py-1.5 text-xs font-medium text-[var(--neu-text-secondary)] xl:inline">
            {now.toLocaleDateString(undefined, {
              weekday: "short",
              day: "numeric",
              month: "short",
            })}
          </span>
        )}

        <NotificationBell />

        <div className="mx-1 hidden h-7 w-px bg-white/[0.09] sm:block" />

        {/* Identity */}
        <div className="flex items-center gap-2.5">
          <div
            className={cn(
              "flex h-9 w-9 shrink-0 items-center justify-center rounded-full",
              "bg-[linear-gradient(135deg,var(--accent-1),var(--accent-2))]",
              "text-xs font-bold text-white",
              "shadow-[0_4px_14px_-4px_var(--neu-accent-glow)]",
              "ring-2 ring-white/10"
            )}
          >
            {initials}
          </div>

          <div className="hidden min-w-0 md:block">
            <p className="truncate text-sm font-semibold leading-tight text-[var(--neu-text)]">
              {user?.name || "Loading…"}
            </p>
            <p className="truncate text-[0.68rem] font-semibold uppercase tracking-[0.1em] text-[var(--neu-accent)]">
              {user?.role || ""}
            </p>
          </div>
        </div>

        <button
          onClick={handleLogout}
          title="Log out"
          aria-label="Log out"
          className={cn(
            "flex h-9 w-9 items-center justify-center rounded-lg",
            "text-[var(--neu-text-secondary)] transition-all",
            "hover:bg-[rgba(255,107,129,0.14)] hover:text-[var(--neu-danger)]"
          )}
        >
          <LogOut size={17} />
        </button>
      </div>
    </header>
  );
}
