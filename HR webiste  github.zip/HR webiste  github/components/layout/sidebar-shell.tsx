"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { cn } from "@/lib/utils";
import { Menu, X, ChevronLeft, ChevronRight, type LucideIcon } from "lucide-react";

export interface NavItem {
  name: string;
  href: string;
  icon: LucideIcon;
}

export interface NavGroup {
  /** Section heading. Hidden when the sidebar is collapsed. */
  label: string;
  items: NavItem[];
}

interface SidebarShellProps {
  /** Drives the accent ramp and the subtitle under the wordmark. */
  portal: "admin" | "employee";
  homeHref: string;
  groups: NavGroup[];
  isCollapsed: boolean;
  setIsCollapsed: (value: boolean) => void;
}

const portalCopy = {
  admin: { title: "AttendEase", subtitle: "Admin Console" },
  employee: { title: "AttendEase", subtitle: "My Workspace" },
} as const;

export function SidebarShell({
  portal,
  homeHref,
  groups,
  isCollapsed,
  setIsCollapsed,
}: SidebarShellProps) {
  const pathname = usePathname();
  const [isOpen, setIsOpen] = useState(false);
  const copy = portalCopy[portal];

  const isItemActive = (href: string) =>
    pathname === href || (href !== homeHref && pathname.startsWith(`${href}/`));

  return (
    <>
      {/* Mobile trigger */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        aria-label={isOpen ? "Close navigation" : "Open navigation"}
        className={cn(
          "fixed left-4 top-3.5 z-50 flex h-10 w-10 items-center justify-center rounded-xl lg:hidden",
          "glass gradient-border text-[var(--neu-text)]"
        )}
      >
        {isOpen ? <X size={20} /> : <Menu size={20} />}
      </button>

      {/* Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm lg:hidden"
          onClick={() => setIsOpen(false)}
        />
      )}

      <aside
        data-portal={portal}
        className={cn(
          "fixed left-0 top-0 z-40 flex h-screen flex-col",
          "border-r border-white/[0.08]",
          "bg-[linear-gradient(180deg,rgba(16,19,36,0.94),rgba(8,10,22,0.96))]",
          "backdrop-blur-2xl",
          "transition-[width,transform] duration-300 ease-out",
          isCollapsed ? "w-20" : "w-64",
          isOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        )}
      >
        {/* Accent edge — the clearest signal of which portal you're in */}
        <div
          aria-hidden
          className="pointer-events-none absolute right-0 top-0 h-full w-px bg-[linear-gradient(180deg,transparent,rgba(var(--accent-rgb),0.6),transparent)]"
        />
        <div
          aria-hidden
          className="pointer-events-none absolute -left-16 top-0 h-56 w-56 rounded-full bg-[var(--accent-1)] opacity-[0.18] blur-3xl"
        />

        {/* Brand */}
        <div
          className={cn(
            "relative flex h-20 shrink-0 items-center border-b border-white/[0.07] px-4",
            isCollapsed ? "justify-center" : "gap-3"
          )}
        >
          <Link href={homeHref} className="flex items-center gap-3 overflow-hidden">
            <span
              className={cn(
                "flex h-10 w-10 shrink-0 items-center justify-center rounded-xl",
                "bg-[linear-gradient(135deg,var(--accent-1),var(--accent-2))]",
                "text-base font-black text-white shadow-[0_6px_18px_-6px_var(--neu-accent-glow)]"
              )}
            >
              AE
            </span>
            {!isCollapsed && (
              <span className="min-w-0">
                <span className="block truncate text-[0.95rem] font-bold leading-tight text-[var(--neu-text)]">
                  {copy.title}
                </span>
                <span className="block truncate text-[0.68rem] font-semibold uppercase tracking-[0.12em] text-[var(--neu-accent)]">
                  {copy.subtitle}
                </span>
              </span>
            )}
          </Link>
        </div>

        {/* Collapse toggle */}
        <button
          onClick={() => setIsCollapsed(!isCollapsed)}
          title={isCollapsed ? "Expand sidebar" : "Collapse sidebar"}
          aria-label={isCollapsed ? "Expand sidebar" : "Collapse sidebar"}
          className={cn(
            "absolute top-[4.25rem] z-50 hidden h-7 w-7 items-center justify-center rounded-full lg:flex",
            "border border-white/10 bg-[var(--neu-surface-solid)] text-[var(--neu-text-secondary)]",
            "shadow-lg transition-all hover:border-[rgba(var(--accent-rgb),0.6)]",
            "hover:bg-[var(--accent-1)] hover:text-white",
            isCollapsed ? "-right-3.5" : "-right-3.5"
          )}
        >
          {isCollapsed ? <ChevronRight size={15} /> : <ChevronLeft size={15} />}
        </button>

        {/* Navigation */}
        <nav className="relative flex-1 overflow-y-auto overflow-x-hidden px-3 py-4">
          {groups.map((group, gi) => (
            <div key={group.label} className={cn(gi > 0 && "mt-5")}>
              {!isCollapsed && (
                <p className="mb-2 px-3 text-[0.64rem] font-bold uppercase tracking-[0.14em] text-[var(--neu-text-muted)]">
                  {group.label}
                </p>
              )}
              {isCollapsed && gi > 0 && <div className="mx-3 mb-3 h-px bg-white/[0.07]" />}

              <div className="space-y-1">
                {group.items.map((item) => {
                  const Icon = item.icon;
                  const active = isItemActive(item.href);

                  return (
                    <Link
                      key={item.href}
                      href={item.href}
                      onClick={() => setIsOpen(false)}
                      title={isCollapsed ? item.name : undefined}
                      className={cn(
                        "group relative flex items-center gap-3 rounded-xl px-3 py-2.5",
                        "text-sm font-medium transition-all duration-200",
                        isCollapsed && "justify-center px-0",
                        active
                          ? "text-white"
                          : "text-[var(--neu-text-secondary)] hover:bg-white/[0.06] hover:text-[var(--neu-text)]"
                      )}
                    >
                      {/* Active pill */}
                      {active && (
                        <span
                          aria-hidden
                          className={cn(
                            "absolute inset-0 rounded-xl",
                            "bg-[linear-gradient(100deg,rgba(var(--accent-rgb),0.32),rgba(var(--accent-rgb),0.10))]",
                            "border border-[rgba(var(--accent-rgb),0.42)]",
                            "shadow-[0_6px_20px_-10px_var(--neu-accent-glow)]"
                          )}
                        />
                      )}
                      {/* Active left rail */}
                      {active && !isCollapsed && (
                        <span
                          aria-hidden
                          className="absolute -left-3 top-1/2 h-6 w-[3px] -translate-y-1/2 rounded-r-full bg-[linear-gradient(180deg,var(--accent-1),var(--accent-2))] shadow-[0_0_10px_var(--neu-accent-glow)]"
                        />
                      )}

                      <Icon
                        size={19}
                        className={cn(
                          "relative z-10 shrink-0 transition-transform duration-200",
                          active
                            ? "text-[var(--neu-accent)]"
                            : "group-hover:scale-110"
                        )}
                      />
                      {!isCollapsed && <span className="relative z-10 truncate">{item.name}</span>}
                    </Link>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>

        {/* Footer */}
        {!isCollapsed && (
          <div className="shrink-0 border-t border-white/[0.07] px-4 py-3">
            <p className="text-[0.68rem] text-[var(--neu-text-muted)]">
              AttendEase · HR, Leave &amp; Payroll
            </p>
          </div>
        )}
      </aside>
    </>
  );
}
