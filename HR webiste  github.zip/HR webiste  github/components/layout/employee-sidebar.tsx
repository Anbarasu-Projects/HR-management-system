"use client";

import {
  LayoutDashboard,
  ClipboardCheck,
  CalendarPlus,
  CalendarRange,
  FileText,
  Bell,
} from "lucide-react";
import { useSidebar } from "@/lib/SidebarContext";
import { SidebarShell, type NavGroup } from "./sidebar-shell";

const groups: NavGroup[] = [
  {
    label: "Overview",
    items: [{ name: "My Dashboard", href: "/employee", icon: LayoutDashboard }],
  },
  {
    label: "Time & Leave",
    items: [
      { name: "My Attendance", href: "/employee/attendance", icon: ClipboardCheck },
      { name: "Apply Leave", href: "/employee/leaves", icon: CalendarPlus },
      { name: "Team Calendar", href: "/employee/calendar", icon: CalendarRange },
    ],
  },
  {
    label: "Payroll",
    items: [{ name: "My Payslip", href: "/employee/payslip", icon: FileText }],
  },
  {
    label: "Account",
    items: [{ name: "Notifications", href: "/employee/notifications", icon: Bell }],
  },
];

export function EmployeeSidebar() {
  const { isEmployeeCollapsed, setIsEmployeeCollapsed } = useSidebar();

  return (
    <SidebarShell
      portal="employee"
      homeHref="/employee"
      groups={groups}
      isCollapsed={isEmployeeCollapsed}
      setIsCollapsed={setIsEmployeeCollapsed}
    />
  );
}
