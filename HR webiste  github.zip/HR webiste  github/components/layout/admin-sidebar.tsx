"use client";

import {
  LayoutDashboard,
  Users,
  ClipboardCheck,
  CalendarDays,
  CalendarRange,
  Wallet,
  Clock,
  Building2,
  BarChart2,
  ScrollText,
  Settings,
} from "lucide-react";
import { useSidebar } from "@/lib/SidebarContext";
import { SidebarShell, type NavGroup } from "./sidebar-shell";

// Grouped so a ten-item console still scans quickly.
const groups: NavGroup[] = [
  {
    label: "Overview",
    items: [{ name: "Dashboard", href: "/admin", icon: LayoutDashboard }],
  },
  {
    label: "People",
    items: [
      { name: "Employees", href: "/admin/employees", icon: Users },
      { name: "Departments", href: "/admin/departments", icon: Building2 },
      { name: "Shifts", href: "/admin/shifts", icon: Clock },
    ],
  },
  {
    label: "Time & Leave",
    items: [
      { name: "Attendance", href: "/admin/attendance", icon: ClipboardCheck },
      { name: "Leave Requests", href: "/admin/leaves", icon: CalendarDays },
      { name: "Leave Calendar", href: "/admin/calendar", icon: CalendarRange },
    ],
  },
  {
    label: "Payroll",
    items: [{ name: "Payroll", href: "/admin/payroll", icon: Wallet }],
  },
  {
    label: "System",
    items: [
      { name: "Reports", href: "/admin/reports", icon: BarChart2 },
      { name: "Audit Logs", href: "/admin/audit-logs", icon: ScrollText },
      { name: "Settings", href: "/admin/settings", icon: Settings },
    ],
  },
];

export function AdminSidebar() {
  const { isAdminCollapsed, setIsAdminCollapsed } = useSidebar();

  return (
    <SidebarShell
      portal="admin"
      homeHref="/admin"
      groups={groups}
      isCollapsed={isAdminCollapsed}
      setIsCollapsed={setIsAdminCollapsed}
    />
  );
}
