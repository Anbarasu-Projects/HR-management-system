"use client";

import * as React from "react";
import { Clock, LogIn, LogOut, RotateCcw } from "lucide-react";
import { ChipLoader } from "@/components/ui/chip-loader";
import { NeuCard, NeuCardContent } from "@/components/ui/neu-card";
import { NeuButton } from "@/components/ui/neu-button";
import { NeuBadge } from "@/components/ui/neu-badge";

interface WorkSession {
  checkIn: string;
  checkOut: string | null;
  hoursWorked: number;
  workingMinutes?: number;
}

interface TodayRecord {
  _id: string;
  date: string;
  checkIn: string | null;
  checkOut: string | null;
  status: "present" | "absent" | "late" | "half-day" | "on-leave";
  hoursWorked: number;
  sessions?: WorkSession[];
}

function formatTime(date: Date): string {
  return date.toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  });
}

function formatDate(date: Date): string {
  return date.toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

function formatShortTime(dateStr: string): string {
  const date = new Date(dateStr);
  return date.toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
  });
}


function badgeVariant(status: TodayRecord["status"]) {
  if (status === "present") return "present" as const;
  if (status === "late") return "late" as const;
  if (status === "absent") return "absent" as const;
  if (status === "half-day") return "warning" as const;
  return "accent" as const;
}

interface CheckInOutPanelProps {
  todayRecord: TodayRecord | null;
  initialLoading?: boolean;
  onAttendanceChanged?: () => Promise<void> | void;
}

export default function CheckInOutPanel({
  todayRecord,
  initialLoading = false,
  onAttendanceChanged,
}: CheckInOutPanelProps) {
  const [currentTime, setCurrentTime] = React.useState<Date | null>(null);
  const [loading, setLoading] = React.useState(false);

  React.useEffect(() => {
    setCurrentTime(new Date());
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const handleCheckIn = async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/attendance/check-in", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });
      const data = await response.json();
      if (data.success) await onAttendanceChanged?.();
      else alert(data.error || "Failed to check in");
    } catch (error) {
      console.error("Check-in error:", error);
      alert("Failed to check in");
    } finally {
      setLoading(false);
    }
  };

  const handleCheckOut = async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/attendance/check-out", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });
      const data = await response.json();
      if (data.success) await onAttendanceChanged?.();
      else alert(data.error || "Failed to check out");
    } catch (error) {
      console.error("Check-out error:", error);
      alert("Failed to check out");
    } finally {
      setLoading(false);
    }
  };

  const sessions = todayRecord?.sessions || [];
  const lastSession = sessions[sessions.length - 1];
  const hasWorkedToday = Boolean(todayRecord?.checkIn);
  const isCurrentlyCheckedIn = Boolean(
    hasWorkedToday &&
    (lastSession ? !lastSession.checkOut : todayRecord?.checkOut === null)
  );
  const canCheckInAgain = hasWorkedToday && !isCurrentlyCheckedIn;
  const activeCheckIn = lastSession && !lastSession.checkOut
    ? lastSession.checkIn
    : todayRecord?.checkIn;

  const getStatusInfo = () => {
    if (!hasWorkedToday) {
      return { text: "Not Checked In", color: "text-[var(--neu-text-muted)]" };
    }
    if (isCurrentlyCheckedIn && activeCheckIn) {
      return {
        text: `Checked In at ${formatShortTime(activeCheckIn)}`,
        color: "text-[var(--neu-success)]",
      };
    }
    return {
      text: `Session saved — ${(todayRecord?.hoursWorked || 0).toFixed(1)}h worked today`,
      color: "text-[var(--neu-accent)]",
    };
  };

  const statusInfo = getStatusInfo();

  return (
    <NeuCard className="w-full">
      <NeuCardContent className="p-8">
        <div className="flex flex-col items-center space-y-6">
          <div className="text-center">
            <div className="flex items-center justify-center gap-2 mb-1">
              <Clock className="w-5 h-5 md:w-6 md:h-6 text-[var(--neu-accent)]" />
              <span className="text-3xl md:text-5xl font-bold text-[var(--neu-text)] tracking-tight" suppressHydrationWarning>
                {currentTime ? formatTime(currentTime) : "--:--:-- --"}
              </span>
            </div>
            <p className="text-lg text-[var(--neu-text-secondary)]" suppressHydrationWarning>
              {currentTime ? formatDate(currentTime) : "Loading..."}
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3">
            <span className={`text-lg font-medium ${statusInfo.color}`}>{statusInfo.text}</span>
            {hasWorkedToday && todayRecord && (
              <NeuBadge variant={badgeVariant(todayRecord.status)}>
                {todayRecord.status.charAt(0).toUpperCase() + todayRecord.status.slice(1)}
              </NeuBadge>
            )}
            {sessions.length > 1 && (
              <span className="rounded-full border border-[var(--neu-border)] px-2.5 py-1 text-xs text-[var(--neu-text-secondary)]">
                {sessions.length} sessions today
              </span>
            )}
          </div>

          {initialLoading ? (
            <div className="w-full"><ChipLoader size="sm" /></div>
          ) : isCurrentlyCheckedIn ? (
            <NeuButton
              size="lg"
              loading={loading}
              onClick={handleCheckOut}
              className="w-52 h-14 text-lg bg-[var(--neu-warning)] text-[var(--neu-bg)] hover:brightness-110"
            >
              <LogOut className="w-5 h-5" />
              Check Out
            </NeuButton>
          ) : (
            <NeuButton
              variant="accent"
              size="lg"
              loading={loading}
              onClick={handleCheckIn}
              className="w-52 h-14 text-lg bg-[var(--neu-success)] hover:brightness-110"
            >
              {canCheckInAgain ? <RotateCcw className="w-5 h-5" /> : <LogIn className="w-5 h-5" />}
              {canCheckInAgain ? "Check In Again" : "Check In"}
            </NeuButton>
          )}

          {canCheckInAgain && (
            <p className="-mt-2 text-center text-xs text-[var(--neu-text-muted)]">
              Your previous session is saved. Start another session whenever you return to work.
            </p>
          )}
        </div>
      </NeuCardContent>
    </NeuCard>
  );
}
