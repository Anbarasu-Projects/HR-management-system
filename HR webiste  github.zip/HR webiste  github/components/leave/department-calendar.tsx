"use client";

import * as React from "react";
import { useCallback, useEffect, useMemo, useState } from "react";
import { ChevronLeft, ChevronRight, CalendarRange, Users, AlertTriangle } from "lucide-react";
import { NeuCard, NeuCardHeader, NeuCardTitle, NeuCardDescription, NeuCardContent } from "@/components/ui/neu-card";
import { NeuButton } from "@/components/ui/neu-button";
import { NeuBadge } from "@/components/ui/neu-badge";
import { ChipLoader } from "@/components/ui/chip-loader";
import { cn } from "@/lib/utils";

interface CalendarEntry {
  leaveId: string;
  userId: string;
  name: string;
  employeeId?: string;
  department: string;
  leaveType: "sick" | "casual" | "annual" | "unpaid" | string;
  startDate: string;
  endDate: string;
  totalDays: number;
  durationType?: "full-day" | "half-day";
  startTime?: string;
  endTime?: string;
}

interface DepartmentOption {
  id: string;
  name: string;
}

interface CalendarPayload {
  month: string;
  scope: string | null;
  departments: DepartmentOption[];
  entries: CalendarEntry[];
}

/** Visual language for each leave type. */
const leaveStyles: Record<string, { label: string; cell: string; dot: string }> = {
  annual: {
    label: "Annual",
    cell: "bg-[rgba(46,230,168,0.18)] text-[var(--neu-success)] border-[rgba(46,230,168,0.4)]",
    dot: "bg-[var(--neu-success)]",
  },
  sick: {
    label: "Medical",
    cell: "bg-[rgba(56,189,248,0.18)] text-[var(--neu-info)] border-[rgba(56,189,248,0.4)]",
    dot: "bg-[var(--neu-info)]",
  },
  casual: {
    label: "Casual",
    cell: "bg-[rgba(255,196,77,0.18)] text-[var(--neu-warning)] border-[rgba(255,196,77,0.4)]",
    dot: "bg-[var(--neu-warning)]",
  },
  unpaid: {
    label: "Unpaid",
    cell: "bg-[rgba(255,107,129,0.18)] text-[var(--neu-danger)] border-[rgba(255,107,129,0.4)]",
    dot: "bg-[var(--neu-danger)]",
  },
};

function styleFor(type: string) {
  return (
    leaveStyles[type] ?? {
      label: type,
      cell: "bg-white/[0.08] text-[var(--neu-text-secondary)] border-white/15",
      dot: "bg-[var(--neu-text-secondary)]",
    }
  );
}

function currentMonth() {
  return new Date().toISOString().slice(0, 7);
}

function shiftMonth(month: string, delta: number) {
  const [y, m] = month.split("-").map(Number);
  const d = new Date(y, m - 1 + delta, 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

function monthLabel(month: string) {
  const [y, m] = month.split("-").map(Number);
  return new Date(y, m - 1, 1).toLocaleDateString("en-US", {
    month: "long",
    year: "numeric",
  });
}

/** Midnight-normalised day number, so comparisons ignore the time part. */
function dayKey(d: Date) {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
}

interface DepartmentCalendarProps {
  /** Admins can switch departments; employees are locked to their own. */
  allowDepartmentFilter?: boolean;
  /** Flag days where this many people or more are away at once. */
  clashThreshold?: number;
}

export function DepartmentCalendar({
  allowDepartmentFilter = false,
  clashThreshold = 3,
}: DepartmentCalendarProps) {
  const [month, setMonth] = useState(currentMonth);
  const [department, setDepartment] = useState<string>("");
  const [data, setData] = useState<CalendarPayload | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams({ month });
      if (allowDepartmentFilter && department) params.set("department", department);

      const res = await fetch(`/api/leaves/calendar?${params.toString()}`);
      const json = await res.json();

      if (json.success) {
        setData(json.data);
      } else {
        setError(json.error || "Failed to load the calendar");
      }
    } catch (err) {
      console.error(err);
      setError("Failed to load the calendar");
    } finally {
      setLoading(false);
    }
  }, [month, department, allowDepartmentFilter]);

  useEffect(() => {
    load();
  }, [load]);

  const [year, monthNum] = month.split("-").map(Number);
  const daysInMonth = new Date(year, monthNum, 0).getDate();
  const days = useMemo(
    () => Array.from({ length: daysInMonth }, (_, i) => new Date(year, monthNum - 1, i + 1)),
    [daysInMonth, year, monthNum]
  );

  // One row per person, with a lookup of which days they're away.
  const rows = useMemo(() => {
    if (!data) return [];

    const byPerson = new Map<
      string,
      { name: string; department: string; days: Map<number, { type: string; durationType: "full-day" | "half-day"; startTime?: string; endTime?: string }> }
    >();

    for (const entry of data.entries) {
      const key = entry.userId || entry.leaveId;
      if (!byPerson.has(key)) {
        byPerson.set(key, {
          name: entry.name,
          department: entry.department,
          days: new Map(),
        });
      }

      const row = byPerson.get(key)!;
      const start = new Date(entry.startDate);
      const end = new Date(entry.endDate);

      for (const day of days) {
        const k = dayKey(day);
        if (k >= dayKey(start) && k <= dayKey(end)) {
          row.days.set(k, {
            type: entry.leaveType,
            durationType: entry.durationType === "half-day" ? "half-day" : "full-day",
            startTime: entry.startTime,
            endTime: entry.endTime,
          });
        }
      }
    }

    return Array.from(byPerson.values()).sort((a, b) => a.name.localeCompare(b.name));
  }, [data, days]);

  // Days where enough people are away to be worth a warning.
  const clashDays = useMemo(() => {
    const counts = new Map<number, number>();
    for (const row of rows) {
      for (const k of row.days.keys()) {
        counts.set(k, (counts.get(k) ?? 0) + 1);
      }
    }
    return new Set(
      Array.from(counts.entries())
        .filter(([, count]) => count >= clashThreshold)
        .map(([k]) => k)
    );
  }, [rows, clashThreshold]);

  const isWeekend = (d: Date) => d.getDay() === 0 || d.getDay() === 6;
  const todayKey = dayKey(new Date());

  return (
    <NeuCard>
      <NeuCardHeader>
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div className="min-w-0">
            <NeuCardTitle className="flex items-center gap-2">
              <CalendarRange className="h-5 w-5 text-[var(--neu-accent)]" />
              Department Leave Calendar
            </NeuCardTitle>
            <NeuCardDescription>
              {data?.scope
                ? `Approved leave across ${data.scope}.`
                : "Approved leave across every department."}
            </NeuCardDescription>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            {allowDepartmentFilter && data && data.departments.length > 0 && (
              <select
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                aria-label="Filter by department"
                className="h-10 cursor-pointer rounded-xl border border-white/[0.12] bg-black/25 px-3 text-sm text-[var(--neu-text)] backdrop-blur-sm focus:border-[var(--neu-accent)] focus:outline-none"
              >
                <option value="">All departments</option>
                {data.departments.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.name}
                  </option>
                ))}
              </select>
            )}

            <div className="flex items-center gap-1 rounded-xl border border-white/[0.1] bg-white/[0.04] p-1">
              <NeuButton
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={() => setMonth((m) => shiftMonth(m, -1))}
                aria-label="Previous month"
              >
                <ChevronLeft className="h-4 w-4" />
              </NeuButton>
              <span className="min-w-[8.5rem] text-center text-sm font-semibold text-[var(--neu-text)]">
                {monthLabel(month)}
              </span>
              <NeuButton
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={() => setMonth((m) => shiftMonth(m, 1))}
                aria-label="Next month"
              >
                <ChevronRight className="h-4 w-4" />
              </NeuButton>
            </div>
          </div>
        </div>
      </NeuCardHeader>

      <NeuCardContent>
        {/* Legend */}
        <div className="mb-4 flex flex-wrap items-center gap-2">
          {Object.entries(leaveStyles).map(([key, s]) => (
            <span
              key={key}
              className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-2.5 py-1 text-[0.72rem] font-medium text-[var(--neu-text-secondary)]"
            >
              <span className={cn("h-1.5 w-1.5 rounded-full", s.dot)} />
              {s.label}
            </span>
          ))}
          <span className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-2.5 py-1 text-[0.72rem] font-medium text-[var(--neu-text-secondary)]">
            <span className="font-bold text-[var(--neu-accent)]">½</span>
            Half day
          </span>
        </div>

        {clashDays.size > 0 && (
          <div className="mb-4 flex items-start gap-2.5 rounded-xl border border-[rgba(255,196,77,0.35)] bg-[rgba(255,196,77,0.1)] px-4 py-3">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-[var(--neu-warning)]" />
            <p className="text-sm text-[var(--neu-warning)]">
              {clashDays.size} {clashDays.size === 1 ? "day has" : "days have"}{" "}
              {clashThreshold} or more people away. Check coverage before approving more
              leave.
            </p>
          </div>
        )}

        {loading ? (
          <ChipLoader size="sm" />
        ) : error ? (
          <div className="py-10 text-center">
            <p className="text-sm text-[var(--neu-danger)]">{error}</p>
            <NeuButton variant="accent" size="sm" onClick={load} className="mt-4">
              Retry
            </NeuButton>
          </div>
        ) : rows.length === 0 ? (
          <div className="py-12 text-center">
            <Users className="mx-auto mb-3 h-8 w-8 text-[var(--neu-text-muted)]" />
            <p className="text-sm text-[var(--neu-text-secondary)]">
              Nobody has approved leave in {monthLabel(month)}.
            </p>
          </div>
        ) : (
          <div className="table-responsive rounded-xl border border-white/[0.07]">
            <table className="w-full border-collapse">
              <thead>
                <tr>
                  <th className="sticky left-0 z-20 min-w-[11rem] bg-[var(--neu-surface-solid)] px-4 py-3 text-left text-[0.7rem] font-bold uppercase tracking-[0.08em] text-[var(--neu-text-secondary)]">
                    Employee
                  </th>
                  {days.map((d) => {
                    const k = dayKey(d);
                    return (
                      <th
                        key={k}
                        className={cn(
                          "min-w-[2.25rem] px-1 py-2 text-center text-[0.68rem] font-semibold",
                          isWeekend(d)
                            ? "bg-white/[0.03] text-[var(--neu-text-muted)]"
                            : "text-[var(--neu-text-secondary)]",
                          k === todayKey && "text-[var(--neu-accent)]",
                          clashDays.has(k) && "bg-[rgba(255,196,77,0.1)]"
                        )}
                      >
                        <span className="block leading-tight">{d.getDate()}</span>
                        <span className="block text-[0.6rem] font-normal opacity-60">
                          {d.toLocaleDateString("en-US", { weekday: "narrow" })}
                        </span>
                      </th>
                    );
                  })}
                </tr>
              </thead>

              <tbody className="divide-y divide-white/[0.06]">
                {rows.map((row) => (
                  <tr key={`${row.name}-${row.department}`} className="hover:bg-white/[0.03]">
                    <td className="sticky left-0 z-10 bg-[var(--neu-surface-solid)] px-4 py-2.5">
                      <p className="truncate text-sm font-medium text-[var(--neu-text)]">
                        {row.name}
                      </p>
                      <p className="truncate text-[0.68rem] text-[var(--neu-text-muted)]">
                        {row.department}
                      </p>
                    </td>

                    {days.map((d) => {
                      const k = dayKey(d);
                      const leaveDay = row.days.get(k);
                      const s = leaveDay ? styleFor(leaveDay.type) : null;

                      return (
                        <td key={k} className="px-0.5 py-1.5 text-center align-middle">
                          {s ? (
                            <span
                              title={`${row.name} — ${s.label} leave${leaveDay?.durationType === "half-day" ? ` (half day ${leaveDay.startTime || ""}–${leaveDay.endTime || ""})` : ""}`}
                              className={cn(
                                "mx-auto flex h-6 w-6 items-center justify-center rounded-md border text-[0.62rem] font-bold",
                                s.cell
                              )}
                            >
                              {leaveDay?.durationType === "half-day" ? "½" : ""}
                            </span>
                          ) : (
                            <span
                              className={cn(
                                "mx-auto block h-6 w-6 rounded-md",
                                isWeekend(d) ? "bg-white/[0.03]" : "bg-white/[0.015]"
                              )}
                            />
                          )}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {!loading && !error && rows.length > 0 && (
          <div className="mt-4 flex flex-wrap items-center gap-3">
            <NeuBadge variant="accent">
              {rows.length} {rows.length === 1 ? "person" : "people"} with leave
            </NeuBadge>
            <span className="text-xs text-[var(--neu-text-muted)]">
              Only approved requests appear here.
            </span>
          </div>
        )}
      </NeuCardContent>
    </NeuCard>
  );
}
