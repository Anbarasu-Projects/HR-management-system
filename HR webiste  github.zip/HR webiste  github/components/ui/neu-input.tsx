"use client";

import * as React from "react";
import { cn } from "@/lib/utils";

interface NeuInputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "size"> {
  label?: string;
  error?: string;
  icon?: React.ReactNode;
  /** Small helper line under the field. */
  hint?: string;
}

const NeuInput = React.forwardRef<HTMLInputElement, NeuInputProps>(
  ({ className, label, error, icon, hint, id, ...props }, ref) => {
    const reactId = React.useId();
    const inputId = id || reactId;

    return (
      <div className="w-full">
        {label && (
          <label
            htmlFor={inputId}
            className="mb-2 block text-[0.8rem] font-semibold tracking-wide text-[var(--neu-text-secondary)]"
          >
            {label}
          </label>
        )}

        <div className="group relative">
          {icon && (
            <div
              className={cn(
                "pointer-events-none absolute left-3 top-1/2 z-10 -translate-y-1/2",
                "flex h-8 w-8 items-center justify-center rounded-lg",
                "border border-white/[0.08] bg-white/[0.045] text-[var(--neu-text-muted)]",
                "shadow-[0_3px_12px_rgba(0,0,0,0.2)]",
                "transition-all duration-300 ease-out",
                "group-hover:border-white/[0.16] group-hover:bg-white/[0.07]",
                "group-focus-within:scale-110 group-focus-within:-rotate-3",
                "group-focus-within:border-[var(--neu-accent)]/45 group-focus-within:bg-[var(--neu-accent)]/12",
                "group-focus-within:text-[var(--neu-accent)] group-focus-within:shadow-[0_0_18px_rgba(var(--accent-rgb),0.24)]"
              )}
            >
              <span className="transition-transform duration-300 group-focus-within:scale-110">{icon}</span>
            </div>
          )}

          <input
            ref={ref}
            id={inputId}
            className={cn(
              "w-full rounded-xl px-4 py-3",
              "bg-black/25 text-[var(--neu-text)] backdrop-blur-sm",
              "border border-white/[0.09]",
              "shadow-[inset_0_1px_6px_rgba(0,0,0,0.4)]",
              "placeholder:text-[var(--neu-text-muted)]",
              "transition-all duration-200 ease-out",
              "hover:border-white/[0.16]",
              "focus:border-[var(--neu-accent)] focus:bg-black/35 focus:outline-none",
              "focus:shadow-[inset_0_1px_6px_rgba(0,0,0,0.4),0_0_0_4px_rgba(var(--accent-rgb),0.15)]",
              "disabled:cursor-not-allowed disabled:opacity-50",
              error &&
                "border-[var(--neu-danger)] focus:border-[var(--neu-danger)] focus:shadow-[inset_0_1px_6px_rgba(0,0,0,0.4),0_0_0_4px_rgba(255,107,129,0.18)]",
              icon && "pl-14",
              className
            )}
            {...props}
          />
        </div>

        {error ? (
          <p className="mt-1.5 flex items-center gap-1 text-xs font-medium text-[var(--neu-danger)]">
            {error}
          </p>
        ) : hint ? (
          <p className="mt-1.5 text-xs text-[var(--neu-text-muted)]">{hint}</p>
        ) : null}
      </div>
    );
  }
);

NeuInput.displayName = "NeuInput";

export { NeuInput, type NeuInputProps };
