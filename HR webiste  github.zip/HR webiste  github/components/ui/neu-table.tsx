"use client";

import * as React from "react";
import { cn } from "@/lib/utils";

interface NeuTableProps extends React.HTMLAttributes<HTMLTableElement> {
  children: React.ReactNode;
}

const NeuTable = React.forwardRef<HTMLTableElement, NeuTableProps>(
  ({ className, children, ...props }, ref) => {
    return (
      <div
        className={cn(
          "w-full overflow-x-auto rounded-[var(--neu-radius)]",
          "glass gradient-border"
        )}
      >
        <table
          ref={ref}
          className={cn("w-full border-collapse text-left", className)}
          {...props}
        >
          {children}
        </table>
      </div>
    );
  }
);

NeuTable.displayName = "NeuTable";

interface NeuTableHeaderProps extends React.HTMLAttributes<HTMLTableSectionElement> {
  children: React.ReactNode;
}

const NeuTableHeader = React.forwardRef<HTMLTableSectionElement, NeuTableHeaderProps>(
  ({ className, children, ...props }, ref) => {
    return (
      <thead
        ref={ref}
        className={cn(
          "sticky top-0 z-10 backdrop-blur-xl",
          "bg-[linear-gradient(180deg,rgba(var(--accent-rgb),0.14),rgba(255,255,255,0.03))]",
          className
        )}
        {...props}
      >
        {children}
      </thead>
    );
  }
);

NeuTableHeader.displayName = "NeuTableHeader";

interface NeuTableBodyProps extends React.HTMLAttributes<HTMLTableSectionElement> {
  children: React.ReactNode;
}

const NeuTableBody = React.forwardRef<HTMLTableSectionElement, NeuTableBodyProps>(
  ({ className, children, ...props }, ref) => {
    return (
      <tbody ref={ref} className={cn("divide-y divide-white/[0.06]", className)} {...props}>
        {children}
      </tbody>
    );
  }
);

NeuTableBody.displayName = "NeuTableBody";

interface NeuTableRowProps extends React.HTMLAttributes<HTMLTableRowElement> {
  children: React.ReactNode;
}

const NeuTableRow = React.forwardRef<HTMLTableRowElement, NeuTableRowProps>(
  ({ className, children, ...props }, ref) => {
    return (
      <tr
        ref={ref}
        className={cn(
          "group transition-colors duration-200",
          // Accent rail slides in from the left on hover.
          "hover:bg-[rgba(var(--accent-rgb),0.07)]",
          "[&>td:first-child]:relative",
          "[&>td:first-child]:before:absolute [&>td:first-child]:before:left-0 [&>td:first-child]:before:top-0",
          "[&>td:first-child]:before:h-full [&>td:first-child]:before:w-[3px]",
          "[&>td:first-child]:before:bg-[linear-gradient(180deg,var(--accent-1),var(--accent-2))]",
          "[&>td:first-child]:before:scale-y-0 [&>td:first-child]:before:transition-transform",
          "[&>td:first-child]:before:duration-200 group-hover:[&>td:first-child]:before:scale-y-100",
          className
        )}
        {...props}
      >
        {children}
      </tr>
    );
  }
);

NeuTableRow.displayName = "NeuTableRow";

interface NeuTableHeadProps extends React.ThHTMLAttributes<HTMLTableCellElement> {
  children: React.ReactNode;
}

const NeuTableHead = React.forwardRef<HTMLTableCellElement, NeuTableHeadProps>(
  ({ className, children, ...props }, ref) => {
    return (
      <th
        ref={ref}
        className={cn(
          "whitespace-nowrap px-4 py-3.5 text-left",
          "text-[0.72rem] font-bold uppercase tracking-[0.08em] text-[var(--neu-text-secondary)]",
          "border-b border-white/10",
          className
        )}
        {...props}
      >
        {children}
      </th>
    );
  }
);

NeuTableHead.displayName = "NeuTableHead";

interface NeuTableCellProps extends React.TdHTMLAttributes<HTMLTableCellElement> {
  children: React.ReactNode;
}

const NeuTableCell = React.forwardRef<HTMLTableCellElement, NeuTableCellProps>(
  ({ className, children, ...props }, ref) => {
    return (
      <td
        ref={ref}
        className={cn(
          "px-4 py-3.5 text-sm text-[var(--neu-text-secondary)]",
          "transition-colors group-hover:text-[var(--neu-text)]",
          className
        )}
        {...props}
      >
        {children}
      </td>
    );
  }
);

NeuTableCell.displayName = "NeuTableCell";

export {
  NeuTable,
  NeuTableHeader,
  NeuTableBody,
  NeuTableRow,
  NeuTableHead,
  NeuTableCell,
  type NeuTableProps,
  type NeuTableHeaderProps,
  type NeuTableBodyProps,
  type NeuTableRowProps,
  type NeuTableHeadProps,
  type NeuTableCellProps,
};
