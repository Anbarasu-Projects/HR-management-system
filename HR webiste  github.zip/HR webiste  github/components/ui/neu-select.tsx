"use client";

import * as React from "react";
import { cn } from "@/lib/utils";

interface SelectOption {
  value: string;
  label: string;
}

interface NeuSelectProps extends Omit<React.SelectHTMLAttributes<HTMLSelectElement>, "size"> {
  label?: string;
  error?: string;
  options: SelectOption[];
  placeholder?: string;
}

const NeuSelect = React.forwardRef<HTMLSelectElement, NeuSelectProps>(
  ({ className, label, error, options, placeholder, id, ...props }, ref) => {
    const reactId = React.useId();
    const selectId = id || reactId;

    return (
      <div className="w-full">
        {label && (
          <label
            htmlFor={selectId}
            className="mb-2 block text-[0.8rem] font-semibold tracking-wide text-[var(--neu-text-secondary)]"
          >
            {label}
          </label>
        )}

        <div className="group relative">
          <select
            ref={ref}
            id={selectId}
            className={cn(
              "w-full cursor-pointer appearance-none rounded-xl px-4 py-3 pr-10",
              "bg-black/25 text-[var(--neu-text)] backdrop-blur-sm",
              "border border-white/[0.09]",
              "shadow-[inset_0_1px_6px_rgba(0,0,0,0.4)]",
              "transition-all duration-200 ease-out",
              "hover:border-white/[0.16]",
              "focus:border-[var(--neu-accent)] focus:bg-black/35 focus:outline-none",
              "focus:shadow-[inset_0_1px_6px_rgba(0,0,0,0.4),0_0_0_4px_rgba(var(--accent-rgb),0.15)]",
              "disabled:cursor-not-allowed disabled:opacity-50",
              error && "border-[var(--neu-danger)] focus:border-[var(--neu-danger)]",
              className
            )}
            {...props}
          >
            {placeholder && (
              <option value="" disabled>
                {placeholder}
              </option>
            )}
            {options.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>

          <div className="pointer-events-none absolute right-3.5 top-1/2 -translate-y-1/2 text-[var(--neu-text-muted)] transition-colors group-focus-within:text-[var(--neu-accent)]">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="6 9 12 15 18 9" />
            </svg>
          </div>
        </div>

        {error && <p className="mt-1.5 text-xs font-medium text-[var(--neu-danger)]">{error}</p>}
      </div>
    );
  }
);

NeuSelect.displayName = "NeuSelect";

export { NeuSelect, type NeuSelectProps, type SelectOption };
