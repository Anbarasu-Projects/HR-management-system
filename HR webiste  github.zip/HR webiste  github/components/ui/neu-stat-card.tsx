"use client";

import * as React from "react";
import { cn } from "@/lib/utils";

type TrendDirection = "up" | "down" | "neutral";
type StatTone = "accent" | "success" | "warning" | "danger" | "info";

interface NeuStatCardProps extends React.HTMLAttributes<HTMLDivElement> {
  title: string;
  value: string | number;
  subtitle?: string;
  icon?: React.ReactNode;
  trend?: TrendDirection;
  trendValue?: string;
  /** Colour-codes the KPI so a dashboard row reads at a glance. */
  tone?: StatTone;
  /** 0–100. Draws a progress rail along the bottom of the card. */
  progress?: number;
}

const toneTokens: Record<StatTone, { ring: string; tile: string; text: string; rail: string }> = {
  accent: {
    ring: "hover:shadow-[0_18px_44px_-14px_var(--neu-accent-glow)]",
    tile: "bg-[linear-gradient(135deg,var(--accent-1),var(--accent-2))] text-white",
    text: "text-[var(--neu-accent)]",
    rail: "bg-[linear-gradient(90deg,var(--accent-1),var(--accent-2))]",
  },
  success: {
    ring: "hover:shadow-[0_18px_44px_-14px_rgba(var(--success-rgb),0.5)]",
    tile: "bg-[linear-gradient(135deg,#2ee6a8,#14b8a6)] text-[#04231a]",
    text: "text-[var(--neu-success)]",
    rail: "bg-[linear-gradient(90deg,#2ee6a8,#14b8a6)]",
  },
  warning: {
    ring: "hover:shadow-[0_18px_44px_-14px_rgba(var(--warning-rgb),0.5)]",
    tile: "bg-[linear-gradient(135deg,#ffc44d,#f59e0b)] text-[#2b1a02]",
    text: "text-[var(--neu-warning)]",
    rail: "bg-[linear-gradient(90deg,#ffc44d,#f59e0b)]",
  },
  danger: {
    ring: "hover:shadow-[0_18px_44px_-14px_rgba(var(--danger-rgb),0.5)]",
    tile: "bg-[linear-gradient(135deg,#ff6b81,#e11d48)] text-white",
    text: "text-[var(--neu-danger)]",
    rail: "bg-[linear-gradient(90deg,#ff6b81,#e11d48)]",
  },
  info: {
    ring: "hover:shadow-[0_18px_44px_-14px_rgba(56,189,248,0.5)]",
    tile: "bg-[linear-gradient(135deg,#38bdf8,#6366f1)] text-white",
    text: "text-[var(--neu-info)]",
    rail: "bg-[linear-gradient(90deg,#38bdf8,#6366f1)]",
  },
};

const trendStyles: Record<TrendDirection, { color: string; icon: React.ReactNode }> = {
  up: {
    color: "text-[var(--neu-success)] bg-[rgba(46,230,168,0.12)]",
    icon: (
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
        <polyline points="18 15 12 9 6 15" />
      </svg>
    ),
  },
  down: {
    color: "text-[var(--neu-danger)] bg-[rgba(255,107,129,0.12)]",
    icon: (
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
        <polyline points="6 9 12 15 18 9" />
      </svg>
    ),
  },
  neutral: {
    color: "text-[var(--neu-text-muted)] bg-white/5",
    icon: (
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
        <line x1="5" y1="12" x2="19" y2="12" />
      </svg>
    ),
  },
};

const NeuStatCard = React.forwardRef<HTMLDivElement, NeuStatCardProps>(
  (
    {
      className,
      title,
      value,
      subtitle,
      icon,
      trend = "neutral",
      trendValue,
      tone = "accent",
      progress,
      ...props
    },
    ref
  ) => {
    const trendStyle = trendStyles[trend];
    const t = toneTokens[tone];

    return (
      <div
        ref={ref}
        className={cn(
          "group relative overflow-hidden rounded-[var(--neu-radius)] p-5 sm:p-6",
          "glass gradient-border hover-sheen",
          "transition-[transform,box-shadow] duration-300 ease-out",
          "hover:-translate-y-1",
          t.ring,
          className
        )}
        {...props}
      >
        {/* Corner bloom — subtle until hover, then it lifts the whole tile */}
        <div
          aria-hidden
          className={cn(
            "pointer-events-none absolute -right-10 -top-12 h-32 w-32 rounded-full blur-3xl",
            "opacity-25 transition-opacity duration-500 group-hover:opacity-50",
            t.rail
          )}
        />

        <div className="relative flex items-start justify-between gap-4">
          <div className="min-w-0 flex-1">
            <p className="text-[0.78rem] font-semibold uppercase tracking-[0.08em] text-[var(--neu-text-secondary)]">
              {title}
            </p>

            <p className="mt-2.5 text-3xl font-bold leading-none tracking-tight text-[var(--neu-text)] tabular-nums sm:text-[2rem]">
              {value}
            </p>

            {(subtitle || trendValue) && (
              <div className="mt-3 flex flex-wrap items-center gap-2">
                {trendValue && (
                  <span
                    className={cn(
                      "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-semibold",
                      trendStyle.color
                    )}
                  >
                    {trendStyle.icon}
                    {trendValue}
                  </span>
                )}
                {subtitle && (
                  <span className="text-xs text-[var(--neu-text-muted)]">{subtitle}</span>
                )}
              </div>
            )}
          </div>

          {icon && (
            <div
              className={cn(
                "flex h-12 w-12 shrink-0 items-center justify-center rounded-xl shadow-lg",
                "transition-transform duration-300 group-hover:scale-110 group-hover:-rotate-6",
                t.tile
              )}
            >
              {icon}
            </div>
          )}
        </div>

        {typeof progress === "number" && (
          <div className="relative mt-5 h-1.5 w-full overflow-hidden rounded-full bg-white/[0.07]">
            <div
              className={cn("h-full rounded-full transition-[width] duration-700 ease-out", t.rail)}
              style={{ width: `${Math.min(100, Math.max(0, progress))}%` }}
            />
          </div>
        )}
      </div>
    );
  }
);

NeuStatCard.displayName = "NeuStatCard";

export { NeuStatCard, type NeuStatCardProps, type TrendDirection, type StatTone };
