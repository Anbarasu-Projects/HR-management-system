"use client";

import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

/**
 * Buttons size to their content (with a sensible minimum) rather than being
 * pinned to a fixed pixel width, so labels never truncate.
 */
const neuButtonVariants = cva(
  [
    "group relative inline-flex shrink-0 items-center justify-center gap-2",
    "cursor-pointer select-none overflow-hidden outline-none",
    "font-semibold tracking-wide no-underline",
    "transition-[transform,box-shadow,background-color,border-color] duration-200 ease-out",
    "active:scale-[0.97]",
  ].join(" "),
  {
    variants: {
      variant: {
        // Solid gradient in the active portal accent — the primary action.
        default: [
          "text-white border border-white/10",
          "bg-[linear-gradient(135deg,var(--accent-1),var(--accent-2))]",
          "shadow-[0_6px_20px_-6px_var(--neu-accent-glow),inset_0_1px_0_rgba(255,255,255,0.28)]",
          "hover:shadow-[0_12px_32px_-8px_var(--neu-accent-glow),inset_0_1px_0_rgba(255,255,255,0.34)]",
          "hover:brightness-110",
        ].join(" "),
        // Tinted glass — secondary action.
        accent: [
          "text-[var(--neu-accent)] border border-[rgba(var(--accent-rgb),0.4)]",
          "bg-[var(--neu-accent-soft)] backdrop-blur-md",
          "hover:bg-[rgba(var(--accent-rgb),0.22)] hover:border-[rgba(var(--accent-rgb),0.6)]",
          "hover:shadow-[0_8px_24px_-10px_var(--neu-accent-glow)]",
        ].join(" "),
        // Minimal — for toolbars and icon rows.
        ghost: [
          "text-[var(--neu-text-secondary)] border border-transparent bg-transparent",
          "hover:bg-white/[0.07] hover:text-[var(--neu-text)]",
        ].join(" "),
        // Destructive.
        danger: [
          "text-[var(--neu-danger)] border border-[rgba(255,107,129,0.4)]",
          "bg-[rgba(255,107,129,0.12)] backdrop-blur-md",
          "hover:bg-[rgba(255,107,129,0.22)] hover:text-white",
          "hover:shadow-[0_8px_24px_-10px_rgba(255,107,129,0.6)]",
        ].join(" "),
        // Neutral glass outline.
        outline: [
          "text-[var(--neu-text)] border border-white/[0.14] bg-white/[0.04] backdrop-blur-md",
          "hover:border-[rgba(var(--accent-rgb),0.5)] hover:bg-white/[0.08]",
        ].join(" "),
      },
      size: {
        sm: "h-9 min-w-[5rem] rounded-lg px-3.5 text-[0.8rem]",
        md: "h-11 min-w-[7rem] rounded-xl px-5 text-sm",
        lg: "h-13 min-w-[9rem] rounded-2xl px-7 text-base",
        icon: "h-11 w-11 min-w-0 rounded-xl p-0",
        full: "h-11 w-full rounded-xl px-5 text-sm",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "md",
    },
  }
);

export interface NeuButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof neuButtonVariants> {
  asChild?: boolean;
  loading?: boolean;
}

const NeuButton = React.forwardRef<HTMLButtonElement, NeuButtonProps>(
  (
    { className, variant, size, asChild = false, loading = false, children, disabled, ...props },
    ref
  ) => {
    const Comp = asChild ? Slot : "button";
    const isBlocked = loading || disabled;

    return (
      <Comp
        ref={ref}
        className={cn(
          neuButtonVariants({ variant, size }),
          isBlocked && "pointer-events-none opacity-60 saturate-50",
          className
        )}
        disabled={disabled || loading}
        {...props}
      >
        {/* Light sweep on hover */}
        <span
          aria-hidden
          className={cn(
            "pointer-events-none absolute inset-0 -translate-x-full",
            "bg-[linear-gradient(100deg,transparent,rgba(255,255,255,0.22),transparent)]",
            "transition-transform duration-700 ease-out group-hover:translate-x-full"
          )}
        />

        {loading && (
          <svg
            className="h-4 w-4 shrink-0 animate-spin"
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            aria-hidden
          >
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
            <path
              className="opacity-75"
              fill="currentColor"
              d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
            />
          </svg>
        )}

        <span className="relative z-10 inline-flex items-center gap-2">{children}</span>
      </Comp>
    );
  }
);

NeuButton.displayName = "NeuButton";

export { NeuButton, neuButtonVariants };
