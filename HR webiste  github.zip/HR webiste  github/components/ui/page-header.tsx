"use client";

import * as React from "react";
import { cn } from "@/lib/utils";

// `title` is omitted from the native attributes so it can hold rich JSX
// rather than the plain tooltip string HTMLAttributes expects.
interface PageHeaderProps extends Omit<React.HTMLAttributes<HTMLDivElement>, "title"> {
  /** Small uppercase label above the title. */
  eyebrow?: string;
  title: React.ReactNode;
  description?: React.ReactNode;
  /** Buttons, month pickers, export controls — right-aligned on desktop. */
  actions?: React.ReactNode;
  icon?: React.ReactNode;
}

/**
 * The banner that opens every dashboard page. It picks up the portal accent
 * automatically, so the admin console reads violet and the employee portal
 * reads cyan without any per-page configuration.
 */
export function PageHeader({
  eyebrow,
  title,
  description,
  actions,
  icon,
  className,
  ...props
}: PageHeaderProps) {
  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-[var(--neu-radius-lg)]",
        "glass gradient-border",
        "px-5 py-6 sm:px-7 sm:py-7",
        className
      )}
      {...props}
    >
      {/* Accent bloom anchored to the top-right corner */}
      <div
        aria-hidden
        className="pointer-events-none absolute -right-16 -top-24 h-56 w-56 rounded-full bg-[linear-gradient(135deg,var(--accent-1),var(--accent-2))] opacity-25 blur-3xl"
      />
      {/* Faint grid texture for depth */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-[0.35]"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,255,255,0.035) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.035) 1px, transparent 1px)",
          backgroundSize: "34px 34px",
          maskImage: "radial-gradient(70% 100% at 50% 0%, #000, transparent)",
          WebkitMaskImage: "radial-gradient(70% 100% at 50% 0%, #000, transparent)",
        }}
      />

      <div className="relative flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex min-w-0 items-start gap-4">
          {icon && (
            <span
              className={cn(
                "hidden h-12 w-12 shrink-0 items-center justify-center rounded-2xl sm:flex",
                "bg-[linear-gradient(135deg,var(--accent-1),var(--accent-2))] text-white",
                "shadow-[0_8px_24px_-8px_var(--neu-accent-glow)]"
              )}
            >
              {icon}
            </span>
          )}

          <div className="min-w-0">
            {eyebrow && <span className="eyebrow mb-2.5">{eyebrow}</span>}

            <h1 className="text-2xl font-bold leading-tight tracking-tight text-[var(--neu-text)] sm:text-[1.75rem]">
              {title}
            </h1>

            {description && (
              <p className="mt-1.5 max-w-2xl text-sm leading-relaxed text-[var(--neu-text-secondary)]">
                {description}
              </p>
            )}
          </div>
        </div>

        {actions && (
          <div className="flex shrink-0 flex-wrap items-center gap-2.5">{actions}</div>
        )}
      </div>
    </div>
  );
}
