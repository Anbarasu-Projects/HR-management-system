"use client";

import * as React from "react";
import { cn } from "@/lib/utils";

type BadgeVariant =
  | "present"
  | "absent"
  | "late"
  | "default"
  | "accent"
  | "success"
  | "error"
  | "warning";

interface NeuBadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  variant?: BadgeVariant;
  /** Pulses the status dot — useful for live/pending states. */
  pulse?: boolean;
  children: React.ReactNode;
}

const variantStyles: Record<BadgeVariant, { dot: string; wrap: string }> = {
  present: {
    dot: "bg-[var(--neu-success)] shadow-[0_0_8px_rgba(46,230,168,0.9)]",
    wrap: "bg-[rgba(46,230,168,0.12)] text-[var(--neu-success)] border-[rgba(46,230,168,0.35)]",
  },
  absent: {
    dot: "bg-[var(--neu-danger)] shadow-[0_0_8px_rgba(255,107,129,0.9)]",
    wrap: "bg-[rgba(255,107,129,0.12)] text-[var(--neu-danger)] border-[rgba(255,107,129,0.35)]",
  },
  late: {
    dot: "bg-[var(--neu-warning)] shadow-[0_0_8px_rgba(255,196,77,0.9)]",
    wrap: "bg-[rgba(255,196,77,0.12)] text-[var(--neu-warning)] border-[rgba(255,196,77,0.35)]",
  },
  default: {
    dot: "bg-[var(--neu-text-secondary)]",
    wrap: "bg-white/[0.06] text-[var(--neu-text-secondary)] border-white/10",
  },
  accent: {
    dot: "bg-[var(--neu-accent)] shadow-[0_0_8px_var(--neu-accent-glow)]",
    wrap: "bg-[var(--neu-accent-soft)] text-[var(--neu-accent)] border-[rgba(var(--accent-rgb),0.35)]",
  },
  success: {
    dot: "bg-[var(--neu-success)] shadow-[0_0_8px_rgba(46,230,168,0.9)]",
    wrap: "bg-[rgba(46,230,168,0.12)] text-[var(--neu-success)] border-[rgba(46,230,168,0.35)]",
  },
  error: {
    dot: "bg-[var(--neu-danger)] shadow-[0_0_8px_rgba(255,107,129,0.9)]",
    wrap: "bg-[rgba(255,107,129,0.12)] text-[var(--neu-danger)] border-[rgba(255,107,129,0.35)]",
  },
  warning: {
    dot: "bg-[var(--neu-warning)] shadow-[0_0_8px_rgba(255,196,77,0.9)]",
    wrap: "bg-[rgba(255,196,77,0.12)] text-[var(--neu-warning)] border-[rgba(255,196,77,0.35)]",
  },
};

const NeuBadge = React.forwardRef<HTMLSpanElement, NeuBadgeProps>(
  ({ className, variant = "default", pulse = false, children, ...props }, ref) => {
    const styles = variantStyles[variant];

    return (
      <span
        ref={ref}
        className={cn(
          "inline-flex items-center gap-1.5 whitespace-nowrap px-2.5 py-1",
          "rounded-full border text-[0.72rem] font-semibold tracking-wide",
          "backdrop-blur-sm",
          styles.wrap,
          className
        )}
        {...props}
      >
        <span className={cn("h-1.5 w-1.5 shrink-0 rounded-full", styles.dot, pulse && "animate-pulse")} />
        {children}
      </span>
    );
  }
);

NeuBadge.displayName = "NeuBadge";

export { NeuBadge, type NeuBadgeProps, type BadgeVariant };
