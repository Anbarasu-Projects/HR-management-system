"use client";

import * as React from "react";
import { useState } from "react";
import Link from "next/link";
import {
  Eye,
  EyeOff,
  ArrowLeft,
  ArrowRight,
  Mail,
  Lock,
  User as UserIcon,
  Building2,
  AlertCircle,
  CalendarDays,
  Wallet,
  ShieldCheck,
  KeyRound,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { NeuButton } from "@/components/ui/neu-button";
import { NeuInput } from "@/components/ui/neu-input";

/**
 * Split-screen authentication screen.
 *
 * Left  — brand panel: aurora wash, product promise, portal highlights.
 * Right — the form itself.
 *
 * Which form renders is inferred from the handlers the page passes in, so
 * /login and /register keep using the exact same component.
 */

interface AuthContentProps {
  image?: { src: string; alt: string };
  quote?: { text: string; author: string };
}

interface AuthUIProps {
  signInContent?: AuthContentProps;
  signUpContent?: AuthContentProps;
  onSignInSubmit?: (data: { email: string; password: string }) => void;
  onSignUpSubmit?: (data: {
    name: string;
    email: string;
    password: string;
    department?: string;
  }) => void;
  isLoading?: boolean;
  error?: string | null;
}

const highlights = [
  { icon: CalendarDays, label: "Leave requests & approvals" },
  { icon: ShieldCheck, label: "Department availability calendar" },
  { icon: Wallet, label: "Payroll and payslips" },
];

export function AuthUI({
  signInContent = {},
  signUpContent = {},
  onSignInSubmit,
  onSignUpSubmit,
  isLoading = false,
  error,
}: AuthUIProps) {
  // A page supplies exactly one handler; that decides the mode.
  const isSignIn = !onSignUpSubmit;
  const content = isSignIn ? signInContent : signUpContent;

  const [showPassword, setShowPassword] = useState(false);
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    department: "",
  });

  const update = (key: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((prev) => ({ ...prev, [key]: e.target.value }));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isLoading) return;

    if (isSignIn) {
      onSignInSubmit?.({ email: form.email.trim(), password: form.password.trim() });
    } else {
      onSignUpSubmit?.({
        name: form.name,
        email: form.email,
        password: form.password.trim(),
        department: form.department || undefined,
      });
    }
  };

  return (
    <div className="flex min-h-screen w-full">
      {/* ── Brand panel (desktop only) ─────────────────────── */}
      <aside className="relative hidden w-1/2 flex-col justify-between overflow-hidden p-12 lg:flex xl:w-[55%]">
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0 bg-[linear-gradient(150deg,rgba(124,92,255,0.22),rgba(217,70,239,0.12)_45%,rgba(34,211,238,0.16))]"
        />
        <div
          aria-hidden
          className="pointer-events-none absolute -left-24 top-1/4 h-96 w-96 rounded-full bg-[var(--accent-1)] opacity-30 blur-[110px]"
        />
        <div
          aria-hidden
          className="pointer-events-none absolute -right-16 bottom-0 h-80 w-80 rounded-full bg-[var(--accent-3)] opacity-25 blur-[110px]"
        />
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0 opacity-[0.4]"
          style={{
            backgroundImage:
              "linear-gradient(rgba(255,255,255,0.035) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.035) 1px, transparent 1px)",
            backgroundSize: "40px 40px",
            maskImage: "radial-gradient(80% 80% at 40% 40%, #000, transparent)",
            WebkitMaskImage: "radial-gradient(80% 80% at 40% 40%, #000, transparent)",
          }}
        />

        <Link href="/" className="relative flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[linear-gradient(135deg,var(--accent-1),var(--accent-2))] text-sm font-black text-white shadow-[0_8px_24px_-8px_var(--neu-accent-glow)]">
            AE
          </span>
          <span className="text-lg font-bold tracking-tight text-white">AttendEase</span>
        </Link>

        <div className="relative max-w-md">
          <h2 className="text-4xl font-black leading-[1.12] tracking-tight text-white">
            HR, leave and payroll
            <br />
            <span className="text-gradient-accent">without the spreadsheets.</span>
          </h2>

          <p className="mt-5 text-[0.95rem] leading-relaxed text-white/70">
            {content.quote?.text ??
              "One place for requests, approvals, team availability and monthly pay."}
          </p>

          <ul className="mt-8 space-y-3">
            {highlights.map(({ icon: Icon, label }) => (
              <li key={label} className="flex items-center gap-3 text-sm text-white/80">
                <span className="flex h-9 w-9 items-center justify-center rounded-xl border border-white/15 bg-white/10 backdrop-blur-sm">
                  <Icon className="h-4 w-4" />
                </span>
                {label}
              </li>
            ))}
          </ul>
        </div>

        <p className="relative text-xs text-white/45">
          {content.quote?.author ?? "AttendEase Team"}
        </p>
      </aside>

      {/* ── Form panel ─────────────────────────────────────── */}
      <main className="relative flex w-full flex-col justify-center px-5 py-10 sm:px-10 lg:w-1/2 xl:w-[45%]">
        <Link
          href="/"
          className="absolute left-5 top-6 inline-flex items-center gap-1.5 text-sm font-medium text-[var(--neu-text-muted)] transition-colors hover:text-[var(--neu-text)] sm:left-10"
        >
          <ArrowLeft className="h-4 w-4" />
          Back
        </Link>

        <div className="mx-auto w-full max-w-md">
          {/* Mobile brand mark */}
          <div className="mb-8 flex items-center gap-2.5 lg:hidden">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[linear-gradient(135deg,var(--accent-1),var(--accent-2))] text-sm font-black text-white">
              AE
            </span>
            <span className="text-base font-bold tracking-tight">AttendEase</span>
          </div>

          <span className="eyebrow mb-4">
            {isSignIn ? "Sign in" : "Create account"}
          </span>

          <h1 className="text-3xl font-bold tracking-tight text-[var(--neu-text)]">
            {isSignIn ? "Welcome back" : "Get started"}
          </h1>
          <p className="mt-2 text-sm text-[var(--neu-text-secondary)]">
            {isSignIn
              ? "Sign in and we'll take you to the right portal."
              : "Register to apply for leave and view your payslips."}
          </p>

          {error && (
            <div
              role="alert"
              className="mt-6 flex items-start gap-2.5 rounded-xl border border-[rgba(255,107,129,0.35)] bg-[rgba(255,107,129,0.1)] px-4 py-3"
            >
              <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-[var(--neu-danger)]" />
              <p className="text-sm text-[var(--neu-danger)]">{error}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="mt-7 space-y-4">
            {!isSignIn && (
              <NeuInput
                label="Full name"
                type="text"
                required
                autoComplete="name"
                placeholder="Jane Tan"
                icon={<UserIcon className="h-4 w-4" />}
                value={form.name}
                onChange={update("name")}
              />
            )}

            <NeuInput
              label={isSignIn ? "Email or Employee ID" : "Email"}
              type={isSignIn ? "text" : "email"}
              required
              autoComplete={isSignIn ? "username" : "email"}
              placeholder={isSignIn ? "you@company.com or EMP-001" : "you@company.com"}
              icon={<Mail className="h-4 w-4" />}
              value={form.email}
              onChange={update("email")}
            />

            {!isSignIn && (
              <NeuInput
                label="Department"
                type="text"
                placeholder="Engineering"
                hint="Optional — HR can assign this later."
                icon={<Building2 className="h-4 w-4" />}
                value={form.department}
                onChange={update("department")}
              />
            )}

            <div className="relative">
              <NeuInput
                label="Password"
                type={showPassword ? "text" : "password"}
                required
                autoComplete={isSignIn ? "current-password" : "new-password"}
                placeholder="••••••••"
                icon={<Lock className="h-4 w-4" />}
                className="pr-11"
                value={form.password}
                onChange={update("password")}
              />
              <button
                type="button"
                onClick={() => setShowPassword((v) => !v)}
                aria-label={showPassword ? "Hide password" : "Show password"}
                className="absolute right-3 top-[2.35rem] flex h-8 w-8 items-center justify-center rounded-lg text-[var(--neu-text-muted)] transition-all duration-200 hover:scale-110 hover:rotate-6 hover:bg-white/[0.05] hover:text-[var(--neu-accent)]"
              >
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>

            {isSignIn && (
              <div className="-mt-1 flex justify-end">
                <Link
                  href="/forgot-password"
                  className="group/forgot inline-flex items-center gap-1.5 text-xs font-semibold text-[var(--neu-text-secondary)] transition-colors hover:text-[var(--neu-accent)]"
                >
                  <KeyRound className="h-3.5 w-3.5 transition-transform duration-200 group-hover/forgot:-rotate-12 group-hover/forgot:scale-110" />
                  Forgot password?
                </Link>
              </div>
            )}

            <NeuButton type="submit" size="full" loading={isLoading} className="mt-2">
              {isSignIn ? "Sign in" : "Create account"}
              {!isLoading && <ArrowRight className="h-4 w-4" />}
            </NeuButton>
          </form>

          <p className="mt-7 text-center text-sm text-[var(--neu-text-secondary)]">
            {isSignIn ? "Don't have an account? " : "Already registered? "}
            <Link
              href={isSignIn ? "/register" : "/login"}
              className={cn(
                "font-semibold text-[var(--neu-accent)] underline-offset-4",
                "transition-colors hover:underline"
              )}
            >
              {isSignIn ? "Register" : "Sign in"}
            </Link>
          </p>
        </div>
      </main>
    </div>
  );
}

export type { AuthUIProps, AuthContentProps };
