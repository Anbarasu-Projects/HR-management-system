"use client";

import * as React from "react";
import { cn } from "@/lib/utils";

type CardVariant = "raised" | "flat" | "inset" | "accent";

interface NeuCardContextValue {
  variant: CardVariant;
}

const NeuCardContext = React.createContext<NeuCardContextValue>({ variant: "raised" });

interface NeuCardProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: CardVariant;
  hover?: boolean;
  /** Adds an animated light sweep on hover. */
  sheen?: boolean;
  /** Adds a soft coloured aura behind the card. */
  glow?: boolean;
  children: React.ReactNode;
}

const variantStyles: Record<CardVariant, string> = {
  // Default frosted panel with a gradient hairline edge.
  raised: "glass gradient-border",
  // Quieter surface for nesting inside another card.
  flat: "bg-white/[0.03] border border-[var(--neu-border)] backdrop-blur-md",
  // Recessed well, used for inputs, code blocks and empty states.
  inset:
    "bg-black/25 border border-white/[0.06] shadow-[inset_0_2px_10px_rgba(0,0,0,0.45)]",
  // Hero card that leans on the portal accent.
  accent:
    "gradient-border backdrop-blur-xl border border-transparent bg-[linear-gradient(150deg,rgba(var(--accent-rgb),0.16),rgba(var(--accent-rgb),0.04)_45%,rgba(255,255,255,0.02))]",
};

const NeuCard = React.forwardRef<HTMLDivElement, NeuCardProps>(
  (
    { className, variant = "raised", hover = false, sheen = false, glow = false, children, ...props },
    ref
  ) => {
    return (
      <NeuCardContext.Provider value={{ variant }}>
        <div
          ref={ref}
          className={cn(
            "relative rounded-[var(--neu-radius)] p-6",
            "transition-[transform,box-shadow,border-color] duration-300 ease-out",
            variantStyles[variant],
            glow && "accent-glow",
            sheen && "hover-sheen",
            hover &&
              "hover:-translate-y-1 hover:shadow-[0_16px_44px_-12px_var(--neu-accent-glow),var(--elev-3)]",
            className
          )}
          {...props}
        >
          {children}
        </div>
      </NeuCardContext.Provider>
    );
  }
);

NeuCard.displayName = "NeuCard";

interface NeuCardHeaderProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
}

const NeuCardHeader = React.forwardRef<HTMLDivElement, NeuCardHeaderProps>(
  ({ className, children, ...props }, ref) => {
    return (
      <div
        ref={ref}
        className={cn(
          "relative pb-4 mb-5",
          // Fading rule instead of a hard border reads softer against glass.
          "after:absolute after:bottom-0 after:left-0 after:h-px after:w-full",
          "after:bg-[linear-gradient(90deg,rgba(var(--accent-rgb),0.5),rgba(255,255,255,0.08)_35%,transparent)]",
          className
        )}
        {...props}
      >
        {children}
      </div>
    );
  }
);

NeuCardHeader.displayName = "NeuCardHeader";

interface NeuCardTitleProps extends React.HTMLAttributes<HTMLHeadingElement> {
  children: React.ReactNode;
  as?: "h1" | "h2" | "h3" | "h4" | "h5" | "h6";
}

const NeuCardTitle = React.forwardRef<HTMLHeadingElement, NeuCardTitleProps>(
  ({ className, children, as: Component = "h3", ...props }, ref) => {
    return (
      <Component
        ref={ref}
        className={cn(
          "text-lg font-semibold tracking-tight text-[var(--neu-text)]",
          className
        )}
        {...props}
      >
        {children}
      </Component>
    );
  }
);

NeuCardTitle.displayName = "NeuCardTitle";

interface NeuCardDescriptionProps extends React.HTMLAttributes<HTMLParagraphElement> {
  children: React.ReactNode;
}

const NeuCardDescription = React.forwardRef<HTMLParagraphElement, NeuCardDescriptionProps>(
  ({ className, children, ...props }, ref) => {
    return (
      <p
        ref={ref}
        className={cn("text-sm leading-relaxed text-[var(--neu-text-secondary)] mt-1.5", className)}
        {...props}
      >
        {children}
      </p>
    );
  }
);

NeuCardDescription.displayName = "NeuCardDescription";

interface NeuCardContentProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
}

const NeuCardContent = React.forwardRef<HTMLDivElement, NeuCardContentProps>(
  ({ className, children, ...props }, ref) => {
    return (
      <div ref={ref} className={cn("", className)} {...props}>
        {children}
      </div>
    );
  }
);

NeuCardContent.displayName = "NeuCardContent";

interface NeuCardFooterProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
}

const NeuCardFooter = React.forwardRef<HTMLDivElement, NeuCardFooterProps>(
  ({ className, children, ...props }, ref) => {
    return (
      <div
        ref={ref}
        className={cn("pt-4 mt-5 border-t border-white/[0.07]", className)}
        {...props}
      >
        {children}
      </div>
    );
  }
);

NeuCardFooter.displayName = "NeuCardFooter";

export {
  NeuCard,
  NeuCardHeader,
  NeuCardTitle,
  NeuCardDescription,
  NeuCardContent,
  NeuCardFooter,
  type NeuCardProps,
  type CardVariant,
};
