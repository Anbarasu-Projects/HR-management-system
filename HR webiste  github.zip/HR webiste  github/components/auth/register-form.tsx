"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  Building2,
  CheckCircle2,
  Clock3,
  Eye,
  EyeOff,
  Lock,
  Mail,
  ShieldCheck,
  User,
  UserPlus,
} from "lucide-react";
import {
  NeuCard,
  NeuCardHeader,
  NeuCardTitle,
  NeuCardDescription,
  NeuCardContent,
  NeuCardFooter,
} from "@/components/ui/neu-card";
import { NeuInput } from "@/components/ui/neu-input";
import { NeuSelect } from "@/components/ui/neu-select";
import { NeuButton } from "@/components/ui/neu-button";

interface RegisterFormData {
  name: string;
  email: string;
  password: string;
  confirmPassword: string;
  department: string;
}

interface RegisterResponse {
  success: boolean;
  message?: string;
  error?: string;
  code?: string;
  data?: {
    user: {
      id: string;
      name: string;
      role: string;
    };
    requiresApproval?: boolean;
  };
}

const departmentOptions = [
  { value: "", label: "Select Department (Optional)" },
  { value: "Engineering", label: "Engineering" },
  { value: "Design", label: "Design" },
  { value: "Marketing", label: "Marketing" },
  { value: "Sales", label: "Sales" },
  { value: "HR", label: "Human Resources" },
  { value: "Finance", label: "Finance" },
  { value: "Operations", label: "Operations" },
  { value: "Management", label: "Management" },
  { value: "Other", label: "Other" },
];

export default function RegisterForm() {
  const router = useRouter();
  const [formData, setFormData] = useState<RegisterFormData>({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    department: "",
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submittedForApproval, setSubmittedForApproval] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (error) setError(null);
  };

  const validateForm = (): boolean => {
    if (!formData.name.trim()) {
      setError("Name is required");
      return false;
    }
    if (!formData.email.trim()) {
      setError("Email is required");
      return false;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      setError("Please enter a valid email address");
      return false;
    }
    if (!formData.password) {
      setError("Password is required");
      return false;
    }
    if (formData.password.length < 6) {
      setError("Password must be at least 6 characters long");
      return false;
    }
    if (formData.password !== formData.confirmPassword) {
      setError("Passwords do not match");
      return false;
    }
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          password: formData.password,
          department: formData.department || undefined,
        }),
      });

      const data: RegisterResponse = await response.json();

      if (!response.ok || !data.success) {
        setError(data.error || "Registration failed. Please try again.");
        return;
      }

      if (data.data?.requiresApproval) {
        setSubmittedForApproval(true);
      } else {
        router.push("/login");
      }
    } catch (err) {
      setError("An unexpected error occurred. Please try again.");
      console.error("Registration error:", err);
    } finally {
      setIsLoading(false);
    }
  };

  if (submittedForApproval) {
    return (
      <NeuCard className="w-full max-w-md mx-auto">
        <NeuCardHeader className="text-center pt-10">
          <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-2xl border border-[var(--neu-warning)]/25 bg-[var(--neu-warning)]/10 text-[var(--neu-warning)] shadow-[0_0_24px_rgba(245,158,11,0.12)]">
            <Clock3 size={30} />
          </div>
          <NeuCardTitle className="text-2xl">Waiting for Approval</NeuCardTitle>
          <NeuCardDescription>
            Your registration request has been sent to the administrator.
          </NeuCardDescription>
        </NeuCardHeader>
        <NeuCardContent>
          <div className="space-y-3 rounded-xl border border-white/[0.07] bg-white/[0.025] p-4 text-sm text-[var(--neu-text-secondary)]">
            <div className="flex items-start gap-2.5">
              <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-[var(--neu-success)]" />
              <span>Your account details were received successfully.</span>
            </div>
            <div className="flex items-start gap-2.5">
              <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-[var(--neu-accent)]" />
              <span>An admin must approve the account before you can sign in.</span>
            </div>
          </div>
        </NeuCardContent>
        <NeuCardFooter className="flex flex-col gap-3">
          <Link href="/login" className="w-full">
            <NeuButton variant="accent" size="lg" className="w-full">
              Go to Login
            </NeuButton>
          </Link>
          <p className="text-center text-xs text-[var(--neu-text-muted)]">
            If you try to sign in before approval, AttendEase will show that your account is still pending.
          </p>
        </NeuCardFooter>
      </NeuCard>
    );
  }

  return (
    <NeuCard className="w-full max-w-md mx-auto">
      <NeuCardHeader className="text-center pt-8">
        <div className="flex justify-center mb-5">
          <div className="relative rounded-3xl border border-white/[0.08] bg-black/20 px-5 py-3 shadow-lg backdrop-blur-sm">
            <img src="/logo.png" alt="AttendEase Logo" className="h-16 w-auto object-contain" />
            <span className="absolute -bottom-2 -right-2 flex h-8 w-8 items-center justify-center rounded-full border border-[var(--neu-accent)]/30 bg-[var(--neu-surface)] text-[var(--neu-accent)] shadow-lg">
              <UserPlus size={16} />
            </span>
          </div>
        </div>
        <NeuCardTitle className="text-2xl">Create Account</NeuCardTitle>
        <NeuCardDescription>
          Register your details and send them for admin approval
        </NeuCardDescription>
      </NeuCardHeader>

      <form onSubmit={handleSubmit}>
        <NeuCardContent className="space-y-4">
          {error && (
            <div className="rounded-xl border border-[var(--neu-danger)]/30 bg-[var(--neu-danger)]/10 p-3 text-sm text-[var(--neu-danger)]">
              {error}
            </div>
          )}

          <NeuInput
            label="Full Name"
            name="name"
            type="text"
            placeholder="Enter your full name"
            value={formData.name}
            onChange={handleChange}
            icon={<User size={18} />}
            disabled={isLoading}
            required
          />

          <NeuInput
            label="Email"
            name="email"
            type="email"
            placeholder="Enter your email"
            value={formData.email}
            onChange={handleChange}
            icon={<Mail size={18} />}
            disabled={isLoading}
            required
          />

          <div className="relative">
            <NeuInput
              label="Password"
              name="password"
              type={showPassword ? "text" : "password"}
              placeholder="Create a password (min 6 chars)"
              value={formData.password}
              onChange={handleChange}
              icon={<Lock size={18} />}
              disabled={isLoading}
              required
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-[2.25rem] text-[var(--neu-text-muted)] transition-colors hover:text-[var(--neu-text)]"
              tabIndex={-1}
              aria-label={showPassword ? "Hide password" : "Show password"}
            >
              {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
            </button>
          </div>

          <div className="relative">
            <NeuInput
              label="Confirm Password"
              name="confirmPassword"
              type={showConfirmPassword ? "text" : "password"}
              placeholder="Confirm your password"
              value={formData.confirmPassword}
              onChange={handleChange}
              icon={<Lock size={18} />}
              disabled={isLoading}
              required
            />
            <button
              type="button"
              onClick={() => setShowConfirmPassword(!showConfirmPassword)}
              className="absolute right-3 top-[2.25rem] text-[var(--neu-text-muted)] transition-colors hover:text-[var(--neu-text)]"
              tabIndex={-1}
              aria-label={showConfirmPassword ? "Hide password" : "Show password"}
            >
              {showConfirmPassword ? <EyeOff size={18} /> : <Eye size={18} />}
            </button>
          </div>

          <NeuSelect
            label="Department"
            name="department"
            options={departmentOptions}
            value={formData.department}
            onChange={handleChange}
            disabled={isLoading}
          />

          <div className="flex items-start gap-2 rounded-xl border border-[var(--neu-accent)]/15 bg-[var(--neu-accent)]/5 p-3 text-xs text-[var(--neu-text-secondary)]">
            <Building2 className="mt-0.5 h-4 w-4 shrink-0 text-[var(--neu-accent)]" />
            <span>After registration, an administrator will review and approve or reject your account.</span>
          </div>
        </NeuCardContent>

        <NeuCardFooter className="flex flex-col gap-4">
          <NeuButton
            type="submit"
            variant="accent"
            size="lg"
            loading={isLoading}
            className="w-full"
          >
            <UserPlus size={17} />
            Submit Registration
          </NeuButton>

          <p className="text-sm text-[var(--neu-text-secondary)] text-center">
            Already have an account?{" "}
            <Link
              href="/login"
              className="font-medium text-[var(--neu-accent)] transition-colors hover:text-[var(--neu-accent-hover)]"
            >
              Login
            </Link>
          </p>
        </NeuCardFooter>
      </form>
    </NeuCard>
  );
}
