"use client";

import { useState } from "react";
import Link from "next/link";
import { ArrowLeft, CheckCircle2, Eye, EyeOff, LockKeyhole, ShieldCheck } from "lucide-react";
import { NeuInput } from "@/components/ui/neu-input";
import { NeuButton } from "@/components/ui/neu-button";

export function ResetPasswordForm({ token }: { token: string }) {
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [complete, setComplete] = useState(false);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setError(null);

    if (!token) {
      setError("This reset link is missing its security token. Request a new link.");
      return;
    }
    if (password.length < 6) {
      setError("Password must be at least 6 characters long.");
      return;
    }
    if (password !== confirmPassword) {
      setError("The passwords do not match.");
      return;
    }

    setLoading(true);
    try {
      const response = await fetch("/api/auth/reset-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, password }),
      });
      const data = await response.json();
      if (!response.ok || !data.success) {
        setError(data.error || "Could not update your password.");
      } else {
        setComplete(true);
      }
    } catch {
      setError("Could not connect to the server. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="relative flex min-h-screen items-center justify-center px-5 py-12">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_25%,rgba(34,211,238,0.14),transparent_38%)]" />
      <section className="glass-strong gradient-border relative w-full max-w-md rounded-[1.5rem] p-6 sm:p-8">
        <Link href="/login" className="mb-7 inline-flex items-center gap-1.5 text-sm font-medium text-[var(--neu-text-muted)] transition-colors hover:text-[var(--neu-text)]">
          <ArrowLeft className="h-4 w-4" /> Back to login
        </Link>

        {complete ? (
          <div className="text-center">
            <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-2xl border border-[var(--neu-success)]/30 bg-[var(--neu-success)]/10 text-[var(--neu-success)] animate-pulse-ring">
              <CheckCircle2 className="h-7 w-7" />
            </div>
            <h1 className="text-2xl font-bold text-[var(--neu-text)]">Password updated</h1>
            <p className="mt-2 text-sm text-[var(--neu-text-secondary)]">You can now sign in using your new password.</p>
            <Link href="/login" className="mt-6 inline-flex min-h-11 w-full items-center justify-center rounded-xl bg-[linear-gradient(135deg,var(--accent-1),var(--accent-2))] px-4 font-semibold text-white shadow-[0_8px_24px_-8px_var(--neu-accent-glow)]">
              Return to sign in
            </Link>
          </div>
        ) : (
          <>
            <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-2xl border border-[var(--neu-accent)]/30 bg-[var(--neu-accent)]/10 text-[var(--neu-accent)] shadow-[0_0_24px_rgba(var(--accent-rgb),0.18)] animate-float">
              <LockKeyhole className="h-6 w-6" />
            </div>
            <span className="eyebrow mb-3"><ShieldCheck className="h-3.5 w-3.5" /> Secure reset</span>
            <h1 className="text-3xl font-bold tracking-tight text-[var(--neu-text)]">Choose a new password</h1>
            <p className="mt-2 text-sm text-[var(--neu-text-secondary)]">Use at least 6 characters and make sure both passwords match.</p>

            {error && <div className="mt-5 rounded-xl border border-[var(--neu-danger)]/30 bg-[var(--neu-danger)]/10 px-4 py-3 text-sm text-[var(--neu-danger)]">{error}</div>}

            <form onSubmit={submit} className="mt-6 space-y-4">
              <div className="relative">
                <NeuInput
                  label="New password"
                  type={showPassword ? "text" : "password"}
                  autoComplete="new-password"
                  placeholder="Enter your new password"
                  value={password}
                  onChange={(event) => setPassword(event.target.value)}
                  icon={<LockKeyhole className="h-4 w-4" />}
                  className="pr-12"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((value) => !value)}
                  className="absolute right-3 top-[2.35rem] flex h-8 w-8 items-center justify-center rounded-lg text-[var(--neu-text-muted)] transition-all hover:scale-110 hover:text-[var(--neu-accent)]"
                  aria-label={showPassword ? "Hide password" : "Show password"}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
              <NeuInput
                label="Confirm new password"
                type={showPassword ? "text" : "password"}
                autoComplete="new-password"
                placeholder="Repeat your new password"
                value={confirmPassword}
                onChange={(event) => setConfirmPassword(event.target.value)}
                icon={<ShieldCheck className="h-4 w-4" />}
                required
              />
              <NeuButton type="submit" size="full" loading={loading}>Update password</NeuButton>
            </form>
          </>
        )}
      </section>
    </main>
  );
}
