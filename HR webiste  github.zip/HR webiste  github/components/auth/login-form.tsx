"use client";

import { useState } from "react";
import Link from "next/link";
import {
  BadgeCheck,
  Eye,
  EyeOff,
  KeyRound,
  ShieldCheck,
  UserRound,
} from "lucide-react";
import {
  NeuCard,
  NeuCardHeader,
  NeuCardTitle,
  NeuCardDescription,
  NeuCardContent,
  NeuCardFooter,
} from "@/components/ui/neu-card";
import { NeuInput } from "@/components/ui/neu-input";
import { NeuButton } from "@/components/ui/neu-button";

interface LoginFormData {
  email: string;
  password: string;
}

interface LoginResponse {
  success: boolean;
  message?: string;
  error?: string;
  code?: string;
  data?: {
    user: {
      id: string;
      name: string;
      role: "admin" | "employee";
    };
    token: string;
  };
}

function LoginIcon({ children }: { children: React.ReactNode }) {
  return (
    <span className="flex h-7 w-7 items-center justify-center rounded-lg border border-[var(--neu-accent)]/25 bg-[var(--neu-accent)]/10 text-[var(--neu-accent)] shadow-[0_0_16px_rgba(var(--accent-rgb),0.16)]">
      {children}
    </span>
  );
}

export default function LoginForm() {
  const [formData, setFormData] = useState<LoginFormData>({
    email: "",
    password: "",
  });
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (error) setError(null);
  };

  const validateForm = (): boolean => {
    if (!formData.email.trim()) {
      setError("Email or Employee ID is required");
      return false;
    }
    if (!formData.password) {
      setError("Password is required");
      return false;
    }
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      const data: LoginResponse = await response.json();

      if (!response.ok || !data.success) {
        setError(data.error || "Login failed. Please try again.");
        return;
      }

      const userRole = data.data?.user?.role;
      window.location.href = userRole === "admin" ? "/admin" : "/employee";
    } catch (err) {
      setError("An unexpected error occurred. Please try again.");
      console.error("Login error:", err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <NeuCard className="w-full max-w-md mx-auto overflow-visible">
      <NeuCardHeader className="text-center pt-8">
        <div className="flex justify-center mb-5">
          <div className="relative">
            <div className="absolute inset-0 rounded-3xl bg-[var(--neu-accent)]/20 blur-xl" />
            <div className="relative rounded-3xl border border-white/[0.08] bg-black/20 px-5 py-3 shadow-lg backdrop-blur-sm">
              <img src="/logo.png" alt="AttendEase Logo" className="h-16 w-auto object-contain" />
            </div>
            <span className="absolute -bottom-2 -right-2 flex h-8 w-8 items-center justify-center rounded-full border border-[var(--neu-accent)]/30 bg-[var(--neu-surface)] text-[var(--neu-accent)] shadow-lg">
              <BadgeCheck size={17} />
            </span>
          </div>
        </div>
        <NeuCardTitle className="text-2xl">Welcome Back</NeuCardTitle>
        <NeuCardDescription>
          Secure access to your AttendEase workspace
        </NeuCardDescription>
        <div className="mx-auto mt-3 inline-flex items-center gap-1.5 rounded-full border border-[var(--neu-accent)]/15 bg-[var(--neu-accent)]/5 px-3 py-1 text-xs font-medium text-[var(--neu-accent)]">
          <ShieldCheck size={13} />
          Protected sign in
        </div>
      </NeuCardHeader>

      <form onSubmit={handleSubmit}>
        <NeuCardContent className="space-y-4">
          {error && (
            <div className="rounded-xl border border-[var(--neu-danger)]/30 bg-[var(--neu-danger)]/10 p-3 text-sm text-[var(--neu-danger)]">
              {error}
            </div>
          )}

          <NeuInput
            label="Email / Employee ID"
            name="email"
            type="text"
            autoComplete="username"
            placeholder="you@company.com or EMP-002"
            value={formData.email}
            onChange={handleChange}
            icon={
              <LoginIcon>
                <UserRound size={15} strokeWidth={2.2} />
              </LoginIcon>
            }
            className="pl-14"
            disabled={isLoading}
            required
          />

          <div className="relative">
            <NeuInput
              label="Password"
              name="password"
              type={showPassword ? "text" : "password"}
              autoComplete="current-password"
              placeholder="Enter your password"
              value={formData.password}
              onChange={handleChange}
              icon={
                <LoginIcon>
                  <KeyRound size={15} strokeWidth={2.2} />
                </LoginIcon>
              }
              className="pl-14 pr-11"
              disabled={isLoading}
              required
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-[2.25rem] rounded-lg p-1 text-[var(--neu-text-muted)] transition-colors hover:bg-white/5 hover:text-[var(--neu-accent)]"
              tabIndex={-1}
              aria-label={showPassword ? "Hide password" : "Show password"}
            >
              {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
            </button>
          </div>
        </NeuCardContent>

        <NeuCardFooter className="flex flex-col gap-4">
          <NeuButton
            type="submit"
            variant="accent"
            size="lg"
            loading={isLoading}
            className="w-full shadow-[0_0_24px_-8px_var(--neu-accent)]"
          >
            <ShieldCheck size={17} />
            Sign In
          </NeuButton>

          <p className="text-sm text-[var(--neu-text-secondary)] text-center">
            Don&apos;t have an account?{" "}
            <Link
              href="/register"
              className="font-medium text-[var(--neu-accent)] transition-colors hover:text-[var(--neu-accent-hover)]"
            >
              Register
            </Link>
          </p>
        </NeuCardFooter>
      </form>
    </NeuCard>
  );
}
