"use client";

import { useState } from "react";
import Link from "next/link";
import { ArrowLeft, ArrowRight, KeyRound, Mail, ShieldCheck } from "lucide-react";
import { NeuInput } from "@/components/ui/neu-input";
import { NeuButton } from "@/components/ui/neu-button";

interface ForgotResponse {
  success: boolean;
  message?: string;
  error?: string;
  devResetUrl?: string;
}

export default function ForgotPasswordPage() {
  const [identifier, setIdentifier] = useState("");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [devResetUrl, setDevResetUrl] = useState<string | null>(null);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setLoading(true);
    setError(null);
    setMessage(null);
    setDevResetUrl(null);

    try {
      const response = await fetch("/api/auth/forgot-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ identifier }),
      });
      const data: ForgotResponse = await response.json();
      if (!response.ok || !data.success) {
        setError(data.error || "Could not prepare a password reset.");
      } else {
        setMessage(data.message || "Password reset instructions are ready.");
        setDevResetUrl(data.devResetUrl || null);
      }
    } catch {
      setError("Could not connect to the server. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="relative flex min-h-screen items-center justify-center px-5 py-12">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_25%,rgba(124,92,255,0.16),transparent_38%)]" />
      <section className="glass-strong gradient-border relative w-full max-w-md rounded-[1.5rem] p-6 sm:p-8">
        <Link
          href="/login"
          className="mb-7 inline-flex items-center gap-1.5 text-sm font-medium text-[var(--neu-text-muted)] transition-colors hover:text-[var(--neu-text)]"
        >
          <ArrowLeft className="h-4 w-4" /> Back to login
        </Link>

        <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-2xl border border-[var(--neu-accent)]/30 bg-[var(--neu-accent)]/10 text-[var(--neu-accent)] shadow-[0_0_24px_rgba(var(--accent-rgb),0.18)] animate-float">
          <KeyRound className="h-6 w-6" />
        </div>

        <span className="eyebrow mb-3"><ShieldCheck className="h-3.5 w-3.5" /> Account recovery</span>
        <h1 className="text-3xl font-bold tracking-tight text-[var(--neu-text)]">Forgot your password?</h1>
        <p className="mt-2 text-sm leading-relaxed text-[var(--neu-text-secondary)]">
          Enter your email or Employee ID. We&apos;ll create a secure reset link that expires after 30 minutes.
        </p>

        {error && (
          <div className="mt-5 rounded-xl border border-[var(--neu-danger)]/30 bg-[var(--neu-danger)]/10 px-4 py-3 text-sm text-[var(--neu-danger)]">{error}</div>
        )}
        {message && (
          <div className="mt-5 rounded-xl border border-[var(--neu-success)]/25 bg-[var(--neu-success)]/10 px-4 py-3 text-sm text-[var(--neu-text)]">{message}</div>
        )}

        <form onSubmit={submit} className="mt-6 space-y-4">
          <NeuInput
            label="Email or Employee ID"
            type="text"
            autoComplete="username"
            placeholder="you@company.com or EMP-002"
            value={identifier}
            onChange={(event) => setIdentifier(event.target.value)}
            icon={<Mail className="h-4 w-4" />}
            required
            disabled={loading}
          />
          <NeuButton type="submit" size="full" loading={loading}>
            Create reset link
            {!loading && <ArrowRight className="h-4 w-4" />}
          </NeuButton>
        </form>

        {devResetUrl && (
          <Link
            href={devResetUrl}
            className="mt-4 flex items-center justify-center rounded-xl border border-[var(--neu-warning)]/25 bg-[var(--neu-warning)]/10 px-4 py-3 text-sm font-semibold text-[var(--neu-warning)] transition-transform hover:scale-[1.01]"
          >
            Open development reset link
          </Link>
        )}
      </section>
    </main>
  );
}
