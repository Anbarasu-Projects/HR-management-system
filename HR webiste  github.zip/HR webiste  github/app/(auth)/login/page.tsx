"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { AuthUI } from "@/components/ui/auth-fuse";
import { clearCurrentUserCache, getCurrentUser } from "@/lib/client-user";

interface LoginResponse {
  success: boolean;
  message?: string;
  error?: string;
  data?: {
    user: {
      id: string;
      name: string;
      role: "admin" | "employee";
    };
    token: string;
  };
}

export default function LoginPage() {
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSignIn = async (data: { email: string; password: string }) => {
    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });

      const result: LoginResponse = await response.json();

      if (!response.ok || !result.success) {
        setError(result.error || "Login failed. Please try again.");
        setIsLoading(false);
        return;
      }

      // A login can replace another user's cookie in the same tab. Clear any
      // previous in-memory profile, then fetch the newly authenticated user
      // before entering the portal so Akash/Michael-style identity carry-over
      // cannot occur.
      clearCurrentUserCache();
      await getCurrentUser(true);

      const userRole = result.data?.user?.role;
      router.replace(userRole === "admin" ? "/admin" : "/employee");
      router.refresh();
    } catch (err) {
      setError("An unexpected error occurred. Please try again.");
      console.error("Login error:", err);
      setIsLoading(false);
    }
  };

  return (
    <AuthUI
      onSignInSubmit={handleSignIn}
      isLoading={isLoading}
      error={error}
      signInContent={{
        quote: {
          text: "Welcome back! Track attendance, manage leaves, and streamline your workflow.",
          author: "AttendEase Team"
        }
      }}
    />
  );
}
