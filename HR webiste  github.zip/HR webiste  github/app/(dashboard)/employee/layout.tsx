"use client";

import { EmployeeSidebar } from "@/components/layout/employee-sidebar";
import { Header } from "@/components/layout/header";
import { useSidebar } from "@/lib/SidebarContext";
import { cn } from "@/lib/utils";

export default function EmployeeLayout({ children }: { children: React.ReactNode }) {
  const { isEmployeeCollapsed: isCollapsed } = useSidebar();

  return (
    // data-portal drives the cyan/teal accent ramp for every child.
    <div data-portal="employee" className="relative z-10 flex min-h-screen bg-transparent">
      <EmployeeSidebar />
      <div
        className={cn(
          "min-w-0 flex-1 transition-[margin] duration-300",
          "ml-0",
          isCollapsed ? "lg:ml-20" : "lg:ml-64"
        )}
      >
        <Header />
        <main className="mx-auto w-full max-w-[1600px] p-3 sm:p-5 md:p-7">{children}</main>
      </div>
    </div>
  );
}
