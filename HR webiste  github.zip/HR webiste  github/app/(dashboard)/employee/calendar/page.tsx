"use client";

import { CalendarRange } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { DepartmentCalendar } from "@/components/leave/department-calendar";

export default function EmployeeCalendarPage() {
  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Team availability"
        icon={<CalendarRange className="h-6 w-6" />}
        title="Department Calendar"
        description="See which colleagues are already on approved leave before you plan your own."
      />

      {/* Employees are scoped to their own department by the API. */}
      <DepartmentCalendar />
    </div>
  );
}
