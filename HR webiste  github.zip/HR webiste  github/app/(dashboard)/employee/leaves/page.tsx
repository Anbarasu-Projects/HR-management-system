"use client";

import { useEffect, useState } from "react";
import { NeuCard, NeuCardContent } from "@/components/ui/neu-card";
import { NeuButton } from "@/components/ui/neu-button";
import { Spinner } from "@/components/ui/spinner";
import { EmptyState } from "@/components/ui/empty-state";
import { Calendar, XCircle, Clock, Paperclip, SunMedium } from "lucide-react";
import { List2 } from "@/components/ui/list-2";
import { NeuBadge } from "@/components/ui/neu-badge";
import { useToast } from "@/components/ui/neu-toast";
import { getCurrentUser } from "@/lib/client-user";

interface LeaveRequest {
  _id: string;
  leaveType: string;
  startDate: string;
  endDate: string;
  totalDays: number;
  durationType?: "full-day" | "half-day";
  startTime?: string;
  endTime?: string;
  medicalDocument?: { fileName?: string; mimeType?: string; size?: number };
  reason: string;
  status: "pending" | "approved" | "rejected";
}

interface LeaveBalance {
  annual: number;
  sick: number;
  casual: number;
}

const initialForm = {
  leaveType: "annual",
  durationType: "full-day" as "full-day" | "half-day",
  startDate: "",
  endDate: "",
  startTime: "09:00",
  endTime: "13:00",
  reason: "",
};

export default function EmployeeLeavesPage() {
  const [leaves, setLeaves] = useState<LeaveRequest[]>([]);
  const [balance, setBalance] = useState<LeaveBalance>({ annual: 0, sick: 0, casual: 0 });
  const [loading, setLoading] = useState(true);
  const [showApplyModal, setShowApplyModal] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [formData, setFormData] = useState(initialForm);
  const [medicalFile, setMedicalFile] = useState<File | null>(null);
  const { success: toastSuccess, error: toastError } = useToast();

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [leavesRes, currentUser] = await Promise.all([
        fetch("/api/leaves/my"),
        getCurrentUser(),
      ]);

      const leavesData = await leavesRes.json();

      if (leavesData.success) setLeaves(leavesData.data);
      if (currentUser?.leaveBalance) {
        setBalance(currentUser.leaveBalance);
      }
    } catch (error) {
      console.error("Failed to fetch data", error);
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setFormData(initialForm);
    setMedicalFile(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const body = new FormData();
      body.append("leaveType", formData.leaveType);
      body.append("durationType", formData.durationType);
      body.append("startDate", formData.startDate);
      body.append("endDate", formData.durationType === "half-day" ? formData.startDate : formData.endDate);
      body.append("reason", formData.reason);
      if (formData.durationType === "half-day") {
        body.append("startTime", formData.startTime);
        body.append("endTime", formData.endTime);
      }
      if (formData.leaveType === "sick" && medicalFile) {
        body.append("medicalDocument", medicalFile);
      }

      const response = await fetch("/api/leaves/apply", {
        method: "POST",
        body,
      });

      const result = await response.json();
      if (response.ok && result.success) {
        setShowApplyModal(false);
        resetForm();
        toastSuccess("Leave request submitted successfully");
        fetchData();
      } else {
        toastError(result.error || "Failed to apply for leave");
      }
    } catch (error) {
      console.error("Failed to apply for leave", error);
      toastError("An unexpected error occurred while submitting leave");
    } finally {
      setSubmitting(false);
    }
  };

  const handleCancel = async (id: string) => {
    try {
      const response = await fetch(`/api/leaves/my?id=${id}`, { method: "DELETE" });
      if (response.ok) {
        toastSuccess("Leave request cancelled");
        fetchData();
      }
    } catch (error) {
      console.error("Failed to cancel leave", error);
    }
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "approved": return "success" as const;
      case "rejected": return "error" as const;
      default: return "default" as const;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Spinner size="lg" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">Leave Management</h2>
          <p className="text-sm text-[var(--neu-text-secondary)] mt-1">
            Request full-day or half-day leave and track your balance
          </p>
        </div>
        <NeuButton onClick={() => setShowApplyModal(true)} variant="accent" className="w-full sm:w-auto">
          <Calendar className="w-4 h-4" />
          Apply for Leave
        </NeuButton>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <NeuCard><NeuCardContent className="p-4 text-center">
          <p className="text-sm text-[var(--neu-text-secondary)]">Annual Leave</p>
          <p className="text-3xl font-bold text-blue-600">{balance.annual}</p>
          <p className="text-xs text-[var(--neu-text-secondary)]">days remaining</p>
        </NeuCardContent></NeuCard>
        <NeuCard><NeuCardContent className="p-4 text-center">
          <p className="text-sm text-[var(--neu-text-secondary)]">Sick Leave</p>
          <p className="text-3xl font-bold text-green-600">{balance.sick}</p>
          <p className="text-xs text-[var(--neu-text-secondary)]">days remaining</p>
        </NeuCardContent></NeuCard>
        <NeuCard><NeuCardContent className="p-4 text-center">
          <p className="text-sm text-[var(--neu-text-secondary)]">Casual Leave</p>
          <p className="text-3xl font-bold text-purple-600">{balance.casual}</p>
          <p className="text-xs text-[var(--neu-text-secondary)]">days remaining</p>
        </NeuCardContent></NeuCard>
      </div>

      <NeuCard>
        <NeuCardContent className="p-6">
          <h3 className="text-lg font-semibold mb-4">Leave History</h3>
          {leaves.length === 0 ? (
            <EmptyState icon={Calendar} title="No leave requests" description="You haven't applied for any leave yet." />
          ) : (
            <List2 items={leaves.map((leave) => ({
              icon: <Calendar className="w-5 h-5 text-[var(--neu-accent)]" />,
              title: leave.leaveType.toUpperCase(),
              category: leave.durationType === "half-day" ? "HALF-DAY LEAVE" : "LEAVE REQUEST",
              description: (
                <div className="flex flex-col gap-1">
                  <div className="flex items-center gap-2 opacity-80 flex-wrap">
                    <Clock className="w-3.5 h-3.5" />
                    {leave.durationType === "half-day" ? (
                      <span>
                        {new Date(leave.startDate).toLocaleDateString()} · {leave.startTime}–{leave.endTime}
                      </span>
                    ) : (
                      <span>{new Date(leave.startDate).toLocaleDateString()} - {new Date(leave.endDate).toLocaleDateString()}</span>
                    )}
                    <span className="font-bold text-[var(--neu-accent)]">
                      ({leave.totalDays === 0.5 ? "Half Day" : `${leave.totalDays} Days`})
                    </span>
                  </div>
                  <div className="text-sm italic opacity-60 line-clamp-1">"{leave.reason}"</div>
                  {leave.medicalDocument?.fileName && (
                    <a
                      href={`/api/leaves/${leave._id}/document`}
                      className="inline-flex w-fit items-center gap-1 text-xs text-[var(--neu-accent)] hover:underline"
                    >
                      <Paperclip className="h-3.5 w-3.5" />
                      {leave.medicalDocument.fileName}
                    </a>
                  )}
                </div>
              ),
              status: (
                <div className="flex items-center gap-3">
                  <NeuBadge variant={getStatusBadgeVariant(leave.status)}>{leave.status}</NeuBadge>
                  {leave.status === "pending" && (
                    <NeuButton size="icon" variant="ghost" onClick={() => handleCancel(leave._id)} className="h-8 w-8 text-[var(--neu-danger)] hover:bg-[var(--neu-danger)]/10">
                      <XCircle className="w-4 h-4" />
                    </NeuButton>
                  )}
                </div>
              )
            }))} />
          )}
        </NeuCardContent>
      </NeuCard>

      {showApplyModal && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
          <div className="bg-[var(--neu-surface)] rounded-xl w-full max-w-lg max-h-[88vh] overflow-y-auto border border-[var(--neu-border)]">
            <div className="p-6">
              <h3 className="text-lg font-semibold mb-4">Apply for Leave</h3>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Leave Type</label>
                  <select
                    value={formData.leaveType}
                    onChange={(e) => {
                      setFormData({ ...formData, leaveType: e.target.value });
                      if (e.target.value !== "sick") setMedicalFile(null);
                    }}
                    className="w-full px-3 py-2 rounded-lg border border-[var(--neu-border)] bg-[var(--neu-bg)]"
                  >
                    <option value="annual">Annual Leave</option>
                    <option value="sick">Sick Leave</option>
                    <option value="casual">Casual Leave</option>
                    <option value="unpaid">Unpaid Leave</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">Duration</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setFormData({ ...formData, durationType: "full-day" })}
                      className={`rounded-lg border px-3 py-2.5 text-sm ${formData.durationType === "full-day" ? "border-[var(--neu-accent)] bg-[var(--neu-accent)]/10 text-[var(--neu-accent)]" : "border-[var(--neu-border)]"}`}
                    >
                      Full Day
                    </button>
                    <button
                      type="button"
                      onClick={() => setFormData({ ...formData, durationType: "half-day", endDate: formData.startDate })}
                      className={`rounded-lg border px-3 py-2.5 text-sm ${formData.durationType === "half-day" ? "border-[var(--neu-accent)] bg-[var(--neu-accent)]/10 text-[var(--neu-accent)]" : "border-[var(--neu-border)]"}`}
                    >
                      <SunMedium className="inline h-4 w-4 mr-1" /> Half Day
                    </button>
                  </div>
                </div>

                {formData.durationType === "half-day" ? (
                  <>
                    <div>
                      <label className="block text-sm font-medium mb-1">Leave Date</label>
                      <input
                        type="date"
                        value={formData.startDate}
                        onChange={(e) => setFormData({ ...formData, startDate: e.target.value, endDate: e.target.value })}
                        required
                        className="w-full px-3 py-2 rounded-lg border border-[var(--neu-border)] bg-[var(--neu-bg)]"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium mb-1">Start Time</label>
                        <input type="time" value={formData.startTime} onChange={(e) => setFormData({ ...formData, startTime: e.target.value })} required className="w-full px-3 py-2 rounded-lg border border-[var(--neu-border)] bg-[var(--neu-bg)]" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-1">End Time</label>
                        <input type="time" value={formData.endTime} onChange={(e) => setFormData({ ...formData, endTime: e.target.value })} required className="w-full px-3 py-2 rounded-lg border border-[var(--neu-border)] bg-[var(--neu-bg)]" />
                      </div>
                    </div>
                    <p className="text-xs text-[var(--neu-text-muted)]">Half-day leave deducts 0.5 day from the selected leave balance.</p>
                  </>
                ) : (
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-1">Start Date</label>
                      <input type="date" value={formData.startDate} onChange={(e) => setFormData({ ...formData, startDate: e.target.value })} required className="w-full px-3 py-2 rounded-lg border border-[var(--neu-border)] bg-[var(--neu-bg)]" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">End Date</label>
                      <input type="date" value={formData.endDate} onChange={(e) => setFormData({ ...formData, endDate: e.target.value })} required className="w-full px-3 py-2 rounded-lg border border-[var(--neu-border)] bg-[var(--neu-bg)]" />
                    </div>
                  </div>
                )}

                {formData.leaveType === "sick" && (
                  <div className="rounded-xl border border-[var(--neu-border)] bg-white/[0.025] p-4">
                    <label className="block text-sm font-medium mb-1">Doctor / Medical Document <span className="font-normal text-[var(--neu-text-muted)]">(optional)</span></label>
                    <input
                      type="file"
                      accept=".pdf,.jpg,.jpeg,.png,.doc,.docx,application/pdf,image/jpeg,image/png,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                      onChange={(e) => setMedicalFile(e.target.files?.[0] || null)}
                      className="block w-full text-sm file:mr-3 file:rounded-lg file:border-0 file:bg-[var(--neu-accent)]/10 file:px-3 file:py-2 file:text-[var(--neu-accent)]"
                    />
                    <p className="mt-1 text-xs text-[var(--neu-text-muted)]">PDF, JPG, PNG, DOC or DOCX · maximum 5 MB.</p>
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium mb-1">Reason</label>
                  <textarea value={formData.reason} onChange={(e) => setFormData({ ...formData, reason: e.target.value })} required rows={3} className="w-full px-3 py-2 rounded-lg border border-[var(--neu-border)] bg-[var(--neu-bg)]" />
                </div>

                <div className="flex gap-3 pt-2">
                  <NeuButton type="submit" variant="accent" loading={submitting} className="flex-1">Submit Request</NeuButton>
                  <NeuButton type="button" variant="ghost" onClick={() => { setShowApplyModal(false); resetForm(); }}>Cancel</NeuButton>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
