"use client";

import { useEffect, useMemo, useState } from "react";
import { NeuCard, NeuCardContent } from "@/components/ui/neu-card";
import { NeuButton } from "@/components/ui/neu-button";
import { Spinner } from "@/components/ui/spinner";
import { EmptyState } from "@/components/ui/empty-state";
import { FileText, Download, CheckCircle2 } from "lucide-react";

interface PayrollRecord {
  _id: string;
  userId: { _id: string; name: string; employeeId?: string };
  month: number;
  year: number;
  basicSalary: number;
  presentDays: number;
  absentDeduction: number;
  lateDeduction: number;
  unpaidLeaveDeduction: number;
  bonuses: number;
  netSalary: number;
  status: "finalized";
}

export default function EmployeePayslipPage() {
  const now = new Date();
  const [payroll, setPayroll] = useState<PayrollRecord[]>([]);
  const [month, setMonth] = useState(now.getMonth() + 1);
  const [year, setYear] = useState(now.getFullYear());
  const [loading, setLoading] = useState(true);
  const [downloading, setDownloading] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    const controller = new AbortController();

    const loadPayslip = async () => {
      setLoading(true);
      setMessage(null);

      try {
        const response = await fetch(`/api/payroll/my?month=${month}&year=${year}`, {
          signal: controller.signal,
          cache: "no-store",
        });
        const data = await response.json();

        if (!response.ok || !data.success) {
          setPayroll([]);
          setMessage("Payslip information is temporarily unavailable. Please try again.");
          return;
        }

        setPayroll(Array.isArray(data.data) ? data.data : []);
      } catch (error) {
        if ((error as Error).name !== "AbortError") {
          console.error("Failed to fetch payslip data", error);
          setPayroll([]);
          setMessage("Payslip information is temporarily unavailable. Please try again.");
        }
      } finally {
        if (!controller.signal.aborted) setLoading(false);
      }
    };

    loadPayslip();
    return () => controller.abort();
  }, [month, year]);

  const selectedPayroll = payroll[0];
  const employee = selectedPayroll?.userId;

  const monthLabel = useMemo(
    () =>
      new Date(year, month - 1).toLocaleString("en-US", {
        month: "long",
      }),
    [month, year]
  );

  const downloadPayslip = async () => {
    if (!employee?._id || !selectedPayroll) return;

    setDownloading(true);
    setMessage(null);

    try {
      const response = await fetch(
        `/api/export/payslip/${employee._id}?month=${month}&year=${year}`,
        { cache: "no-store" }
      );

      if (!response.ok) {
        let friendly = "Unable to download this payslip right now.";
        try {
          const data = await response.json();
          if (data?.code === "NOT_FINALIZED") {
            friendly = "HR has not finalized this payslip yet.";
          } else if (data?.code === "NOT_FOUND") {
            friendly = "No payslip is available for this month.";
          }
        } catch {
          // Keep the friendly fallback instead of opening a raw server error page.
        }
        setMessage(friendly);
        return;
      }

      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      const disposition = response.headers.get("content-disposition") || "";
      const match = disposition.match(/filename="?([^\"]+)"?/i);
      link.href = url;
      link.download = match?.[1] || `payslip-${monthLabel.toLowerCase()}-${year}.pdf`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Payslip download failed", error);
      setMessage("Unable to download this payslip right now. Please try again.");
    } finally {
      setDownloading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Spinner size="lg" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">My Payslip</h2>
          <p className="mt-1 text-sm text-[var(--neu-text-secondary)]">
            Finalized payslips published by HR appear here.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <select
            value={month}
            onChange={(e) => setMonth(Number.parseInt(e.target.value, 10))}
            className="flex-1 sm:flex-none px-3 py-2 rounded-lg bg-[var(--neu-surface)] border border-[var(--neu-border)] text-sm"
          >
            {Array.from({ length: 12 }, (_, i) => (
              <option key={i + 1} value={i + 1}>
                {new Date(0, i).toLocaleString("en-US", { month: "long" })}
              </option>
            ))}
          </select>
          <select
            value={year}
            onChange={(e) => setYear(Number.parseInt(e.target.value, 10))}
            className="flex-1 sm:flex-none px-3 py-2 rounded-lg bg-[var(--neu-surface)] border border-[var(--neu-border)] text-sm"
          >
            {[2024, 2025, 2026, 2027].map((y) => (
              <option key={y} value={y}>{y}</option>
            ))}
          </select>
        </div>
      </div>

      {message && (
        <div className="rounded-xl border border-[var(--neu-border)] bg-[var(--neu-surface)] px-4 py-3 text-sm text-[var(--neu-text-secondary)]">
          {message}
        </div>
      )}

      {!selectedPayroll ? (
        <EmptyState
          icon={FileText}
          title="No finalized payslip yet"
          description={`HR has not published a payslip for ${monthLabel} ${year}. Once payroll is finalized, it will appear here automatically.`}
        />
      ) : (
        <NeuCard>
          <NeuCardContent className="p-4 sm:p-8 space-y-8">
            <div className="border-b border-[var(--neu-border)] pb-6 mb-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h3 className="text-xl font-bold text-[var(--neu-accent)]">AttendEase</h3>
                  <p className="text-sm text-[var(--neu-text-secondary)]">Employee Payslip</p>
                </div>
                <div className="sm:text-right">
                  <p className="font-medium">{employee?.name || "Employee"}</p>
                  <p className="text-sm text-[var(--neu-text-secondary)]">
                    ID: {employee?.employeeId || "N/A"}
                  </p>
                </div>
              </div>
              <div className="mt-4 flex flex-wrap items-center gap-3">
                <p className="text-lg font-semibold">{monthLabel} {year}</p>
                <span className="inline-flex items-center gap-1 rounded-full bg-green-100 px-2 py-1 text-xs font-medium text-green-700">
                  <CheckCircle2 className="h-3.5 w-3.5" />
                  FINALIZED
                </span>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex justify-between py-3 border-b border-[var(--neu-border)]">
                <span className="text-[var(--neu-text-secondary)]">Basic Salary</span>
                <span className="font-medium">${selectedPayroll.basicSalary.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
              </div>
              <div className="flex justify-between py-3 border-b border-[var(--neu-border)]">
                <span className="text-[var(--neu-text-secondary)]">Present Days</span>
                <span className="font-medium">{selectedPayroll.presentDays}</span>
              </div>
              <div className="flex justify-between py-3 border-b border-[var(--neu-border)] text-red-600">
                <span>Absent Deduction</span>
                <span>-${selectedPayroll.absentDeduction.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
              </div>
              <div className="flex justify-between py-3 border-b border-[var(--neu-border)] text-red-600">
                <span>Late Deduction</span>
                <span>-${selectedPayroll.lateDeduction.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
              </div>
              {selectedPayroll.unpaidLeaveDeduction > 0 && (
                <div className="flex justify-between py-3 border-b border-[var(--neu-border)] text-red-600">
                  <span>Unpaid Leave Deduction</span>
                  <span>-${selectedPayroll.unpaidLeaveDeduction.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                </div>
              )}
              <div className="flex justify-between py-3 border-b border-[var(--neu-border)] text-green-600">
                <span>Bonuses</span>
                <span>+${selectedPayroll.bonuses.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
              </div>
              <div className="flex justify-between py-4 text-lg font-bold">
                <span>Net Salary</span>
                <span className="text-[var(--neu-accent)]">${selectedPayroll.netSalary.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
              </div>
            </div>

            <div className="mt-8 pt-6 border-t border-[var(--neu-border)]">
              <p className="text-xs text-[var(--neu-text-secondary)]">
                This is a computer-generated payslip and does not require a signature.
              </p>
            </div>

            <div className="mt-6 flex justify-end">
              <NeuButton onClick={downloadPayslip} variant="accent" loading={downloading}>
                <Download className="w-4 h-4 mr-2" />
                Download PDF
              </NeuButton>
            </div>
          </NeuCardContent>
        </NeuCard>
      )}
    </div>
  );
}
