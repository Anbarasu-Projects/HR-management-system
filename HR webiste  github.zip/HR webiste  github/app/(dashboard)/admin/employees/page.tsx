"use client";

import { useState, useEffect, useCallback } from "react";
import { Plus, Pencil, Trash2, Search, Users, Loader2, X, Download, FileSpreadsheet, Cake, CheckCircle2, XCircle, UserPlus, Clock3 } from "lucide-react";
import {
  NeuTable,
  NeuTableHeader,
  NeuTableBody,
  NeuTableRow,
  NeuTableHead,
  NeuTableCell,
} from "@/components/ui/neu-table";
import { NeuCard, NeuCardHeader, NeuCardTitle, NeuCardContent } from "@/components/ui/neu-card";
import { NeuButton } from "@/components/ui/neu-button";
import { NeuInput } from "@/components/ui/neu-input";
import { NeuSelect } from "@/components/ui/neu-select";
import { NeuDialog } from "@/components/ui/neu-dialog";
import { NeuBadge } from "@/components/ui/neu-badge";
import { List2, ListItem } from "@/components/ui/list-2";
import { User as UserIcon } from "lucide-react";
import { useToast } from "@/components/ui/neu-toast";

interface Employee {
  _id: string;
  name: string;
  email: string;
  role: "admin" | "employee";
  employeeId?: string;
  department?: { _id: string; name: string } | null;
  shift?: { _id: string; name: string } | null;
  salary?: number;
  joiningDate?: string;
  birthday?: string;
  isActive?: boolean;
  createdAt: string;
}

interface PendingRegistration {
  _id: string;
  name: string;
  email: string;
  department?: { _id: string; name: string } | null;
  approvalStatus: "pending";
  approvalRequestedAt?: string;
  createdAt: string;
}

interface EmployeeFormData {
  name: string;
  email: string;
  password: string;
  confirmPassword: string;
  role: "admin" | "employee";
  department: string;
  shift: string;
  salary: string;
  joiningDate: string;
  birthday: string;
  isActive: boolean;
}

interface Department {
  _id: string;
  name: string;
}

interface Shift {
  _id: string;
  name: string;
}

interface PaginationData {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
}

const roleOptions = [
  { value: "employee", label: "Employee" },
  { value: "admin", label: "Admin" },
];

const emptyFormData: EmployeeFormData = {
  name: "",
  email: "",
  password: "",
  confirmPassword: "",
  role: "employee",
  department: "",
  shift: "",
  salary: "",
  joiningDate: "",
  birthday: "",
  isActive: true,
};

export default function EmployeeManagementPage() {
  const toast = useToast();
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [filteredEmployees, setFilteredEmployees] = useState<Employee[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [pendingRegistrations, setPendingRegistrations] = useState<PendingRegistration[]>([]);
  const [isLoadingRegistrations, setIsLoadingRegistrations] = useState(true);
  const [reviewingRegistrationId, setReviewingRegistrationId] = useState<string | null>(null);

  // Dialog states
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);

  // Form states
  const [formData, setFormData] = useState<EmployeeFormData>(emptyFormData);
  const [formErrors, setFormErrors] = useState<Partial<Record<keyof EmployeeFormData, string>>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Fetch employees
  const fetchEmployees = useCallback(async () => {
    setIsLoading(true);
    try {
      const response = await fetch("/api/employees");
      const data = await response.json();
      if (data.success) {
        setEmployees(data.data);
        setFilteredEmployees(data.data);
      } else {
        setError(data.error || "Failed to fetch employees");
      }
    } catch (err) {
      setError("Failed to fetch employees");
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const fetchPendingRegistrations = useCallback(async () => {
    setIsLoadingRegistrations(true);
    try {
      const response = await fetch("/api/admin/registrations");
      const data = await response.json();
      if (data.success) {
        setPendingRegistrations(Array.isArray(data.data) ? data.data : []);
      }
    } catch (err) {
      console.error("Failed to fetch pending registrations", err);
    } finally {
      setIsLoadingRegistrations(false);
    }
  }, []);

  const fetchDepartments = useCallback(async () => {
    try {
      const response = await fetch("/api/departments");
      const data = await response.json();
      if (data.success) {
        setDepartments(data.data);
      }
    } catch (err) {
      console.error("Failed to fetch departments", err);
    }
  }, []);

  useEffect(() => {
    fetchEmployees();
    fetchDepartments();
    fetchPendingRegistrations();
  }, [fetchEmployees, fetchDepartments, fetchPendingRegistrations]);

  const departmentOptions = departments.map((department) => ({
    value: department._id,
    label: department.name,
  }));

  // Filter employees based on search
  useEffect(() => {
    if (!searchQuery.trim()) {
      setFilteredEmployees(employees);
      return;
    }

    const query = searchQuery.toLowerCase();
    const filtered = employees.filter(
      (emp) =>
        emp.name.toLowerCase().includes(query) ||
        emp.email.toLowerCase().includes(query) ||
        emp.employeeId?.toLowerCase().includes(query) ||
        emp.department?.name?.toLowerCase().includes(query)
    );
    setFilteredEmployees(filtered);
  }, [searchQuery, employees]);

  // Validate form
  const validateForm = (isEdit: boolean): boolean => {
    const errors: Partial<Record<keyof EmployeeFormData, string>> = {};

    if (!formData.name.trim()) {
      errors.name = "Name is required";
    }

    if (!formData.email.trim()) {
      errors.email = "Email is required";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      errors.email = "Invalid email format";
    }

    if (!isEdit && !formData.password) {
      errors.password = "Password is required";
    } else if (formData.password && formData.password.length < 6) {
      errors.password = "Password must be at least 6 characters";
    }

    if (formData.password && formData.password !== formData.confirmPassword) {
      errors.confirmPassword = "Passwords do not match";
    }

    if (formData.role === "employee") {
      if (formData.salary.trim() === "") {
        errors.salary = "Basic monthly salary is required";
      } else if (!Number.isFinite(Number(formData.salary)) || Number(formData.salary) < 0) {
        errors.salary = "Enter a valid salary of 0 or more";
      }
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  // Handle add employee
  const handleAdd = async () => {
    if (!validateForm(false)) return;

    setIsSubmitting(true);
    try {
      const response = await fetch("/api/employees", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...formData,
          password: formData.password.trim(),
          confirmPassword: undefined,
          salary: formData.salary === "" ? 0 : Number(formData.salary),
          birthday: formData.birthday || undefined,
          isActive: true,
        }),
      });

      const data = await response.json();
      if (data.success) {
        setIsAddDialogOpen(false);
        setFormData(emptyFormData);
        toast.success(`Employee ${formData.name} added successfully`);
        fetchEmployees();
      } else {
        setFormErrors({ ...formErrors, email: data.error });
      }
    } catch (err) {
      console.error(err);
      setError("Failed to add employee");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle edit employee
  const handleEdit = async () => {
    if (!selectedEmployee || !validateForm(true)) return;

    setIsSubmitting(true);
    try {
      const payload: Record<string, unknown> = {
        id: selectedEmployee._id,
        name: formData.name,
        email: formData.email,
        role: formData.role,
        department: formData.department,
        shift: formData.shift,
        salary: formData.salary === "" ? 0 : Number(formData.salary),
        joiningDate: formData.joiningDate || undefined,
        birthday: formData.birthday || null,
        isActive: formData.isActive,
      };

      if (formData.password) {
        payload.password = formData.password.trim();
      }

      const response = await fetch("/api/employees", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await response.json();
      if (data.success) {
        const passwordChanged = Boolean(formData.password);
        setIsEditDialogOpen(false);
        toast.success(
          passwordChanged
            ? `Changes saved for ${formData.name}. Password updated securely.`
            : `Changes saved for ${formData.name}`
        );
        setSelectedEmployee(null);
        setFormData(emptyFormData);
        fetchEmployees();
      } else {
        setFormErrors({ ...formErrors, email: data.error });
      }
    } catch (err) {
      console.error(err);
      setError("Failed to update employee");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle delete employee
  const handleDelete = async () => {
    if (!selectedEmployee) return;

    setIsSubmitting(true);
    try {
      const response = await fetch(`/api/employees?id=${selectedEmployee._id}`, {
        method: "DELETE",
      });

      const data = await response.json();
      if (data.success) {
        setIsDeleteDialogOpen(false);
        toast.success(`${selectedEmployee.name} was deleted`);
        setSelectedEmployee(null);
        fetchEmployees();
      } else {
        setError(data.error || "Failed to delete employee");
      }
    } catch (err) {
      console.error(err);
      setError("Failed to delete employee");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRegistrationDecision = async (registration: PendingRegistration, action: "approve" | "reject") => {
    setReviewingRegistrationId(registration._id);
    try {
      const response = await fetch(`/api/admin/registrations/${registration._id}/${action}`, {
        method: "POST",
      });
      const data = await response.json();

      if (!response.ok || !data.success) {
        toast.error(data.error || `Failed to ${action} registration`);
        return;
      }

      toast.success(
        action === "approve"
          ? `${registration.name} approved and can now sign in`
          : `${registration.name}'s registration was rejected`
      );
      await Promise.all([fetchPendingRegistrations(), fetchEmployees()]);
    } catch (err) {
      console.error(`Failed to ${action} registration`, err);
      toast.error(`Failed to ${action} registration`);
    } finally {
      setReviewingRegistrationId(null);
    }
  };

  // Open edit dialog
  const openEditDialog = (employee: Employee) => {
    setSelectedEmployee(employee);
    setFormData({
      name: employee.name,
      email: employee.email,
      password: "",
      confirmPassword: "",
      role: employee.role,
      department: employee.department?._id || "",
      shift: employee.shift?._id || "",
      salary: employee.salary?.toString() || "",
      joiningDate: employee.joiningDate ? new Date(employee.joiningDate).toISOString().split('T')[0] : "",
      birthday: employee.birthday ? new Date(employee.birthday).toISOString().split('T')[0] : "",
      isActive: employee.isActive !== false,
    });
    setFormErrors({});
    setIsEditDialogOpen(true);
  };

  // Open delete dialog
  const openDeleteDialog = (employee: Employee) => {
    setSelectedEmployee(employee);
    setIsDeleteDialogOpen(true);
  };

  // Open add dialog
  const openAddDialog = () => {
    setFormData(emptyFormData);
    setFormErrors({});
    setIsAddDialogOpen(true);
  };

  const getRoleBadgeVariant = (role: string): "accent" | "default" => {
    return role === "admin" ? "accent" : "default";
  };

  // Handle export employees to Excel
  const handleExportEmployees = async () => {
    try {
      const response = await fetch("/api/export/employees?format=excel");

      if (!response.ok) {
        throw new Error("Failed to export");
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;

      // Get filename from Content-Disposition header or generate default
      const contentDisposition = response.headers.get("Content-Disposition");
      let filename = "employees-export.xlsx";
      if (contentDisposition) {
        const match = contentDisposition.match(/filename="(.+)"/);
        if (match) filename = match[1];
      }

      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Export employees error:", error);
      alert("Failed to export employees. Please try again.");
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="w-8 h-8 animate-spin text-[var(--neu-accent)]" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-12">
        <p className="text-[var(--neu-danger)] text-lg">{error}</p>
        <NeuButton variant="accent" onClick={fetchEmployees} className="mt-4">
          Retry
        </NeuButton>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
        <div className="flex items-center gap-3">
          <Users className="w-6 h-6 md:w-8 md:h-8 text-[var(--neu-accent)]" />
          <h1 className="text-xl md:text-2xl font-bold text-[var(--neu-text)]">
            Employee Management
          </h1>
        </div>
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <NeuButton
            variant="ghost"
            onClick={handleExportEmployees}
            className="flex-1 sm:flex-none h-11"
          >
            <FileSpreadsheet className="w-4 h-4" />
            Export Excel
          </NeuButton>
          <NeuButton
            variant="accent"
            onClick={openAddDialog}
            className="flex-1 sm:flex-none h-11 shadow-[0_0_20px_-5px_var(--neu-accent)]"
          >
            <Plus className="w-4 h-4" />
            Add Employee
          </NeuButton>
        </div>
      </div>

      {/* Pending self-registration approvals */}
      <NeuCard id="pending-registrations" className="scroll-mt-24 border border-[var(--neu-warning)]/20">
        <NeuCardHeader>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[var(--neu-warning)]/10 text-[var(--neu-warning)]">
                <UserPlus className="h-5 w-5" />
              </div>
              <div>
                <NeuCardTitle>Registration Requests</NeuCardTitle>
                <p className="mt-1 text-xs text-[var(--neu-text-secondary)]">
                  New accounts cannot sign in until you approve them.
                </p>
              </div>
            </div>
            {!isLoadingRegistrations && pendingRegistrations.length > 0 && (
              <span className="rounded-full bg-[var(--neu-warning)]/10 px-3 py-1 text-xs font-bold text-[var(--neu-warning)]">
                {pendingRegistrations.length} pending
              </span>
            )}
          </div>
        </NeuCardHeader>
        <NeuCardContent>
          {isLoadingRegistrations ? (
            <div className="flex items-center gap-2 py-4 text-sm text-[var(--neu-text-secondary)]">
              <Loader2 className="h-4 w-4 animate-spin" />
              Checking registration requests...
            </div>
          ) : pendingRegistrations.length === 0 ? (
            <div className="flex items-center gap-2 rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-4 text-sm text-[var(--neu-text-secondary)]">
              <CheckCircle2 className="h-5 w-5 text-[var(--neu-success)]" />
              No registration requests are waiting for review.
            </div>
          ) : (
            <div className="space-y-3">
              {pendingRegistrations.map((registration) => {
                const isReviewing = reviewingRegistrationId === registration._id;
                const requestedAt = registration.approvalRequestedAt || registration.createdAt;

                return (
                  <div
                    key={registration._id}
                    className="flex flex-col gap-4 rounded-xl border border-white/[0.08] bg-white/[0.025] p-4 lg:flex-row lg:items-center lg:justify-between"
                  >
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <p className="font-semibold text-[var(--neu-text)]">{registration.name}</p>
                        <span className="rounded-full bg-[var(--neu-warning)]/10 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-[var(--neu-warning)]">
                          Pending
                        </span>
                      </div>
                      <p className="mt-1 truncate text-sm text-[var(--neu-text-secondary)]">
                        {registration.email}
                        {registration.department?.name ? ` · ${registration.department.name}` : ""}
                      </p>
                      <p className="mt-1 flex items-center gap-1.5 text-xs text-[var(--neu-text-muted)]">
                        <Clock3 className="h-3.5 w-3.5" />
                        Registered {new Date(requestedAt).toLocaleString()}
                      </p>
                    </div>

                    <div className="flex shrink-0 gap-2">
                      <NeuButton
                        variant="accent"
                        size="sm"
                        disabled={isReviewing}
                        onClick={() => handleRegistrationDecision(registration, "approve")}
                      >
                        {isReviewing ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle2 className="h-4 w-4" />}
                        Approve
                      </NeuButton>
                      <NeuButton
                        variant="danger"
                        size="sm"
                        disabled={isReviewing}
                        onClick={() => handleRegistrationDecision(registration, "reject")}
                      >
                        <XCircle className="h-4 w-4" />
                        Reject
                      </NeuButton>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </NeuCardContent>
      </NeuCard>

      {/* Search */}
      <NeuInput
        type="text"
        placeholder="Search employees by name, email, or department..."
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
        icon={<Search className="w-4 h-4" />}
      />

      {/* Employees Table */}
      <NeuCard>
        <NeuCardHeader>
          <NeuCardTitle>All Employees ({filteredEmployees.length})</NeuCardTitle>
        </NeuCardHeader>
        <NeuCardContent>
          {filteredEmployees.length === 0 ? (
            <div className="text-center py-12 text-[var(--neu-text-secondary)]">
              <Users className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p className="text-lg font-medium">No employees found</p>
              <p className="text-sm mt-1">
                {searchQuery ? "Try adjusting your search" : "Add your first employee to get started"}
              </p>
            </div>
          ) : (
            <List2 
              items={filteredEmployees.map((employee) => ({
                icon: <UserIcon className="w-5 h-5" />,
                title: employee.name,
                category: employee.role.toUpperCase(),
                description: (
                  <div className="flex flex-col gap-1">
                    <span>{employee.department?.name || "No Dept"} • {employee.email}</span>
                    {employee.employeeId && (
                      <span className="text-xs text-[var(--neu-text-secondary)]">
                        Employee ID: {employee.employeeId} • {employee.isActive === false ? "Inactive" : "Active"}
                      </span>
                    )}
                    {employee.role === "employee" && (
                      <>
                        <span className="text-sm font-medium text-[var(--neu-accent)]">
                          Basic Salary: ${(employee.salary || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} / month
                        </span>
                        {employee.birthday && (
                          <span className="flex items-center gap-1 text-xs text-[var(--neu-text-secondary)]">
                            <Cake className="h-3.5 w-3.5" />
                            Birthday: {new Date(employee.birthday).toLocaleDateString(undefined, { day: "numeric", month: "short" })}
                          </span>
                        )}
                      </>
                    )}
                  </div>
                ),
                onClick: () => openEditDialog(employee),
                status: (
                  <div className="flex items-center gap-2">
                    <NeuBadge variant={getRoleBadgeVariant(employee.role)}>
                      {employee.role}
                    </NeuBadge>
                    <NeuButton
                      variant="ghost"
                      size="icon"
                      onClick={(e) => {
                        e.stopPropagation();
                        openDeleteDialog(employee);
                      }}
                      className="h-8 w-8 text-[var(--neu-danger)] hover:bg-[var(--neu-danger)]/10"
                    >
                      <Trash2 className="w-4 h-4" />
                    </NeuButton>
                  </div>
                )
              }))}
            />
          )}
        </NeuCardContent>
      </NeuCard>

      {/* Add Employee Dialog */}
      <NeuDialog
        open={isAddDialogOpen}
        onClose={() => setIsAddDialogOpen(false)}
        title="Add New Employee"
      >
        <div className="space-y-4">
          <NeuInput
            label="Full Name"
            placeholder="Enter employee name"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            error={formErrors.name}
          />
          <NeuInput
            label="Email"
            type="email"
            placeholder="Enter email address"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            error={formErrors.email}
          />
          <NeuInput
            label="Password"
            type="password"
            placeholder="Enter password (min 6 characters)"
            value={formData.password}
            onChange={(e) => setFormData({ ...formData, password: e.target.value })}
            error={formErrors.password}
          />
          <NeuInput
            label="Confirm Password"
            type="password"
            placeholder="Re-enter password"
            value={formData.confirmPassword}
            onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
            error={formErrors.confirmPassword}
          />
          <NeuSelect
            label="Role"
            options={roleOptions}
            value={formData.role}
            onChange={(e) =>
              setFormData({ ...formData, role: e.target.value as "admin" | "employee" })
            }
          />
          <NeuSelect
            label="Department"
            options={departmentOptions}
            value={formData.department}
            onChange={(e) => setFormData({ ...formData, department: e.target.value })}
            placeholder="Select department"
          />
          {formData.role === "employee" && (
            <NeuInput
              label="Basic Monthly Salary (SGD)"
              type="number"
              min="0"
              step="0.01"
              placeholder="e.g. 3500"
              value={formData.salary}
              onChange={(e) => setFormData({ ...formData, salary: e.target.value })}
              error={formErrors.salary}
              hint="This amount is used when monthly payroll is generated."
            />
          )}
          <NeuInput
            label="Birthday"
            type="date"
            value={formData.birthday}
            onChange={(e) => setFormData({ ...formData, birthday: e.target.value })}
            hint="Used for upcoming birthday reminders on the admin dashboard."
          />
          <NeuInput
            label="Joining Date"
            type="date"
            value={formData.joiningDate}
            onChange={(e) => setFormData({ ...formData, joiningDate: e.target.value })}
          />
          <div className="sticky bottom-0 z-10 -mx-4 flex gap-3 border-t border-[var(--neu-border)] bg-[var(--neu-surface)] px-4 pb-1 pt-4">
            <NeuButton
              variant="accent"
              onClick={handleAdd}
              loading={isSubmitting}
              className="flex-1"
            >
              Add Employee
            </NeuButton>
            <NeuButton
              variant="ghost"
              onClick={() => setIsAddDialogOpen(false)}
              disabled={isSubmitting}
            >
              Cancel
            </NeuButton>
          </div>
        </div>
      </NeuDialog>

      {/* Edit Employee Dialog */}
      <NeuDialog
        open={isEditDialogOpen}
        onClose={() => setIsEditDialogOpen(false)}
        title="Edit Employee"
      >
        <div className="space-y-4">
          <NeuInput
            label="Full Name"
            placeholder="Enter employee name"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            error={formErrors.name}
          />
          <NeuInput
            label="Email"
            type="email"
            placeholder="Enter email address"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            error={formErrors.email}
          />
          <NeuInput
            label="Reset Password (optional)"
            type="password"
            placeholder="Enter a new password only if you want to change it"
            value={formData.password}
            onChange={(e) => setFormData({ ...formData, password: e.target.value })}
            error={formErrors.password}
            hint="For security, the saved password is encrypted and is never displayed here again."
          />
          {formData.password && (
            <NeuInput
              label="Confirm New Password"
              type="password"
              placeholder="Re-enter the new password"
              value={formData.confirmPassword}
              onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
              error={formErrors.confirmPassword}
              hint="This prevents accidental password typos before saving."
            />
          )}
          <NeuSelect
            label="Role"
            options={roleOptions}
            value={formData.role}
            onChange={(e) =>
              setFormData({ ...formData, role: e.target.value as "admin" | "employee" })
            }
          />
          <NeuSelect
            label="Department"
            options={departmentOptions}
            value={formData.department}
            onChange={(e) => setFormData({ ...formData, department: e.target.value })}
            placeholder="Select department"
          />
          {formData.role === "employee" && (
            <NeuInput
              label="Basic Monthly Salary (SGD)"
              type="number"
              min="0"
              step="0.01"
              placeholder="e.g. 3500"
              value={formData.salary}
              onChange={(e) => setFormData({ ...formData, salary: e.target.value })}
              error={formErrors.salary}
              hint="Changing this updates future payroll and any draft payroll you regenerate."
            />
          )}
          <NeuSelect
            label="Account Status"
            options={[
              { value: "active", label: "Active — employee can sign in" },
              { value: "inactive", label: "Inactive — sign in blocked" },
            ]}
            value={formData.isActive ? "active" : "inactive"}
            onChange={(e) =>
              setFormData({ ...formData, isActive: e.target.value === "active" })
            }
          />
          <NeuInput
            label="Birthday"
            type="date"
            value={formData.birthday}
            onChange={(e) => setFormData({ ...formData, birthday: e.target.value })}
            hint="Used for upcoming birthday reminders on the admin dashboard."
          />
          <NeuInput
            label="Joining Date"
            type="date"
            value={formData.joiningDate}
            onChange={(e) => setFormData({ ...formData, joiningDate: e.target.value })}
          />
          <div className="sticky bottom-0 z-10 -mx-4 flex gap-3 border-t border-[var(--neu-border)] bg-[var(--neu-surface)] px-4 pb-1 pt-4">
            <NeuButton
              variant="accent"
              onClick={handleEdit}
              loading={isSubmitting}
              className="flex-1"
            >
              Save Changes
            </NeuButton>
            <NeuButton
              variant="ghost"
              onClick={() => setIsEditDialogOpen(false)}
              disabled={isSubmitting}
            >
              Cancel
            </NeuButton>
          </div>
        </div>
      </NeuDialog>

      {/* Delete Confirmation Dialog */}
      <NeuDialog
        open={isDeleteDialogOpen}
        onClose={() => setIsDeleteDialogOpen(false)}
        title="Delete Employee"
      >
        <div className="space-y-4">
          <div className="flex items-center gap-3 p-4 bg-[var(--neu-danger)]/10 rounded-[var(--neu-radius)]">
            <Trash2 className="w-6 h-6 text-[var(--neu-danger)]" />
            <div>
              <p className="text-[var(--neu-text)] font-medium">
                Are you sure you want to delete this employee?
              </p>
              <p className="text-sm text-[var(--neu-text-secondary)] mt-1">
                This will also delete all their attendance records. This action cannot be undone.
              </p>
            </div>
          </div>

          {selectedEmployee && (
            <div className="p-4 bg-[var(--neu-surface-light)] rounded-[var(--neu-radius)]">
              <p className="font-medium text-[var(--neu-text)]">{selectedEmployee.name}</p>
              <p className="text-sm text-[var(--neu-text-secondary)]">{selectedEmployee.email}</p>
            </div>
          )}

          <div className="flex gap-3 pt-4">
            <NeuButton
              variant="danger"
              onClick={handleDelete}
              loading={isSubmitting}
              className="flex-1"
            >
              Delete Employee
            </NeuButton>
            <NeuButton
              variant="ghost"
              onClick={() => setIsDeleteDialogOpen(false)}
              disabled={isSubmitting}
            >
              Cancel
            </NeuButton>
          </div>
        </div>
      </NeuDialog>
    </div>
  );
}
