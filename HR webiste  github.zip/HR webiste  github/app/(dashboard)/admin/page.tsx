"use client";

import { useState, useEffect, useCallback } from "react";
import { ChevronLeft, ChevronRight, LayoutDashboard, Cake, CalendarClock, ArrowRight } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { AttendanceStats } from "@/components/attendance/attendance-stats";
import { AttendanceFilters, FilterState } from "@/components/attendance/attendance-filters";
import { AttendanceTable } from "@/components/attendance/attendance-table";
import { AttendanceExport } from "@/components/attendance/attendance-export";
import { NeuCard, NeuCardHeader, NeuCardTitle, NeuCardContent } from "@/components/ui/neu-card";
import { NeuButton } from "@/components/ui/neu-button";
import { ChipLoader } from "@/components/ui/chip-loader";
import Link from "next/link";

interface AttendanceStatsData {
  totalEmployees: number;
  presentToday: number;
  absentToday: number;
  lateToday: number;
  avgHoursThisMonth: number;
  attendanceRate: number;
  totalLateThisMonth: number;
  presentTrend: number;
  lateTrend: number;
  month: string;
}

interface AttendanceRecord {
  _id: string;
  userId: {
    _id: string;
    name: string;
    email: string;
    department?: string;
  };
  date: string;
  checkIn: string;
  checkOut: string | null;
  hoursWorked: number;
  status: "present" | "absent" | "late";
  notes?: string;
}

const ITEMS_PER_PAGE = 10;

interface BirthdayHighlight {
  _id: string;
  name: string;
  employeeId?: string;
  department: string | null;
  birthday: string;
  nextBirthday: string;
  daysUntil: number;
}

interface PendingLeaveHighlight {
  _id: string;
  userId?: {
    _id: string;
    name: string;
    employeeId?: string;
  };
  leaveType: string;
  startDate: string;
  endDate: string;
  totalDays: number;
  appliedAt: string;
}

interface AdminHighlights {
  upcomingBirthdays: BirthdayHighlight[];
  pendingLeaves: PendingLeaveHighlight[];
  pendingLeaveCount: number;
}

export default function AdminDashboardPage() {
  const [stats, setStats] = useState<AttendanceStatsData | null>(null);
  const [records, setRecords] = useState<AttendanceRecord[]>([]);
  const [filteredRecords, setFilteredRecords] = useState<AttendanceRecord[]>([]);
  const [isLoadingStats, setIsLoadingStats] = useState(true);
  const [isLoadingRecords, setIsLoadingRecords] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [highlights, setHighlights] = useState<AdminHighlights>({
    upcomingBirthdays: [],
    pendingLeaves: [],
    pendingLeaveCount: 0,
  });
  const [isLoadingHighlights, setIsLoadingHighlights] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [filters, setFilters] = useState<FilterState>({
    month: new Date().toISOString().slice(0, 7),
    employeeId: "",
    status: "",
    search: "",
  });

  // Fetch stats
  const fetchStats = useCallback(async (month: string) => {
    setIsLoadingStats(true);
    try {
      const response = await fetch(`/api/attendance/stats?month=${month}`);
      const data = await response.json();
      if (data.success) {
        setStats(data.data);
      } else {
        setError(data.error || "Failed to fetch stats");
      }
    } catch (err) {
      setError("Failed to fetch stats");
      console.error(err);
    } finally {
      setIsLoadingStats(false);
    }
  }, []);

  // Fetch attendance records
  const fetchRecords = useCallback(async (month: string) => {
    setIsLoadingRecords(true);
    try {
      const response = await fetch(`/api/attendance?month=${month}`);
      const data = await response.json();
      if (data.success) {
        const validRecords = Array.isArray(data.data.records) ? data.data.records : [];
        setRecords(validRecords);
        setFilteredRecords(validRecords);
      } else {
        setError(data.error || "Failed to fetch records");
      }
    } catch (err) {
      setError("Failed to fetch records");
      console.error(err);
    } finally {
      setIsLoadingRecords(false);
    }
  }, []);

  const fetchHighlights = useCallback(async () => {
    setIsLoadingHighlights(true);
    try {
      const response = await fetch("/api/admin/highlights");
      const data = await response.json();
      if (data.success) {
        setHighlights(data.data);
      }
    } catch (err) {
      console.error("Failed to fetch dashboard highlights", err);
    } finally {
      setIsLoadingHighlights(false);
    }
  }, []);

  // Initial/monthly load
  useEffect(() => {
    fetchStats(filters.month);
    fetchRecords(filters.month);
  }, [fetchStats, fetchRecords, filters.month]);

  useEffect(() => {
    fetchHighlights();
  }, [fetchHighlights]);

  // Apply filters to records
  useEffect(() => {
    let result = [...records];

    // Filter by employee
    if (filters.employeeId) {
      result = result.filter(
        (record) =>
          typeof record.userId === "object" &&
          record.userId._id === filters.employeeId
      );
    }

    // Filter by status
    if (filters.status) {
      result = result.filter((record) => record.status === filters.status);
    }

    // Filter by search (name)
    if (filters.search) {
      const searchLower = filters.search.toLowerCase();
      result = result.filter(
        (record) =>
          typeof record.userId === "object" &&
          record.userId.name.toLowerCase().includes(searchLower)
      );
    }

    setFilteredRecords(result);
    setCurrentPage(1);
  }, [filters, records]);

  const handleFilter = (newFilters: FilterState) => {
    setFilters(newFilters);
    fetchStats(newFilters.month);
    fetchRecords(newFilters.month);
  };

  const handlePrevMonth = () => {
    const [year, month] = filters.month.split("-").map(Number);
    const date = new Date(year, month - 2, 1); // month - 2 because month is 1-indexed and we want previous
    const newMonth = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
    handleFilter({ ...filters, month: newMonth });
  };

  const handleNextMonth = () => {
    const [year, month] = filters.month.split("-").map(Number);
    const date = new Date(year, month, 1); // month is 1-indexed, so this gives next month
    const newMonth = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
    handleFilter({ ...filters, month: newMonth });
  };

  // Pagination
  const totalPages = Math.ceil(filteredRecords.length / ITEMS_PER_PAGE);
  const paginatedRecords = filteredRecords.slice(
    (currentPage - 1) * ITEMS_PER_PAGE,
    currentPage * ITEMS_PER_PAGE
  );

  const formatMonthDisplay = (monthStr: string) => {
    const [year, month] = monthStr.split("-");
    const date = new Date(Number(year), Number(month) - 1, 1);
    return date.toLocaleDateString("en-US", { month: "long", year: "numeric" });
  };

  if (error) {
    return (
      <div className="space-y-8">
        <div className="text-center py-12">
          <p className="text-[var(--neu-danger)] text-lg">{error}</p>
          <NeuButton
            variant="accent"
            onClick={() => {
              setError(null);
              fetchStats(filters.month);
              fetchRecords(filters.month);
            }}
            className="mt-4"
          >
            Retry
          </NeuButton>
        </div>
      </div>
    );
  }

  const isLoading = isLoadingStats || isLoadingRecords;

  return (
    <div className="relative space-y-8" style={{ minHeight: "400px" }}>
      {/* Overlay loader — blurs behind without shifting layout */}
      {isLoading && (
        <ChipLoader overlay size="md" label="Loading" />
      )}

      {/* Header */}
      <PageHeader
        eyebrow="Admin Console"
        icon={<LayoutDashboard className="h-6 w-6" />}
        title={formatMonthDisplay(filters.month)}
        description="Workforce attendance, leave and payroll at a glance."
        actions={
          <>
            <div className="flex items-center gap-1 rounded-xl border border-white/[0.1] bg-white/[0.04] p-1">
              <NeuButton
                variant="ghost"
                size="icon"
                className="h-9 w-9"
                onClick={handlePrevMonth}
                aria-label="Previous month"
              >
                <ChevronLeft className="h-4 w-4" />
              </NeuButton>
              <NeuButton
                variant="ghost"
                size="icon"
                className="h-9 w-9"
                onClick={handleNextMonth}
                aria-label="Next month"
              >
                <ChevronRight className="h-4 w-4" />
              </NeuButton>
            </div>
            <AttendanceExport records={filteredRecords} month={filters.month} />
          </>
        }
      />

      {/* Stats Grid */}
      <AttendanceStats stats={stats} isLoading={false} />

      {/* People & leave alerts */}
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
        <NeuCard>
          <NeuCardHeader>
            <div className="flex items-center justify-between gap-3">
              <NeuCardTitle>Upcoming Birthdays</NeuCardTitle>
              <Cake className="h-5 w-5 text-[var(--neu-accent)]" />
            </div>
          </NeuCardHeader>
          <NeuCardContent>
            {isLoadingHighlights ? (
              <ChipLoader size="sm" />
            ) : highlights.upcomingBirthdays.length === 0 ? (
              <p className="py-4 text-sm text-[var(--neu-text-muted)]">
                No employee birthdays in the next 30 days.
              </p>
            ) : (
              <div className="space-y-2">
                {highlights.upcomingBirthdays.slice(0, 5).map((birthday) => (
                  <div
                    key={birthday._id}
                    className={`relative flex items-center justify-between gap-3 rounded-xl border px-3 py-3 ${
                      birthday.daysUntil <= 2
                        ? "border-[var(--neu-accent)]/40 bg-[var(--neu-accent)]/10 animate-pulse"
                        : "border-white/[0.07] bg-white/[0.025]"
                    }`}
                  >
                    {birthday.daysUntil <= 2 && (
                      <span className="absolute -right-1 -top-3 inline-block text-lg animate-bounce" aria-hidden="true">🎉</span>
                    )}
                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold text-[var(--neu-text)]">{birthday.name}</p>
                      <p className="truncate text-xs text-[var(--neu-text-secondary)]">
                        {birthday.department || "No department"} · {new Date(birthday.nextBirthday).toLocaleDateString(undefined, { day: "numeric", month: "short" })}
                      </p>
                    </div>
                    <span className="shrink-0 rounded-full bg-[var(--neu-accent)]/10 px-2.5 py-1 text-xs font-semibold text-[var(--neu-accent)]">
                      {birthday.daysUntil === 0 ? "Today 🎉" : birthday.daysUntil === 1 ? "Tomorrow" : `${birthday.daysUntil} days`}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </NeuCardContent>
        </NeuCard>

        <NeuCard>
          <NeuCardHeader>
            <div className="flex items-center justify-between gap-3">
              <div>
                <NeuCardTitle>Leave Requests</NeuCardTitle>
                {!isLoadingHighlights && highlights.pendingLeaveCount > 0 && (
                  <p className="mt-1 text-xs text-[var(--neu-text-secondary)]">
                    {highlights.pendingLeaveCount} request{highlights.pendingLeaveCount === 1 ? "" : "s"} awaiting review
                  </p>
                )}
              </div>
              <CalendarClock className="h-5 w-5 text-[var(--neu-warning)]" />
            </div>
          </NeuCardHeader>
          <NeuCardContent>
            {isLoadingHighlights ? (
              <ChipLoader size="sm" />
            ) : highlights.pendingLeaves.length === 0 ? (
              <p className="py-4 text-sm text-[var(--neu-text-muted)]">No pending leave requests.</p>
            ) : (
              <div className="space-y-2">
                {highlights.pendingLeaves.slice(0, 4).map((leave) => (
                  <div
                    key={leave._id}
                    className="flex items-center justify-between gap-3 rounded-xl border border-white/[0.07] bg-white/[0.025] px-3 py-3"
                  >
                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold text-[var(--neu-text)]">
                        {leave.userId?.name || "Employee"}
                      </p>
                      <p className="truncate text-xs capitalize text-[var(--neu-text-secondary)]">
                        {leave.leaveType} · {new Date(leave.startDate).toLocaleDateString(undefined, { day: "numeric", month: "short" })} – {new Date(leave.endDate).toLocaleDateString(undefined, { day: "numeric", month: "short" })}
                      </p>
                    </div>
                    <span className="shrink-0 rounded-full bg-[var(--neu-warning)]/10 px-2.5 py-1 text-xs font-semibold text-[var(--neu-warning)]">
                      Pending
                    </span>
                  </div>
                ))}
                <Link
                  href="/admin/leaves"
                  className="mt-2 inline-flex items-center gap-1.5 text-sm font-semibold text-[var(--neu-accent)] hover:underline"
                >
                  Review leave requests <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
            )}
          </NeuCardContent>
        </NeuCard>
      </div>

      {/* Filters */}
      <AttendanceFilters onFilter={handleFilter} initialFilters={filters} />

      {/* Attendance Table */}
      <NeuCard>
        <NeuCardHeader>
          <NeuCardTitle>Attendance Records</NeuCardTitle>
        </NeuCardHeader>
        <NeuCardContent>
          <AttendanceTable records={paginatedRecords} />

          {/* Pagination */}
          {!isLoadingRecords && totalPages > 1 && (
            <div className="flex items-center justify-between mt-6 pt-4 border-t border-[var(--neu-border)]">
              <p className="text-sm text-[var(--neu-text-secondary)]">
                Showing {(currentPage - 1) * ITEMS_PER_PAGE + 1} to{" "}
                {Math.min(currentPage * ITEMS_PER_PAGE, filteredRecords.length)} of{" "}
                {filteredRecords.length} records
              </p>
              <div className="flex gap-2">
                <NeuButton
                  variant="ghost"
                  size="sm"
                  onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                  disabled={currentPage === 1}
                >
                  <ChevronLeft className="w-4 h-4 mr-1" />
                  Previous
                </NeuButton>
                <NeuButton
                  variant="ghost"
                  size="sm"
                  onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                  disabled={currentPage === totalPages}
                >
                  Next
                  <ChevronRight className="w-4 h-4 ml-1" />
                </NeuButton>
              </div>
            </div>
          )}
        </NeuCardContent>
      </NeuCard>
    </div>
  );
}
