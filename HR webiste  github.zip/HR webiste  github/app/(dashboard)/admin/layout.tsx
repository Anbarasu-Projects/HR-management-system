"use client";

import { AdminSidebar } from "@/components/layout/admin-sidebar";
import { Header } from "@/components/layout/header";
import { useSidebar } from "@/lib/SidebarContext";
import { cn } from "@/lib/utils";

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const { isAdminCollapsed: isCollapsed } = useSidebar();

  return (
    // data-portal drives the violet/magenta accent ramp for every child.
    <div data-portal="admin" className="relative z-10 flex min-h-screen bg-transparent">
      <AdminSidebar />
      <div
        className={cn(
          "min-w-0 flex-1 transition-[margin] duration-300",
          "ml-0",
          isCollapsed ? "lg:ml-20" : "lg:ml-64"
        )}
      >
        <Header />
        <main className="mx-auto w-full max-w-[1600px] p-3 sm:p-5 md:p-7">{children}</main>
      </div>
    </div>
  );
}
