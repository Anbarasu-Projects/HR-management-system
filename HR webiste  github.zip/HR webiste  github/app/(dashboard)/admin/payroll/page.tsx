"use client";

import { useEffect, useState } from "react";
import { NeuCard, NeuCardContent } from "@/components/ui/neu-card";
import { NeuButton } from "@/components/ui/neu-button";
import { EmptyState } from "@/components/ui/empty-state";
import { DollarSign, Download, User as UserIcon, TrendingUp, TrendingDown, Pencil, Gift } from "lucide-react";
import { ChipLoader } from "@/components/ui/chip-loader";
import { List2, ListItem } from "@/components/ui/list-2";
import { NeuBadge } from "@/components/ui/neu-badge";
import { NeuDialog } from "@/components/ui/neu-dialog";
import { NeuInput } from "@/components/ui/neu-input";

interface PayrollRecord {
  _id: string;
  userId: { _id: string; name: string; employeeId?: string };
  month: number;
  year: number;
  basicSalary: number;
  presentDays: number;
  absentDeduction: number;
  lateDeduction: number;
  unpaidLeaveDeduction: number;
  unpaidLeaveDays: number;
  bonuses: number;
  netSalary: number;
  status: "draft" | "finalized";
}

export default function AdminPayrollPage() {
  const [payroll, setPayroll] = useState<PayrollRecord[]>([]);
  const [month, setMonth] = useState(new Date().getMonth() + 1);
  const [year, setYear] = useState(new Date().getFullYear());
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [editingBonus, setEditingBonus] = useState<PayrollRecord | null>(null);
  const [bonusValue, setBonusValue] = useState("");
  const [savingBonus, setSavingBonus] = useState(false);
  const [downloadingId, setDownloadingId] = useState<string | null>(null);

  const fetchPayroll = async () => {
    setLoading(true);
    try {
      const response = await fetch(`/api/payroll?month=${month}&year=${year}`);
      const data = await response.json();
      if (data.success) {
        setPayroll(data.data);
      }
    } catch (error) {
      console.error("Failed to fetch payroll", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPayroll();
  }, [month, year]);

  const handleGenerate = async () => {
    setGenerating(true);
    try {
      const response = await fetch("/api/payroll", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ month, year }),
      });
      if (response.ok) {
        fetchPayroll();
      }
    } catch (error) {
      console.error("Failed to generate payroll", error);
    } finally {
      setGenerating(false);
    }
  };

  const handleFinalize = async (id: string) => {
    try {
      const response = await fetch(`/api/payroll/${id}`, {
        method: "PATCH",
      });
      if (response.ok) {
        fetchPayroll();
      }
    } catch (error) {
      console.error("Failed to finalize payroll", error);
    }
  };

  const openBonusDialog = (record: PayrollRecord) => {
    setEditingBonus(record);
    setBonusValue(String(record.bonuses || 0));
  };

  const handleSaveBonus = async () => {
    if (!editingBonus) return;

    const amount = Number(bonusValue);
    if (!Number.isFinite(amount) || amount < 0) {
      alert("Please enter a valid bonus amount of 0 or more.");
      return;
    }

    setSavingBonus(true);
    try {
      const response = await fetch(`/api/payroll/${editingBonus._id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ bonuses: amount }),
      });
      const data = await response.json();
      if (!response.ok || !data.success) {
        alert(data.error || "Failed to update bonus");
        return;
      }
      setEditingBonus(null);
      setBonusValue("");
      fetchPayroll();
    } catch (error) {
      console.error("Failed to update bonus", error);
      alert("Failed to update bonus");
    } finally {
      setSavingBonus(false);
    }
  };

  const downloadPayslip = async (record: PayrollRecord) => {
    const userId = record.userId?._id;
    if (!userId) {
      alert("This payroll record is missing an employee ID.");
      return;
    }

    setDownloadingId(record._id);
    try {
      const response = await fetch(
        `/api/export/payslip/${userId}?month=${month}&year=${year}`,
        { cache: "no-store" }
      );

      if (!response.ok) {
        let message = "Unable to download this payslip right now.";
        try {
          const data = await response.json();
          if (data?.error) message = data.error;
        } catch {
          // Keep the friendly fallback instead of opening a raw error page.
        }
        alert(message);
        return;
      }

      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      const disposition = response.headers.get("content-disposition") || "";
      const match = disposition.match(/filename="?([^\"]+)"?/i);
      link.href = url;
      link.download = match?.[1] || `payslip-${month}-${year}.pdf`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Failed to download payslip", error);
      alert("Unable to download this payslip right now. Please try again.");
    } finally {
      setDownloadingId(null);
    }
  };

  // We use the overlay mode in the return block instead of an early return 
  // to avoid layout shifts and maintain a professional appearance while loading.

  return (
    <div className="relative space-y-6" style={{ minHeight: "400px" }}>
      {/* Overlay loader — blurs behind without shifting layout */}
      {loading && (
        <ChipLoader overlay size="md" label="Loading" />
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <h2 className="text-2xl font-bold">Payroll Management</h2>
        <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
          <select
            value={month}
            onChange={(e) => setMonth(parseInt(e.target.value))}
            className="flex-1 sm:flex-none px-3 py-2 rounded-lg bg-[var(--neu-surface)] border border-[var(--neu-border)] text-sm outline-none transition-colors hover:border-[var(--neu-accent)]/50 focus:border-[var(--neu-accent)]"
          >
            {Array.from({ length: 12 }, (_, i) => (
              <option key={i + 1} value={i + 1}>
                {new Date(0, i).toLocaleString("en-US", { month: "long" })}
              </option>
            ))}
          </select>
          <select
            value={year}
            onChange={(e) => setYear(parseInt(e.target.value))}
            className="flex-1 sm:flex-none px-3 py-2 rounded-lg bg-[var(--neu-surface)] border border-[var(--neu-border)] text-sm outline-none transition-colors hover:border-[var(--neu-accent)]/50 focus:border-[var(--neu-accent)]"
          >
            {[2024, 2025, 2026].map((y) => (
              <option key={y} value={y}>
                {y}
              </option>
            ))}
          </select>
          <NeuButton onClick={handleGenerate} loading={generating} variant="accent" className="w-full sm:w-auto">
            <DollarSign className="w-4 h-4" />
            Generate Payroll
          </NeuButton>
        </div>
      </div>

      {/* Payroll Table */}
      <NeuCard>
        <NeuCardContent className="p-6">
          {payroll.length === 0 ? (
            <EmptyState
              icon={DollarSign}
              title="No payroll records"
              description={`No payroll generated for ${new Date(year, month - 1).toLocaleString("en-US", { month: "long" })} ${year}. Click Generate Payroll to create.`}
            />
          ) : (
            <List2 
              items={payroll.map((record) => ({
                icon: <UserIcon className="w-5 h-5 text-[var(--neu-accent)]" />,
                title: record.userId?.name || "Unknown Employee",
                category: record.userId?.employeeId || "NO ID",
                description: (
                  <div className="flex flex-col gap-2">
                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm">
                      <span className="opacity-70">Basic: ${record.basicSalary.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                      <span className="flex items-center gap-1 text-[var(--neu-danger)]">
                        <TrendingDown className="w-3 h-3" />
                        Deductions: -${(record.absentDeduction + record.lateDeduction + record.unpaidLeaveDeduction).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </span>
                      <span className="flex items-center gap-1 text-[var(--neu-success)]">
                        <TrendingUp className="w-3 h-3" />
                        Bonus: +${record.bonuses.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </span>
                    </div>
                    {record.unpaidLeaveDays > 0 && (
                      <div className="text-xs text-[var(--neu-text-secondary)]">
                        Includes {record.unpaidLeaveDays} unpaid leave day{record.unpaidLeaveDays === 1 ? "" : "s"}: -${record.unpaidLeaveDeduction.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </div>
                    )}
                    <div className="text-xl font-black text-[var(--neu-text)]">
                      Net: <span className="text-[var(--neu-accent)]">${record.netSalary.toLocaleString()}</span>
                      <span className="text-xs font-normal opacity-50 ml-2">({record.presentDays} Days)</span>
                    </div>
                  </div>
                ),
                status: (
                  <div className="flex items-center gap-2">
                    <NeuBadge variant={record.status === "finalized" ? "success" : "warning"}>
                      {record.status.toUpperCase()}
                    </NeuBadge>
                    <div className="flex gap-1 ml-2">
                      {record.status === "draft" && (
                        <>
                          <NeuButton
                            size="icon"
                            variant="ghost"
                            onClick={() => openBonusDialog(record)}
                            className="h-8 w-8 text-[var(--neu-accent)] hover:bg-[var(--neu-accent)]/10"
                            title="Add or edit bonus"
                          >
                            <Pencil className="w-4 h-4" />
                          </NeuButton>
                          <NeuButton
                            size="icon"
                            variant="ghost"
                            onClick={() => handleFinalize(record._id)}
                            className="h-8 w-8 text-[var(--neu-success)] hover:bg-[var(--neu-success)]/10"
                            title="Finalize payroll"
                          >
                            <TrendingUp className="w-4 h-4" />
                          </NeuButton>
                        </>
                      )}
                      <NeuButton
                        size="icon"
                        variant="ghost"
                        onClick={() => downloadPayslip(record)}
                        loading={downloadingId === record._id}
                        className="h-8 w-8 opacity-70 hover:opacity-100"
                        title={record.status === "finalized" ? "Download payslip" : "Download draft preview"}
                      >
                        <Download className="w-4 h-4" />
                      </NeuButton>
                    </div>
                  </div>
                )
              }))}
            />
          )}
        </NeuCardContent>
      </NeuCard>

      <NeuDialog
        open={!!editingBonus}
        onClose={() => !savingBonus && setEditingBonus(null)}
        title="Adjust Employee Bonus"
      >
        <div className="space-y-4">
          <div className="flex items-center gap-3 rounded-xl border border-white/10 bg-white/5 p-4">
            <Gift className="h-5 w-5 text-[var(--neu-accent)]" />
            <div>
              <p className="font-semibold text-[var(--neu-text)]">{editingBonus?.userId?.name}</p>
              <p className="text-xs text-[var(--neu-text-secondary)]">
                Bonus is added to net salary before payroll is finalized.
              </p>
            </div>
          </div>
          <NeuInput
            label="Bonus Amount (SGD)"
            type="number"
            min="0"
            step="0.01"
            value={bonusValue}
            onChange={(e) => setBonusValue(e.target.value)}
            placeholder="e.g. 250"
          />
          <div className="flex gap-3 pt-2">
            <NeuButton variant="accent" onClick={handleSaveBonus} loading={savingBonus} className="flex-1">
              Save Bonus
            </NeuButton>
            <NeuButton variant="ghost" onClick={() => setEditingBonus(null)} disabled={savingBonus}>
              Cancel
            </NeuButton>
          </div>
        </div>
      </NeuDialog>
    </div>
  );
}
