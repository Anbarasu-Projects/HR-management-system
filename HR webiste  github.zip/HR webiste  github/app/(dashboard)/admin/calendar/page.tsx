"use client";

import { CalendarRange } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { DepartmentCalendar } from "@/components/leave/department-calendar";

export default function AdminCalendarPage() {
  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Organisation-wide"
        icon={<CalendarRange className="h-6 w-6" />}
        title="Leave Calendar"
        description="Approved leave across every department, with a warning when too many people are away at once."
      />

      {/* Admins can switch departments and see the whole organisation. */}
      <DepartmentCalendar allowDepartmentFilter />
    </div>
  );
}
