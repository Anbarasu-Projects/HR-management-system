import Link from "next/link";
import {
  ArrowRight,
  CalendarDays,
  ClipboardCheck,
  Wallet,
  Users,
  ShieldCheck,
  BarChart3,
  Building2,
  Bell,
  CheckCircle2,
} from "lucide-react";

/**
 * Marketing / entry page. Rendered on the server — no canvas, no particle
 * engine — so first paint is fast. All motion comes from CSS.
 */

const modules = [
  {
    icon: ShieldCheck,
    title: "Roles & Access",
    body: "Employee, Manager and HR each get their own portal, permissions and navigation.",
  },
  {
    icon: CalendarDays,
    title: "Leave Management",
    body: "Annual, medical, emergency and unpaid leave with balances, history and approvals.",
  },
  {
    icon: Users,
    title: "Department Calendar",
    body: "Approved leave lands on a shared calendar so teams can see who is away.",
  },
  {
    icon: Wallet,
    title: "Payroll",
    body: "Salary, allowances, bonuses and deductions roll into monthly payslips.",
  },
  {
    icon: Building2,
    title: "HR Administration",
    body: "Employees, departments, leave policies, holidays and reporting in one console.",
  },
  {
    icon: BarChart3,
    title: "Reports",
    body: "Attendance trends, department breakdowns and exportable monthly summaries.",
  },
];

const workflow = [
  "Employee submits a leave request",
  "Manager reviews team availability",
  "Approve or reject with a comment",
  "Balance and calendar update",
  "Unpaid leave adjusts payroll",
  "HR generates the payslip",
];

export default function Home() {
  return (
    <div className="relative flex min-h-screen flex-col">
      {/* ── Top bar ───────────────────────────────────────────── */}
      <header className="sticky top-0 z-50 border-b border-white/[0.07] bg-[rgba(8,10,22,0.7)] backdrop-blur-2xl">
        <div className="mx-auto flex h-16 w-full max-w-6xl items-center justify-between px-5">
          <Link href="/" className="flex items-center gap-2.5">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[linear-gradient(135deg,var(--accent-1),var(--accent-2))] text-sm font-black text-white shadow-[0_6px_18px_-6px_var(--neu-accent-glow)]">
              AE
            </span>
            <span className="text-base font-bold tracking-tight">AttendEase</span>
          </Link>

          <nav className="flex items-center gap-2">
            <Link
              href="/login"
              className="rounded-xl px-4 py-2 text-sm font-semibold text-[var(--neu-text-secondary)] transition-colors hover:text-[var(--neu-text)]"
            >
              Sign in
            </Link>
            <Link
              href="/register"
              className="inline-flex items-center gap-1.5 rounded-xl border border-white/10 bg-[linear-gradient(135deg,var(--accent-1),var(--accent-2))] px-4 py-2 text-sm font-semibold text-white shadow-[0_6px_20px_-6px_var(--neu-accent-glow)] transition-transform hover:-translate-y-0.5"
            >
              Get started
              <ArrowRight className="h-4 w-4" />
            </Link>
          </nav>
        </div>
      </header>

      <main className="relative z-10 mx-auto w-full max-w-6xl flex-1 px-5">
        {/* ── Hero ────────────────────────────────────────────── */}
        <section className="animate-rise py-20 text-center sm:py-28">
          <span className="eyebrow mb-6">HR · Leave · Payroll</span>

          <h1 className="mx-auto max-w-3xl text-4xl font-black leading-[1.08] tracking-tight sm:text-6xl">
            <span className="text-gradient">Leave requests, team calendars</span>
            <br />
            <span className="text-gradient-accent">and payroll in one place</span>
          </h1>

          <p className="mx-auto mt-6 max-w-xl text-base leading-relaxed text-[var(--neu-text-secondary)] sm:text-lg">
            Employees apply for leave and check their payslips. Managers approve
            requests knowing who else is away. HR runs payroll from the same data.
          </p>

          <div className="mt-9 flex flex-wrap items-center justify-center gap-3">
            <Link
              href="/login"
              className="inline-flex items-center gap-2 rounded-xl border border-white/10 bg-[linear-gradient(135deg,var(--accent-1),var(--accent-2))] px-6 py-3 text-sm font-semibold text-white shadow-[0_10px_30px_-8px_var(--neu-accent-glow)] transition-transform hover:-translate-y-0.5"
            >
              Open the portal
              <ArrowRight className="h-4 w-4" />
            </Link>
            <Link
              href="#modules"
              className="inline-flex items-center gap-2 rounded-xl border border-white/[0.14] bg-white/[0.04] px-6 py-3 text-sm font-semibold text-[var(--neu-text)] backdrop-blur-md transition-colors hover:bg-white/[0.08]"
            >
              See the modules
            </Link>
          </div>
        </section>

        {/* ── The two portals ─────────────────────────────────── */}
        <section className="grid gap-5 pb-6 md:grid-cols-2">
          {/* Employee — cyan ramp */}
          <div
            data-portal="employee"
            className="glass gradient-border hover-sheen group relative overflow-hidden rounded-[var(--neu-radius-lg)] p-7 transition-transform duration-300 hover:-translate-y-1"
          >
            <div
              aria-hidden
              className="pointer-events-none absolute -right-14 -top-16 h-48 w-48 rounded-full bg-[linear-gradient(135deg,var(--accent-1),var(--accent-2))] opacity-25 blur-3xl"
            />
            <div className="relative">
              <span className="mb-5 flex h-12 w-12 items-center justify-center rounded-2xl bg-[linear-gradient(135deg,var(--accent-1),var(--accent-2))] text-[#04231a] shadow-[0_8px_24px_-8px_var(--neu-accent-glow)]">
                <ClipboardCheck className="h-6 w-6" />
              </span>

              <span className="eyebrow mb-3">Employee portal</span>
              <h2 className="text-xl font-bold tracking-tight">Everything about your time</h2>
              <p className="mt-2 text-sm leading-relaxed text-[var(--neu-text-secondary)]">
                Apply for leave, watch the balance update, see which colleagues are
                away and download payslips.
              </p>

              <ul className="mt-5 space-y-2.5">
                {[
                  "Apply for annual, medical, emergency or unpaid leave",
                  "Track approval status and cancel pending requests",
                  "Department calendar of approved leave",
                  "Monthly salary, allowances and payslip downloads",
                ].map((line) => (
                  <li key={line} className="flex items-start gap-2.5 text-sm text-[var(--neu-text-secondary)]">
                    <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-[var(--neu-accent)]" />
                    {line}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Admin — violet ramp */}
          <div
            data-portal="admin"
            className="glass gradient-border hover-sheen group relative overflow-hidden rounded-[var(--neu-radius-lg)] p-7 transition-transform duration-300 hover:-translate-y-1"
          >
            <div
              aria-hidden
              className="pointer-events-none absolute -right-14 -top-16 h-48 w-48 rounded-full bg-[linear-gradient(135deg,var(--accent-1),var(--accent-2))] opacity-25 blur-3xl"
            />
            <div className="relative">
              <span className="mb-5 flex h-12 w-12 items-center justify-center rounded-2xl bg-[linear-gradient(135deg,var(--accent-1),var(--accent-2))] text-white shadow-[0_8px_24px_-8px_var(--neu-accent-glow)]">
                <ShieldCheck className="h-6 w-6" />
              </span>

              <span className="eyebrow mb-3">Manager &amp; HR console</span>
              <h2 className="text-xl font-bold tracking-tight">Approve, staff and pay</h2>
              <p className="mt-2 text-sm leading-relaxed text-[var(--neu-text-secondary)]">
                Review requests with full context, keep departments covered and run
                payroll off approved leave.
              </p>

              <ul className="mt-5 space-y-2.5">
                {[
                  "Approve or reject with comments and balance context",
                  "Warnings when too many people book the same dates",
                  "Employees, departments, shifts and leave policies",
                  "Monthly payroll, payslips and exportable reports",
                ].map((line) => (
                  <li key={line} className="flex items-start gap-2.5 text-sm text-[var(--neu-text-secondary)]">
                    <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-[var(--neu-accent)]" />
                    {line}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        {/* ── Modules ─────────────────────────────────────────── */}
        <section id="modules" className="scroll-mt-24 py-16">
          <div className="mb-10 text-center">
            <span className="eyebrow mb-4">Modules</span>
            <h2 className="text-3xl font-bold tracking-tight text-gradient sm:text-4xl">
              One system, five moving parts
            </h2>
            <p className="mx-auto mt-3 max-w-xl text-sm text-[var(--neu-text-secondary)]">
              Each module feeds the next, so an approved leave request reaches the
              calendar and the payslip without anyone re-keying it.
            </p>
          </div>

          <div className="stagger grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {modules.map(({ icon: Icon, title, body }) => (
              <div
                key={title}
                className="glass gradient-border hover-sheen group rounded-[var(--neu-radius)] p-6 transition-transform duration-300 hover:-translate-y-1"
              >
                <span className="mb-4 flex h-11 w-11 items-center justify-center rounded-xl bg-[var(--neu-accent-soft)] text-[var(--neu-accent)] transition-transform duration-300 group-hover:scale-110">
                  <Icon className="h-5 w-5" />
                </span>
                <h3 className="text-base font-semibold tracking-tight">{title}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-[var(--neu-text-secondary)]">
                  {body}
                </p>
              </div>
            ))}
          </div>
        </section>

        {/* ── Workflow ────────────────────────────────────────── */}
        <section className="pb-20">
          <div className="glass gradient-border relative overflow-hidden rounded-[var(--neu-radius-lg)] p-7 sm:p-10">
            <div
              aria-hidden
              className="pointer-events-none absolute -left-20 -top-24 h-64 w-64 rounded-full bg-[var(--accent-1)] opacity-20 blur-3xl"
            />

            <div className="relative">
              <span className="eyebrow mb-4">Workflow</span>
              <h2 className="max-w-lg text-2xl font-bold tracking-tight sm:text-3xl">
                From request to payslip
              </h2>

              <ol className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {workflow.map((step, i) => (
                  <li
                    key={step}
                    className="flex items-start gap-3 rounded-xl border border-white/[0.08] bg-white/[0.03] p-4"
                  >
                    <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-[linear-gradient(135deg,var(--accent-1),var(--accent-2))] text-xs font-bold text-white">
                      {i + 1}
                    </span>
                    <span className="text-sm leading-snug text-[var(--neu-text-secondary)]">
                      {step}
                    </span>
                  </li>
                ))}
              </ol>

              <div className="mt-9 flex flex-wrap items-center gap-3">
                <Link
                  href="/login"
                  className="inline-flex items-center gap-2 rounded-xl border border-white/10 bg-[linear-gradient(135deg,var(--accent-1),var(--accent-2))] px-6 py-3 text-sm font-semibold text-white shadow-[0_10px_30px_-8px_var(--neu-accent-glow)] transition-transform hover:-translate-y-0.5"
                >
                  Sign in to your portal
                  <ArrowRight className="h-4 w-4" />
                </Link>
                <span className="inline-flex items-center gap-2 text-sm text-[var(--neu-text-muted)]">
                  <Bell className="h-4 w-4" />
                  Email and in-app notifications included
                </span>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* ── Footer ──────────────────────────────────────────── */}
      <footer className="border-t border-white/[0.07] py-8">
        <div className="mx-auto flex w-full max-w-6xl flex-col items-center justify-between gap-3 px-5 text-sm text-[var(--neu-text-muted)] sm:flex-row">
          <p>AttendEase — HR, Leave &amp; Payroll Management System</p>
          <div className="flex gap-5">
            <Link href="/login" className="transition-colors hover:text-[var(--neu-text)]">
              Sign in
            </Link>
            <Link href="/register" className="transition-colors hover:text-[var(--neu-text)]">
              Register
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
