import { NextRequest, NextResponse } from "next/server";
import connectDB from "@/lib/db";
import { requireAuth } from "@/lib/middleware-helpers";
import Payroll from "@/models/Payroll";
import { ApiResponse } from "@/types";

// GET /api/payroll/my - Get the signed-in employee's published payslips.
// Draft payroll is intentionally hidden from employees until HR finalizes it.
export async function GET(
  request: NextRequest
): Promise<NextResponse<ApiResponse<unknown>>> {
  try {
    const user = await requireAuth(request);
    if (user instanceof NextResponse) {
      return user;
    }

    await connectDB();

    const { searchParams } = new URL(request.url);
    const month = Number.parseInt(searchParams.get("month") || "0", 10);
    const year = Number.parseInt(searchParams.get("year") || "0", 10);

    const query: Record<string, unknown> = {
      userId: user.userId,
      status: "finalized",
    };

    if (month >= 1 && month <= 12) query.month = month;
    if (year > 0) query.year = year;

    // Populate only the two employee fields needed by the payslip screen so
    // the client does not need a second /api/auth/me request.
    const payrolls = await Payroll.find(query)
      .populate("userId", "name employeeId")
      .sort({ year: -1, month: -1 })
      .lean();

    return NextResponse.json(
      {
        success: true,
        data: payrolls,
      },
      {
        status: 200,
        headers: { "Cache-Control": "private, no-store" },
      }
    );
  } catch (error) {
    console.error("Get my payroll error:", error);
    return NextResponse.json(
      {
        success: false,
        error: "Payslips are temporarily unavailable",
        code: "SERVER_ERROR",
      },
      { status: 500 }
    );
  }
}
