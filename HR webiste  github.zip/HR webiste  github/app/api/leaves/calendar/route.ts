import { NextRequest, NextResponse } from "next/server";
import mongoose from "mongoose";
import connectDB from "@/lib/db";
import { requireAuth } from "@/lib/middleware-helpers";
import Leave from "@/models/Leave";
import User from "@/models/User";
import Department from "@/models/Department";
import { ApiResponse } from "@/types";

/**
 * GET /api/leaves/calendar?month=YYYY-MM[&department=<departmentId>]
 *
 * Returns approved leave for the month so the shared department calendar can
 * show who is away.
 *
 * Visibility rules:
 *   - employee -> locked to their own department
 *   - admin    -> every department, optionally filtered by department id
 */

interface CalendarEntry {
  leaveId: string;
  userId: string;
  name: string;
  employeeId?: string;
  department: string;
  leaveType: string;
  startDate: string;
  endDate: string;
  totalDays: number;
  durationType?: "full-day" | "half-day";
  startTime?: string;
  endTime?: string;
}

interface DepartmentOption {
  id: string;
  name: string;
}

interface CalendarPayload {
  month: string;
  /** Friendly department name the viewer is scoped to, or null for all. */
  scope: string | null;
  /** Departments an admin may switch between. */
  departments: DepartmentOption[];
  entries: CalendarEntry[];
}

export async function GET(
  request: NextRequest
): Promise<NextResponse<ApiResponse<CalendarPayload>>> {
  try {
    const authResult = await requireAuth(request);
    if (authResult instanceof NextResponse) {
      return authResult;
    }

    await connectDB();

    const { searchParams } = new URL(request.url);
    const month = searchParams.get("month") || new Date().toISOString().slice(0, 7);

    const [yearStr, monthStr] = month.split("-");
    const year = Number(yearStr);
    const monthNum = Number(monthStr);

    if (!year || !monthNum || monthNum < 1 || monthNum > 12) {
      return NextResponse.json(
        { success: false, error: "Invalid month. Expected YYYY-MM." },
        { status: 400 }
      );
    }

    const monthStart = new Date(year, monthNum - 1, 1, 0, 0, 0, 0);
    const monthEnd = new Date(year, monthNum, 0, 23, 59, 59, 999);
    const isAdmin = authResult.role === "admin";

    let scopeDepartmentId: string | null = null;
    let scope: string | null = null;

    if (isAdmin) {
      const requestedDepartment = searchParams.get("department");
      if (requestedDepartment) {
        const departmentDoc = mongoose.Types.ObjectId.isValid(requestedDepartment)
          ? await Department.findById(requestedDepartment).select("name").lean<any>()
          : await Department.findOne({
              name: { $regex: new RegExp(`^${requestedDepartment.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}$`, "i") },
            })
              .select("name")
              .lean<any>();

        if (departmentDoc) {
          scopeDepartmentId = String(departmentDoc._id);
          scope = departmentDoc.name;
        }
      }
    } else {
      const viewer = await User.findById(authResult.userId)
        .select("department")
        .populate("department", "name")
        .lean<any>();

      if (viewer?.department) {
        if (typeof viewer.department === "object" && viewer.department._id) {
          scopeDepartmentId = String(viewer.department._id);
          scope = viewer.department.name || "Department";
        } else {
          const departmentId = String(viewer.department);
          const departmentDoc = mongoose.Types.ObjectId.isValid(departmentId)
            ? await Department.findById(departmentId).select("name").lean<any>()
            : null;
          scopeDepartmentId = departmentId;
          scope = departmentDoc?.name || "Department";
        }
      }
    }

    const userFilter: Record<string, unknown> = { isActive: { $ne: false } };
    if (scopeDepartmentId) {
      userFilter.department = scopeDepartmentId;
    }

    const visibleUsers = await User.find(userFilter)
      .select("_id name employeeId department")
      .populate("department", "name")
      .lean<any[]>();

    const userIds = visibleUsers.map((user) => user._id);
    const userLookup = new Map(
      visibleUsers.map((user) => {
        const departmentName =
          user.department && typeof user.department === "object"
            ? user.department.name || "Unassigned"
            : "Unassigned";

        return [
          String(user._id),
          {
            name: user.name || "Unknown",
            employeeId: user.employeeId as string | undefined,
            department: departmentName,
          },
        ] as const;
      })
    );

    const leaves = await Leave.find({
      status: "approved",
      userId: { $in: userIds },
      startDate: { $lte: monthEnd },
      endDate: { $gte: monthStart },
    })
      .select("userId leaveType startDate endDate totalDays durationType startTime endTime")
      .sort({ startDate: 1 })
      .lean<any[]>();

    const entries: CalendarEntry[] = leaves.map((leave) => {
      const userId = String(leave.userId);
      const user = userLookup.get(userId);

      return {
        leaveId: String(leave._id),
        userId,
        name: user?.name ?? "Unknown",
        employeeId: user?.employeeId,
        department: user?.department ?? "Unassigned",
        leaveType: String(leave.leaveType),
        startDate: new Date(leave.startDate).toISOString(),
        endDate: new Date(leave.endDate).toISOString(),
        totalDays: Number(leave.totalDays),
        durationType: leave.durationType || "full-day",
        startTime: leave.startTime || undefined,
        endTime: leave.endTime || undefined,
      };
    });

    const departments: DepartmentOption[] = isAdmin
      ? (await Department.find({ isActive: { $ne: false } })
          .select("_id name")
          .sort({ name: 1 })
          .lean<any[]>()).map((department) => ({
          id: String(department._id),
          name: department.name,
        }))
      : [];

    return NextResponse.json({
      success: true,
      data: { month, scope, departments, entries },
    });
  } catch (error) {
    console.error("Leave calendar error:", error);
    return NextResponse.json(
      { success: false, error: "Failed to load the leave calendar" },
      { status: 500 }
    );
  }
}
