import { NextRequest, NextResponse } from "next/server";
import connectDB from "@/lib/db";
import { requireAuth } from "@/lib/middleware-helpers";
import Leave from "@/models/Leave";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const auth = await requireAuth(request);
    if (auth instanceof NextResponse) return auth;

    const { id } = await params;
    await connectDB();

    const leave = await Leave.findById(id).select("userId medicalDocument leaveType");
    if (!leave) {
      return NextResponse.json({ success: false, error: "Leave request not found" }, { status: 404 });
    }

    if (auth.role !== "admin" && String(leave.userId) !== auth.userId) {
      return NextResponse.json({ success: false, error: "You do not have access to this document" }, { status: 403 });
    }

    const doc = leave.medicalDocument;
    if (!doc?.data || !doc.fileName || !doc.mimeType) {
      return NextResponse.json({ success: false, error: "No medical document attached" }, { status: 404 });
    }

    const safeName = doc.fileName.replace(/[\r\n"]/g, "_");
    const binary = Buffer.from(doc.data);
    return new NextResponse(new Uint8Array(binary), {
      status: 200,
      headers: {
        "Content-Type": doc.mimeType,
        "Content-Length": String(doc.size || binary.length),
        "Content-Disposition": `attachment; filename="${safeName}"`,
        "Cache-Control": "private, no-store",
      },
    });
  } catch (error) {
    console.error("Medical document download error:", error);
    return NextResponse.json({ success: false, error: "Failed to download medical document" }, { status: 500 });
  }
}
