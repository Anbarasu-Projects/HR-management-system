import { NextRequest, NextResponse } from "next/server";
import connectDB from "@/lib/db";
import { requireAuth, requireAdmin } from "@/lib/middleware-helpers";
import Leave from "@/models/Leave";
import User from "@/models/User";
import Attendance from "@/models/Attendance";
import { ApiResponse, ApproveLeaveBody } from "@/types";
import { createNotification } from "@/lib/notifications";

// PUT /api/leaves/[id]/approve - Admin approves leave
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
): Promise<NextResponse<ApiResponse<unknown>>> {
  try {
    // Check admin authorization
    const authResult = await requireAdmin(request);
    if (authResult instanceof NextResponse) {
      return authResult;
    }

    const adminId = authResult.userId;
    const { id } = await params;
    const body: ApproveLeaveBody = await request.json();

    await connectDB();

    // Find leave request
    const leave = await Leave.findById(id);
    if (!leave) {
      return NextResponse.json(
        {
          success: false,
          error: "Leave request not found",
          code: "NOT_FOUND",
        },
        { status: 404 }
      );
    }

    if (leave.status !== "pending") {
      return NextResponse.json(
        {
          success: false,
          error: `Leave request is already ${leave.status}`,
          code: "INVALID_STATUS",
        },
        { status: 400 }
      );
    }

    // Deduct leave balance (skip for unpaid)
    if (leave.leaveType !== "unpaid") {
      const user = await User.findById(leave.userId);
      if (!user) {
        return NextResponse.json(
          { success: false, error: "Employee account not found", code: "NOT_FOUND" },
          { status: 404 }
        );
      }

      const normalizedBalance = {
        annual: user.leaveBalance?.annual ?? 20,
        sick: user.leaveBalance?.sick ?? 10,
        casual: user.leaveBalance?.casual ?? 5,
      };
      const leaveType = leave.leaveType as keyof typeof normalizedBalance;
      const available = normalizedBalance[leaveType] || 0;

      if (leave.totalDays > available) {
        return NextResponse.json(
          {
            success: false,
            error: `Employee has insufficient ${leave.leaveType} leave balance. Available: ${available}, Requested: ${leave.totalDays}`,
            code: "INSUFFICIENT_BALANCE",
          },
          { status: 400 }
        );
      }

      normalizedBalance[leaveType] = available - leave.totalDays;
      user.leaveBalance = normalizedBalance;
      await user.save();
    }

    // Approve leave
    leave.status = "approved";
    leave.approvedBy = adminId;
    leave.adminComment = body.adminComment || "";
    await leave.save();

    // Create attendance records for the approved leave period.
    // Half-day leave creates a half-day attendance marker on the selected date.
    const startDate = new Date(leave.startDate);
    const endDate = new Date(leave.endDate);
    const attendanceRecords = [];

    if (leave.durationType === "half-day") {
      const dateStr = startDate.toISOString().split("T")[0];
      const existing = await Attendance.findOne({ userId: leave.userId, date: dateStr });
      if (!existing) {
        attendanceRecords.push({
          userId: leave.userId,
          date: dateStr,
          checkIn: null,
          checkOut: null,
          status: "half-day",
          hoursWorked: 0,
          workingMinutes: 0,
          notes: `Half-day ${leave.leaveType} leave (${leave.startTime || ""}–${leave.endTime || ""})`,
        });
      }
    } else {
      for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
        const dayOfWeek = d.getDay();
        if (dayOfWeek !== 0 && dayOfWeek !== 6) {
          const dateStr = d.toISOString().split("T")[0];
          const existing = await Attendance.findOne({ userId: leave.userId, date: dateStr });

          if (!existing) {
            attendanceRecords.push({
              userId: leave.userId,
              date: dateStr,
              checkIn: null,
              checkOut: null,
              status: "on-leave",
              hoursWorked: 0,
              workingMinutes: 0,
              notes: `On ${leave.leaveType} leave`,
            });
          }
        }
      }
    }

    if (attendanceRecords.length > 0) {
      await Attendance.insertMany(attendanceRecords);
    }

    // Create notification for the user
    await createNotification({
      userId: leave.userId,
      title: "Leave Approved",
      message: leave.durationType === "half-day"
        ? `Your half-day ${leave.leaveType} leave for ${startDate.toLocaleDateString()} (${leave.startTime}–${leave.endTime}) has been approved.`
        : `Your ${leave.leaveType} leave for ${startDate.toLocaleDateString()} to ${endDate.toLocaleDateString()} has been approved.`,
      type: "success",
      link: "/employee/leaves",
    });

    const populatedLeave = await Leave.findById(leave._id)
      .select("-medicalDocument.data")
      .populate("userId", "name email")
      .populate("approvedBy", "name")
      .lean();

    return NextResponse.json(
      {
        success: true,
        data: populatedLeave,
        message: "Leave request approved successfully",
      },
      { status: 200 }
    );
  } catch (error) {
    console.error("Approve leave error:", error);
    const message = error instanceof Error ? error.message : "Unknown approval error";
    return NextResponse.json(
      {
        success: false,
        error: `Failed to approve leave: ${message}`,
        code: "SERVER_ERROR",
      },
      { status: 500 }
    );
  }
}
