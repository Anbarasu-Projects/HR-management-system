import { NextRequest, NextResponse } from "next/server";
import connectDB from "@/lib/db";
import { requireAuth } from "@/lib/middleware-helpers";
import Leave from "@/models/Leave";
import User from "@/models/User";
import Notification from "@/models/Notification";
import { ApiResponse, LeaveDuration, LeaveType } from "@/types";

const MAX_MEDICAL_FILE_SIZE = 5 * 1024 * 1024;
const ALLOWED_MEDICAL_TYPES = new Set([
  "application/pdf",
  "image/jpeg",
  "image/png",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
]);

function calculateWorkingDays(startDate: Date, endDate: Date): number {
  let count = 0;
  const curDate = new Date(startDate);
  const end = new Date(endDate);

  while (curDate <= end) {
    const dayOfWeek = curDate.getDay();
    if (dayOfWeek !== 0 && dayOfWeek !== 6) count++;
    curDate.setDate(curDate.getDate() + 1);
  }
  return count;
}

function isValidTime(value: string): boolean {
  return /^([01]\d|2[0-3]):[0-5]\d$/.test(value);
}

function minutes(value: string): number {
  const [hours, mins] = value.split(":").map(Number);
  return hours * 60 + mins;
}

async function parseLeaveRequest(request: NextRequest) {
  const contentType = request.headers.get("content-type") || "";

  if (contentType.includes("multipart/form-data")) {
    const form = await request.formData();
    const file = form.get("medicalDocument");
    return {
      leaveType: String(form.get("leaveType") || "") as LeaveType,
      startDate: String(form.get("startDate") || ""),
      endDate: String(form.get("endDate") || ""),
      reason: String(form.get("reason") || ""),
      durationType: (String(form.get("durationType") || "full-day") as LeaveDuration),
      startTime: String(form.get("startTime") || ""),
      endTime: String(form.get("endTime") || ""),
      medicalFile: file instanceof File && file.size > 0 ? file : null,
    };
  }

  const body = await request.json();
  return {
    leaveType: String(body.leaveType || "") as LeaveType,
    startDate: String(body.startDate || ""),
    endDate: String(body.endDate || ""),
    reason: String(body.reason || ""),
    durationType: (body.durationType || "full-day") as LeaveDuration,
    startTime: String(body.startTime || ""),
    endTime: String(body.endTime || ""),
    medicalFile: null as File | null,
  };
}

// POST /api/leaves/apply - Employee applies for leave
export async function POST(
  request: NextRequest
): Promise<NextResponse<ApiResponse<unknown>>> {
  try {
    const user = await requireAuth(request);
    if (user instanceof NextResponse) return user;

    const payload = await parseLeaveRequest(request);
    const { leaveType, startDate, reason, durationType, startTime, endTime, medicalFile } = payload;
    const endDate = durationType === "half-day" ? startDate : payload.endDate;

    if (!leaveType || !startDate || !endDate || !reason.trim()) {
      return NextResponse.json(
        { success: false, error: "Leave type, date, and reason are required", code: "VALIDATION_ERROR" },
        { status: 400 }
      );
    }

    if (!["annual", "sick", "casual", "unpaid"].includes(leaveType)) {
      return NextResponse.json(
        { success: false, error: "Invalid leave type", code: "VALIDATION_ERROR" },
        { status: 400 }
      );
    }

    if (!["full-day", "half-day"].includes(durationType)) {
      return NextResponse.json(
        { success: false, error: "Invalid leave duration", code: "VALIDATION_ERROR" },
        { status: 400 }
      );
    }

    const start = new Date(`${startDate}T00:00:00`);
    const end = new Date(`${endDate}T00:00:00`);
    if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) {
      return NextResponse.json(
        { success: false, error: "Please choose valid leave dates", code: "VALIDATION_ERROR" },
        { status: 400 }
      );
    }

    if (start > end) {
      return NextResponse.json(
        { success: false, error: "End date must be after start date", code: "VALIDATION_ERROR" },
        { status: 400 }
      );
    }

    let totalDays: number;
    if (durationType === "half-day") {
      if (!startTime || !endTime || !isValidTime(startTime) || !isValidTime(endTime)) {
        return NextResponse.json(
          { success: false, error: "Half-day leave requires a valid start and end time", code: "VALIDATION_ERROR" },
          { status: 400 }
        );
      }
      if (minutes(endTime) <= minutes(startTime)) {
        return NextResponse.json(
          { success: false, error: "Half-day end time must be later than the start time", code: "VALIDATION_ERROR" },
          { status: 400 }
        );
      }
      if (start.getDay() === 0 || start.getDay() === 6) {
        return NextResponse.json(
          { success: false, error: "Half-day leave must be on a working day", code: "VALIDATION_ERROR" },
          { status: 400 }
        );
      }
      totalDays = 0.5;
    } else {
      totalDays = calculateWorkingDays(start, end);
      if (totalDays < 1) {
        return NextResponse.json(
          { success: false, error: "The selected dates do not include a working day", code: "VALIDATION_ERROR" },
          { status: 400 }
        );
      }
    }

    let medicalDocument:
      | { fileName: string; mimeType: string; size: number; data: Buffer }
      | undefined;

    if (medicalFile) {
      if (leaveType !== "sick") {
        return NextResponse.json(
          { success: false, error: "Medical documents can only be attached to sick leave", code: "VALIDATION_ERROR" },
          { status: 400 }
        );
      }
      if (!ALLOWED_MEDICAL_TYPES.has(medicalFile.type)) {
        return NextResponse.json(
          { success: false, error: "Medical document must be PDF, JPG, PNG, DOC, or DOCX", code: "INVALID_FILE_TYPE" },
          { status: 400 }
        );
      }
      if (medicalFile.size > MAX_MEDICAL_FILE_SIZE) {
        return NextResponse.json(
          { success: false, error: "Medical document must be 5 MB or smaller", code: "FILE_TOO_LARGE" },
          { status: 400 }
        );
      }
      medicalDocument = {
        fileName: medicalFile.name.replace(/[\r\n"]/g, "_").slice(0, 180),
        mimeType: medicalFile.type,
        size: medicalFile.size,
        data: Buffer.from(await medicalFile.arrayBuffer()),
      };
    }

    await connectDB();

    if (leaveType !== "unpaid") {
      const userDoc = await User.findById(user.userId);
      if (!userDoc) {
        return NextResponse.json(
          { success: false, error: "Employee account not found", code: "NOT_FOUND" },
          { status: 404 }
        );
      }

      const normalizedBalance = {
        annual: userDoc.leaveBalance?.annual ?? 20,
        sick: userDoc.leaveBalance?.sick ?? 10,
        casual: userDoc.leaveBalance?.casual ?? 5,
      };

      if (
        userDoc.leaveBalance?.annual == null ||
        userDoc.leaveBalance?.sick == null ||
        userDoc.leaveBalance?.casual == null
      ) {
        userDoc.leaveBalance = normalizedBalance;
        await userDoc.save();
      }

      const available = normalizedBalance[leaveType as keyof typeof normalizedBalance] || 0;
      if (totalDays > available) {
        return NextResponse.json(
          {
            success: false,
            error: `Insufficient ${leaveType} leave balance. Available: ${available}, Requested: ${totalDays}`,
            code: "INSUFFICIENT_BALANCE",
          },
          { status: 400 }
        );
      }
    }

    const overlapping = await Leave.findOne({
      userId: user.userId,
      status: { $in: ["pending", "approved"] },
      startDate: { $lte: end },
      endDate: { $gte: start },
    });

    if (overlapping) {
      return NextResponse.json(
        { success: false, error: "You have an overlapping leave request for this period", code: "OVERLAPPING_LEAVE" },
        { status: 409 }
      );
    }

    const leave = await Leave.create({
      userId: user.userId,
      leaveType,
      startDate: start,
      endDate: end,
      totalDays,
      durationType,
      startTime: durationType === "half-day" ? startTime : null,
      endTime: durationType === "half-day" ? endTime : null,
      medicalDocument,
      reason: reason.trim(),
      status: "pending",
    });

    const populatedLeave = await Leave.findById(leave._id)
      .select("-medicalDocument.data")
      .populate("userId", "name email")
      .lean();

    try {
      const admins = await User.find({ role: "admin", isActive: true }).select("_id").lean();
      const applicant = populatedLeave?.userId as unknown as { name?: string } | undefined;
      const applicantName = applicant?.name || "An employee";
      const label = leaveType === "sick" ? "Sick" : leaveType.charAt(0).toUpperCase() + leaveType.slice(1);
      const dateLabel = durationType === "half-day"
        ? `${start.toLocaleDateString("en-SG")} · ${startTime}–${endTime} (half day)`
        : `${start.toLocaleDateString("en-SG")} – ${end.toLocaleDateString("en-SG")}`;

      if (admins.length > 0) {
        await Notification.insertMany(
          admins.map((admin) => ({
            userId: admin._id,
            title: "New leave request",
            message: `${applicantName} applied for ${label} leave (${dateLabel}).`,
            type: "info",
            isRead: false,
            link: "/admin/leaves",
          }))
        );
      }
    } catch (notificationError) {
      console.error("Leave admin notification error:", notificationError);
    }

    return NextResponse.json(
      { success: true, data: populatedLeave, message: "Leave application submitted successfully" },
      { status: 201 }
    );
  } catch (error) {
    console.error("Apply leave error:", error);
    return NextResponse.json(
      { success: false, error: "Failed to apply for leave", code: "SERVER_ERROR" },
      { status: 500 }
    );
  }
}
