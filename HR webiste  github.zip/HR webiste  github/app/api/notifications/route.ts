import { NextRequest, NextResponse } from "next/server";
import connectDB from "@/lib/db";
import { requireAuth } from "@/lib/middleware-helpers";
import Notification from "@/models/Notification";
import User from "@/models/User";
import { ApiResponse } from "@/types";

function startOfTodayUtc(): Date {
  const now = new Date();
  return new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
}

function getNextBirthday(birthday: Date, today: Date): Date {
  let next = new Date(Date.UTC(today.getUTCFullYear(), birthday.getUTCMonth(), birthday.getUTCDate()));
  if (next.getTime() < today.getTime()) {
    next = new Date(Date.UTC(today.getUTCFullYear() + 1, birthday.getUTCMonth(), birthday.getUTCDate()));
  }
  return next;
}

async function ensureAdminBirthdayReminders(adminId: string) {
  const today = startOfTodayUtc();
  const employees = await User.find({
    role: "employee",
    isActive: { $ne: false },
    birthday: { $ne: null },
  })
    .select("name birthday department")
    .populate("department", "name")
    .lean<any[]>();

  const nearBirthdays = employees
    .map((employee) => {
      const birthday = new Date(employee.birthday);
      const nextBirthday = getNextBirthday(birthday, today);
      const daysUntil = Math.round((nextBirthday.getTime() - today.getTime()) / 86400000);
      return { employee, nextBirthday, daysUntil };
    })
    .filter(({ daysUntil }) => daysUntil >= 0 && daysUntil <= 2);

  await Promise.all(
    nearBirthdays.map(async ({ employee, nextBirthday, daysUntil }) => {
      const dayLabel = nextBirthday.toISOString().slice(0, 10);
      const dedupeKey = `birthday:${String(employee._id)}:${dayLabel}`;
      const departmentName =
        employee.department && typeof employee.department === "object"
          ? employee.department.name
          : null;
      const timing = daysUntil === 0 ? "today" : daysUntil === 1 ? "tomorrow" : "in 2 days";

      try {
        await Notification.updateOne(
          { userId: adminId, dedupeKey },
          {
            $setOnInsert: {
              userId: adminId,
              title: "🎉 Birthday coming up!",
              message: `${employee.name}'s birthday is ${timing}${departmentName ? ` · ${departmentName}` : ""}. Time to celebrate! 🎂`,
              type: "success",
              isRead: false,
              link: "/admin",
              dedupeKey,
            },
          },
          { upsert: true }
        );
      } catch (error: any) {
        // A duplicate-key race is harmless; the reminder already exists.
        if (error?.code !== 11000) throw error;
      }
    })
  );
}

// POST /api/notifications - Create a notification (internal/admin use)
export async function POST(
  request: NextRequest
): Promise<NextResponse<ApiResponse<unknown>>> {
  try {
    const body = await request.json();
    const { userId, title, message, type, link, dedupeKey } = body;

    if (!userId || !title || !message) {
      return NextResponse.json(
        { success: false, error: "UserId, title, and message are required", code: "VALIDATION_ERROR" },
        { status: 400 }
      );
    }

    await connectDB();
    const notification = await Notification.create({
      userId,
      title,
      message,
      type: type || "info",
      link,
      ...(dedupeKey ? { dedupeKey } : {}),
      isRead: false,
    });

    return NextResponse.json({ success: true, data: notification }, { status: 201 });
  } catch (error) {
    console.error("Create notification error:", error);
    return NextResponse.json(
      { success: false, error: "Failed to create notification", code: "SERVER_ERROR" },
      { status: 500 }
    );
  }
}

// GET /api/notifications - Get the signed-in user's notifications.
// Admin reads also create one deduplicated birthday reminder when a birthday is 0-2 days away.
export async function GET(
  request: NextRequest
): Promise<NextResponse<ApiResponse<unknown>>> {
  try {
    const user = await requireAuth(request);
    if (user instanceof NextResponse) return user;

    const { searchParams } = new URL(request.url);
    const unreadOnly = searchParams.get("unreadOnly") === "true";
    const limit = Math.min(50, Math.max(1, parseInt(searchParams.get("limit") || "20")));

    await connectDB();

    if (user.role === "admin") {
      try {
        await ensureAdminBirthdayReminders(user.userId);
      } catch (birthdayError) {
        // Birthday reminder generation must never block the regular notification list.
        console.error("Birthday reminder generation error:", birthdayError);
      }
    }

    const query: Record<string, unknown> = { userId: user.userId };
    if (unreadOnly) query.isRead = false;

    const [notifications, unreadCount] = await Promise.all([
      Notification.find(query).sort({ createdAt: -1 }).limit(limit).lean(),
      Notification.countDocuments({ userId: user.userId, isRead: false }),
    ]);

    return NextResponse.json(
      { success: true, data: notifications, unreadCount },
      {
        status: 200,
        headers: {
          "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
          Vary: "Cookie",
        },
      }
    );
  } catch (error) {
    console.error("Get notifications error:", error);
    return NextResponse.json(
      { success: false, error: "Failed to fetch notifications", code: "SERVER_ERROR" },
      { status: 500 }
    );
  }
}
