import { NextRequest, NextResponse } from "next/server";
import connectDB from "@/lib/db";
import { requireAuth } from "@/lib/middleware-helpers";
import Payroll from "@/models/Payroll";
import User from "@/models/User";
import { jsPDF } from "jspdf";

// PDF generation relies on Node.js APIs/Buffer-compatible output.
export const runtime = "nodejs";

const money = (value: unknown) => {
  const amount = typeof value === "number" && Number.isFinite(value) ? value : 0;
  return `$${amount.toFixed(2)}`;
};

function drawMoneyRow(
  doc: jsPDF,
  label: string,
  value: string,
  y: number,
  options?: { bold?: boolean; negative?: boolean; positive?: boolean }
) {
  if (options?.negative) doc.setTextColor(190, 45, 45);
  else if (options?.positive) doc.setTextColor(25, 130, 75);
  else doc.setTextColor(35, 35, 35);

  doc.setFont("helvetica", options?.bold ? "bold" : "normal");
  doc.text(label, 20, y);
  doc.text(value, 188, y, { align: "right" });
  doc.setDrawColor(225, 228, 235);
  doc.line(20, y + 4, 188, y + 4);
}

// GET /api/export/payslip/[userId]?month=9&year=2026
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ userId: string }> }
): Promise<NextResponse> {
  try {
    const authUser = await requireAuth(request);
    if (authUser instanceof NextResponse) {
      return authUser;
    }

    const { userId } = await params;
    const { searchParams } = new URL(request.url);
    const month = Number.parseInt(
      searchParams.get("month") || String(new Date().getMonth() + 1),
      10
    );
    const year = Number.parseInt(
      searchParams.get("year") || String(new Date().getFullYear()),
      10
    );

    if (!userId || month < 1 || month > 12 || year < 2000 || year > 2100) {
      return NextResponse.json(
        { success: false, error: "Invalid payslip request", code: "VALIDATION_ERROR" },
        { status: 400 }
      );
    }

    const isAdmin = authUser.role === "admin";
    if (userId !== authUser.userId && !isAdmin) {
      return NextResponse.json(
        {
          success: false,
          error: "You can only download your own payslip",
          code: "FORBIDDEN",
        },
        { status: 403 }
      );
    }

    await connectDB();

    const [employee, payroll] = await Promise.all([
      User.findById(userId).select("name employeeId").lean(),
      Payroll.findOne({ userId, month, year }).lean(),
    ]);

    if (!employee) {
      return NextResponse.json(
        { success: false, error: "Employee not found", code: "NOT_FOUND" },
        { status: 404 }
      );
    }

    if (!payroll) {
      return NextResponse.json(
        {
          success: false,
          error: "No payslip has been generated for this month",
          code: "NOT_FOUND",
        },
        { status: 404 }
      );
    }

    // Employees only receive published/finalized payslips. Admin can still
    // preview a draft from the payroll console if needed.
    if (!isAdmin && payroll.status !== "finalized") {
      return NextResponse.json(
        {
          success: false,
          error: "This payslip has not been finalized by HR yet",
          code: "NOT_FINALIZED",
        },
        { status: 409 }
      );
    }

    const monthName = new Date(year, month - 1).toLocaleString("en-US", {
      month: "long",
    });

    // Use jsPDF directly instead of the autoTable plugin. This removes the
    // plugin integration that can fail in Next.js server routes and keeps the
    // download path lightweight and deterministic.
    const doc = new jsPDF();
    const payrollData = payroll as any;
    const employeeData = employee as any;

    doc.setFont("helvetica", "bold");
    doc.setFontSize(21);
    doc.setTextColor(84, 55, 190);
    doc.text("AttendEase", 20, 20);

    doc.setFont("helvetica", "normal");
    doc.setFontSize(11);
    doc.setTextColor(95, 100, 115);
    doc.text("Employee Payslip", 20, 29);

    doc.setFillColor(247, 247, 252);
    doc.roundedRect(20, 38, 168, 35, 3, 3, "F");
    doc.setTextColor(35, 35, 35);
    doc.setFontSize(10);
    doc.text(`Employee: ${employeeData.name || "Employee"}`, 27, 49);
    doc.text(`Employee ID: ${employeeData.employeeId || "N/A"}`, 27, 58);
    doc.text(`Pay period: ${monthName} ${year}`, 27, 67);
    doc.text(`Status: ${String(payrollData.status || "draft").toUpperCase()}`, 125, 49);
    doc.text(`Generated: ${new Date().toLocaleDateString("en-SG")}`, 125, 58);

    doc.setFont("helvetica", "bold");
    doc.setFontSize(12);
    doc.setTextColor(35, 35, 35);
    doc.text("Salary Summary", 20, 88);
    doc.setFontSize(10);

    let y = 100;
    drawMoneyRow(doc, "Basic Salary", money(payrollData.basicSalary), y);
    y += 12;
    drawMoneyRow(doc, "Present Days", String(payrollData.presentDays ?? 0), y);
    y += 12;
    drawMoneyRow(doc, "Bonus", `+${money(payrollData.bonuses)}`, y, { positive: true });
    y += 12;
    drawMoneyRow(doc, "Absent Deduction", `-${money(payrollData.absentDeduction)}`, y, { negative: true });
    y += 12;
    drawMoneyRow(doc, "Late Deduction", `-${money(payrollData.lateDeduction)}`, y, { negative: true });
    y += 12;
    drawMoneyRow(
      doc,
      "Unpaid Leave Deduction",
      `-${money(payrollData.unpaidLeaveDeduction)}`,
      y,
      { negative: true }
    );

    y += 18;
    doc.setFillColor(84, 55, 190);
    doc.roundedRect(20, y - 8, 168, 20, 3, 3, "F");
    doc.setFont("helvetica", "bold");
    doc.setFontSize(12);
    doc.setTextColor(255, 255, 255);
    doc.text("Net Salary", 27, y + 4);
    doc.text(money(payrollData.netSalary), 181, y + 4, { align: "right" });

    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.setTextColor(130, 135, 145);
    doc.text(
      "This is a computer-generated payslip and does not require a signature.",
      20,
      276
    );
    doc.text("For queries, please contact HR.", 20, 282);

    const pdfBytes = new Uint8Array(doc.output("arraybuffer"));
    const safeEmployeeId = String(employeeData.employeeId || "employee").replace(
      /[^a-zA-Z0-9_-]/g,
      "-"
    );

    return new NextResponse(pdfBytes, {
      status: 200,
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="payslip-${safeEmployeeId}-${monthName.toLowerCase()}-${year}.pdf"`,
        "Cache-Control": "private, no-store",
      },
    });
  } catch (error) {
    console.error("Export payslip error:", error);
    return NextResponse.json(
      {
        success: false,
        error: "Payslip download is temporarily unavailable",
        code: "SERVER_ERROR",
      },
      { status: 500 }
    );
  }
}
