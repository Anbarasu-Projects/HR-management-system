import { NextRequest, NextResponse } from "next/server";
import connectDB from "@/lib/db";
import { requireAuth } from "@/lib/middleware-helpers";
import Attendance from "@/models/Attendance";
import { ApiResponse } from "@/types";

interface AttendanceRecord {
  _id: string;
  userId: {
    _id: string;
    name: string;
    email: string;
    department: string;
  };
  date: string;
  checkIn: Date;
  checkOut: Date | null;
  status: "present" | "absent" | "late";
  hoursWorked: number;
  notes: string;
}

interface AttendanceResponse {
  records: AttendanceRecord[];
  total: number;
  page: number;
  totalPages: number;
}

export async function GET(
  request: NextRequest
): Promise<NextResponse<ApiResponse<AttendanceResponse>>> {
  try {
    const user = await requireAuth(request);
    if (user instanceof NextResponse) {
      return user;
    }

    await connectDB();

    const { searchParams } = new URL(request.url);
    const month = searchParams.get("month");
    const page = parseInt(searchParams.get("page") || "1", 10);
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get("limit") || "30", 10)));
    const includeTotal = searchParams.get("includeTotal") !== "false";

    const query: Record<string, unknown> = {};

    if (user.role === "employee") {
      query.userId = user.userId;
    }

    if (month) {
      const startDate = `${month}-01`;
      const [year, monthNum] = month.split("-").map(Number);
      const lastDay = new Date(year, monthNum, 0).getDate();
      const endDate = `${month}-${lastDay.toString().padStart(2, "0")}`;
      query.date = { $gte: startDate, $lte: endDate };
    }

    const skip = (page - 1) * limit;

    let recordsQuery = Attendance.find(query)
      .sort({ date: -1 })
      .skip(skip)
      .limit(limit);

    // Employee dashboard rows never display another user's profile, so avoid
    // an unnecessary populate query. Admin attendance screens still receive
    // the populated user information they need.
    if (user.role !== "employee") {
      recordsQuery = recordsQuery.populate("userId", "name email department");
    }

    const recordsPromise = recordsQuery.lean();
    const [records, total] = includeTotal
      ? await Promise.all([recordsPromise, Attendance.countDocuments(query)])
      : [await recordsPromise, 0];

    const totalPages = includeTotal ? Math.ceil(total / limit) : 0;

    return NextResponse.json<ApiResponse<AttendanceResponse>>(
      {
        success: true,
        data: {
          records: records as unknown as AttendanceRecord[],
          total,
          page,
          totalPages,
        },
      },
      {
        status: 200,
        headers: {
          "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
          Vary: "Cookie",
        },
      }
    );
  } catch (error) {
    console.error("Fetch attendance error:", error);
    return NextResponse.json<ApiResponse<never>>(
      {
        success: false,
        error: "Internal server error",
      },
      { status: 500 }
    );
  }
}
