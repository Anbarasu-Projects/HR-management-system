import { NextRequest, NextResponse } from "next/server";
import connectDB from "@/lib/db";
import { requireAuth } from "@/lib/middleware-helpers";
import { getAppDateString, getAppTimeMinutes } from "@/lib/app-time";
import Attendance from "@/models/Attendance";
import User from "@/models/User";
import { ApiResponse, CheckOutRequestBody } from "@/types";

function ensureSessions(record: any) {
  if (!Array.isArray(record.sessions)) record.sessions = [];
  if (record.sessions.length === 0 && record.checkIn) {
    record.sessions.push({
      checkIn: record.checkIn,
      checkOut: record.checkOut || null,
      workingMinutes: Number(record.workingMinutes || 0),
      hoursWorked: Number(record.hoursWorked || 0),
      notes: record.notes || "",
      location: record.location || { lat: null, lng: null },
    });
  }
  return record.sessions;
}


async function findTodayRecordWithLegacyDateFix(userId: string, now: Date, todayStr: string) {
  let record: any = await Attendance.findOne({ userId, date: todayStr });
  if (record) return record;

  const oldUtcDate = now.toISOString().slice(0, 10);
  if (oldUtcDate !== todayStr) {
    const legacy: any = await Attendance.findOne({ userId, date: oldUtcDate }).sort({ updatedAt: -1 });
    const referenceTime = legacy?.checkIn || legacy?.createdAt;
    if (legacy && referenceTime && getAppDateString(new Date(referenceTime)) === todayStr) {
      legacy.date = todayStr;
      await legacy.save();
      record = legacy;
    }
  }
  return record;
}

export async function POST(
  request: NextRequest
): Promise<NextResponse<ApiResponse<unknown>>> {
  try {
    const user = await requireAuth(request);
    if (user instanceof NextResponse) return user;

    await connectDB();

    const now = new Date();
    const todayStr = getAppDateString(now);
    const record: any = await findTodayRecordWithLegacyDateFix(
      user.userId,
      now,
      todayStr
    );

    if (!record || !record.checkIn) {
      return NextResponse.json<ApiResponse<never>>(
        { success: false, error: "No active check-in found for today", code: "NO_CHECKIN" },
        { status: 400 }
      );
    }

    const sessions = ensureSessions(record);
    const currentSession = sessions[sessions.length - 1];
    if (!currentSession || currentSession.checkOut) {
      return NextResponse.json<ApiResponse<never>>(
        { success: false, error: "You are not currently checked in. You can start a new session.", code: "NO_ACTIVE_SESSION" },
        { status: 400 }
      );
    }

    const sessionStart = new Date(currentSession.checkIn);
    const sessionMs = Math.max(0, now.getTime() - sessionStart.getTime());
    const sessionMinutes = Math.floor(sessionMs / 60000);
    const sessionHours = Number((sessionMinutes / 60).toFixed(2));

    currentSession.checkOut = now;
    currentSession.workingMinutes = sessionMinutes;
    currentSession.hoursWorked = sessionHours;

    let body: CheckOutRequestBody = {};
    try { body = await request.json(); } catch { /* empty body is fine */ }
    if (body.notes) {
      currentSession.notes = currentSession.notes
        ? `${currentSession.notes} | ${body.notes}`
        : body.notes;
      record.notes = record.notes ? `${record.notes} | ${body.notes}` : body.notes;
    }

    const totalMinutes = sessions.reduce(
      (sum: number, session: any) => sum + Number(session.workingMinutes || 0),
      0
    );
    const totalHours = Number((totalMinutes / 60).toFixed(2));

    record.checkOut = now;
    record.workingMinutes = totalMinutes;
    record.hoursWorked = totalHours;

    // Recalculate the DAILY status from the first check-in and cumulative work.
    // A second session can therefore move a short "half-day" into a full day.
    const statusBeforeCheckout = record.status;
    let isHalfDay = false;
    let shiftFound = false;
    let wasLate = record.status === "late";
    try {
      const userDoc: any = await User.findById(user.userId).populate("shift");
      if (userDoc?.shift) {
        shiftFound = true;
        const shift = userDoc.shift as any;
        const halfDayThreshold = (Number(shift.workingHours || 0) * 60) / 2;
        isHalfDay = halfDayThreshold > 0 && totalMinutes < halfDayThreshold;

        if (shift.startTime && record.checkIn) {
          const [shiftHour, shiftMinute] = String(shift.startTime).split(":").map(Number);
          const firstCheckInMinutes = getAppTimeMinutes(new Date(record.checkIn));
          wasLate = firstCheckInMinutes - (shiftHour * 60 + shiftMinute) > (shift.lateThresholdMinutes || 15);
        }
      }
    } catch (error) {
      console.error("Shift lookup warning in check-out:", error);
    }

    record.status = wasLate
      ? "late"
      : shiftFound
        ? (isHalfDay ? "half-day" : "present")
        : statusBeforeCheckout === "half-day"
          ? "half-day"
          : "present";
    await record.save();

    return NextResponse.json<ApiResponse<unknown>>(
      {
        success: true,
        message: `Session saved. ${totalHours.toFixed(2)}h worked today. You can check in again when ready.`,
        data: {
          _id: record._id,
          date: record.date,
          checkIn: record.checkIn,
          checkOut: record.checkOut,
          hoursWorked: record.hoursWorked,
          workingMinutes: record.workingMinutes,
          sessionHours,
          sessionMinutes,
          sessionCount: sessions.length,
          status: record.status,
          isHalfDay,
          canCheckInAgain: true,
        },
      },
      { status: 200 }
    );
  } catch (error) {
    console.error("Check-out error:", error);
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: "Internal server error", code: "SERVER_ERROR" },
      { status: 500 }
    );
  }
}
