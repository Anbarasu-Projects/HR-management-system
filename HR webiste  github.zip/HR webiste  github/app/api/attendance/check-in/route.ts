import { NextRequest, NextResponse } from "next/server";
import connectDB from "@/lib/db";
import { requireAuth } from "@/lib/middleware-helpers";
import { getAppDateString, getAppTimeMinutes } from "@/lib/app-time";
import Attendance from "@/models/Attendance";
import User from "@/models/User";
import { ApiResponse, CheckInRequestBody } from "@/types";

function legacySession(record: any) {
  if (!record.checkIn) return null;
  const minutes = Number(record.workingMinutes || 0);
  return {
    checkIn: record.checkIn,
    checkOut: record.checkOut || null,
    workingMinutes: minutes,
    hoursWorked: Number(record.hoursWorked || (minutes / 60) || 0),
    notes: record.notes || "",
    location: record.location || { lat: null, lng: null },
  };
}

function ensureSessions(record: any) {
  if (!Array.isArray(record.sessions)) record.sessions = [];
  if (record.sessions.length === 0) {
    const legacy = legacySession(record);
    if (legacy) record.sessions.push(legacy);
  }
  return record.sessions;
}

function activeSession(record: any) {
  const sessions = ensureSessions(record);
  const last = sessions[sessions.length - 1];
  return last && !last.checkOut ? last : null;
}


async function findTodayRecordWithLegacyDateFix(userId: string, now: Date, todayStr: string) {
  let record: any = await Attendance.findOne({ userId, date: todayStr });
  if (record) return record;

  // V13 and earlier used UTC dates. In Singapore, work recorded between
  // midnight and 07:59 could therefore be saved under the previous date.
  // Correct only a record whose actual check-in/creation belongs to today.
  const oldUtcDate = now.toISOString().slice(0, 10);
  if (oldUtcDate !== todayStr) {
    const legacy: any = await Attendance.findOne({ userId, date: oldUtcDate }).sort({ updatedAt: -1 });
    const referenceTime = legacy?.checkIn || legacy?.createdAt;
    if (legacy && referenceTime && getAppDateString(new Date(referenceTime)) === todayStr) {
      legacy.date = todayStr;
      await legacy.save();
      record = legacy;
    }
  }
  return record;
}

function cumulativeMinutes(record: any) {
  return ensureSessions(record).reduce(
    (sum: number, session: any) => sum + Number(session.workingMinutes || 0),
    0
  );
}

export async function POST(
  request: NextRequest
): Promise<NextResponse<ApiResponse<unknown>>> {
  try {
    const user = await requireAuth(request);
    if (user instanceof NextResponse) return user;

    await connectDB();

    const now = new Date();
    const todayStr = getAppDateString(now);
    let body: CheckInRequestBody = {};
    try { body = await request.json(); } catch { /* empty body is fine */ }

    // Close a forgotten active session only when THAT session is older than 12h.
    const danglingRecord: any = await Attendance.findOne({
      userId: user.userId,
      checkOut: null,
      checkIn: { $ne: null },
    }).sort({ date: -1, updatedAt: -1 });

    if (danglingRecord) {
      const active = activeSession(danglingRecord);
      if (active) {
        const start = new Date(active.checkIn);
        const twelveHoursAgo = new Date(now.getTime() - 12 * 60 * 60 * 1000);
        if (start < twelveHoursAgo) {
          const autoCheckOut = new Date(start.getTime() + 12 * 60 * 60 * 1000);
          active.checkOut = autoCheckOut;
          active.workingMinutes = 12 * 60;
          active.hoursWorked = 12;
          active.notes = active.notes
            ? `${active.notes} | Auto-checkout after 12h`
            : "Auto-checkout after 12h";
          danglingRecord.checkOut = autoCheckOut;
          danglingRecord.workingMinutes = cumulativeMinutes(danglingRecord);
          danglingRecord.hoursWorked = Number((danglingRecord.workingMinutes / 60).toFixed(2));
          danglingRecord.notes = danglingRecord.notes
            ? `${danglingRecord.notes} | Auto-checkout after 12h`
            : "Auto-checkout after 12h";
          await danglingRecord.save();
        }
      }
    }

    const existingRecord: any = await findTodayRecordWithLegacyDateFix(
      user.userId,
      now,
      todayStr
    );

    if (existingRecord?.status === "on-leave") {
      return NextResponse.json<ApiResponse<never>>(
        { success: false, error: "You are on approved full-day leave today.", code: "ON_LEAVE" },
        { status: 400 }
      );
    }

    if (existingRecord) {
      // Existing daily record: either start first physical session on a leave
      // marker, reject duplicate active check-in, or append a new work session.
      if (activeSession(existingRecord)) {
        return NextResponse.json<ApiResponse<never>>(
          { success: false, error: "You are already checked in. Check out before starting another session.", code: "ALREADY_CHECKED_IN" },
          { status: 400 }
        );
      }

      const sessions = ensureSessions(existingRecord);
      const isFirstPhysicalSession = !existingRecord.checkIn;
      sessions.push({
        checkIn: now,
        checkOut: null,
        workingMinutes: 0,
        hoursWorked: 0,
        notes: body.notes || "",
        location: body.lat != null && body.lng != null
          ? { lat: body.lat, lng: body.lng }
          : { lat: null, lng: null },
      });

      if (isFirstPhysicalSession) existingRecord.checkIn = now;
      existingRecord.checkOut = null; // active session
      // Preserve a pre-created half-day leave marker on its first physical
      // session. A normal short session may be re-evaluated at checkout.
      if (existingRecord.status !== "late" && !(existingRecord.status === "half-day" && isFirstPhysicalSession)) {
        existingRecord.status = "present";
      }
      if (body.notes) {
        existingRecord.notes = existingRecord.notes
          ? `${existingRecord.notes} | ${body.notes}`
          : body.notes;
      }
      if (body.lat != null && body.lng != null) {
        existingRecord.location = { lat: body.lat, lng: body.lng };
      }
      await existingRecord.save();

      return NextResponse.json<ApiResponse<unknown>>(
        {
          success: true,
          message: sessions.length > 1 ? "Checked in again — previous session remains saved" : "Check-in successful",
          data: {
            _id: existingRecord._id,
            date: existingRecord.date,
            checkIn: now,
            status: existingRecord.status,
            isLate: existingRecord.status === "late",
            sessionNumber: sessions.length,
          },
        },
        { status: 200 }
      );
    }

    // Determine lateness only for the first check-in of the day.
    let isLate = false;
    try {
      const userDoc: any = await User.findById(user.userId).populate("shift").exec();
      if (userDoc?.shift && typeof userDoc.shift === "object" && userDoc.shift.startTime) {
        const [shiftHour, shiftMinute] = String(userDoc.shift.startTime).split(":").map(Number);
        const shiftStartMinutes = shiftHour * 60 + shiftMinute;
        const minutesLate = getAppTimeMinutes(now) - shiftStartMinutes;
        isLate = minutesLate > (userDoc.shift.lateThresholdMinutes || 15);
      }
    } catch (error) {
      console.error("Shift lookup warning in check-in:", error);
    }

    const location = body.lat != null && body.lng != null
      ? { lat: body.lat, lng: body.lng }
      : { lat: null, lng: null };

    const attendance: any = await Attendance.create({
      userId: user.userId,
      date: todayStr,
      checkIn: now,
      checkOut: null,
      status: isLate ? "late" : "present",
      notes: body.notes || "",
      location,
      sessions: [{
        checkIn: now,
        checkOut: null,
        workingMinutes: 0,
        hoursWorked: 0,
        notes: body.notes || "",
        location,
      }],
    });

    return NextResponse.json<ApiResponse<unknown>>(
      {
        success: true,
        message: isLate ? "Check-in recorded (Late)" : "Check-in successful",
        data: {
          _id: attendance._id,
          date: attendance.date,
          checkIn: attendance.checkIn,
          status: attendance.status,
          isLate,
          sessionNumber: 1,
        },
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("Check-in error:", error);
    if (error instanceof Error && error.message.includes("Cast to ObjectId failed")) {
      return NextResponse.json<ApiResponse<never>>(
        { success: false, error: "Your profile has outdated Shift/Department data. Please contact admin.", code: "LEGACY_DATA_ERROR" },
        { status: 400 }
      );
    }
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: "Internal server error", code: "SERVER_ERROR" },
      { status: 500 }
    );
  }
}
