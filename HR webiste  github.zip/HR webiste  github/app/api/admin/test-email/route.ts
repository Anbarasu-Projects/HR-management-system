import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/middleware-helpers";
import {
  sendEmail,
  emailTemplates,
  getEmailStatus,
  verifyEmailTransport,
} from "@/lib/email";
import { ApiResponse, JWTPayload } from "@/types";

// GET /api/admin/test-email - Safely report server-side SMTP status.
export async function GET(request: NextRequest) {
  const authResult = await requireAdmin(request);
  if (authResult instanceof NextResponse) return authResult;

  const status = getEmailStatus();
  return NextResponse.json(
    { success: true, data: status },
    { headers: { "Cache-Control": "no-store" } }
  );
}

// POST /api/admin/test-email - Verify SMTP and send a test email to admin.
export async function POST(
  request: NextRequest
): Promise<NextResponse<ApiResponse<null>>> {
  try {
    const authResult = await requireAdmin(request);
    if (authResult instanceof NextResponse) return authResult;

    const status = getEmailStatus();
    if (!status.configured) {
      return NextResponse.json(
        {
          success: false,
          error: `SMTP is not configured. Add ${status.missing.join(", ")} to .env.local and restart the app.`,
          code: "SMTP_NOT_CONFIGURED",
        },
        { status: 400 }
      );
    }

    const body = await request.json().catch(() => ({}));
    const adminEmail = body.email || (authResult as unknown as JWTPayload).email;

    if (!adminEmail) {
      return NextResponse.json(
        { success: false, error: "No email address available", code: "NO_EMAIL" },
        { status: 400 }
      );
    }

    const verification = await verifyEmailTransport();
    if (!verification.success) {
      return NextResponse.json(
        {
          success: false,
          error: `SMTP connection failed: ${verification.error || "Check your host, port, username and App Password."}`,
          code: "SMTP_CONNECTION_FAILED",
        },
        { status: 502 }
      );
    }

    const template = emailTemplates.welcome("Admin");
    const sent = await sendEmail({
      to: adminEmail,
      subject: `[TEST] ${template.subject}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #1e3a5f;">AttendEase Email Test</h2>
          <p>This is a test email from your AttendEase system.</p>
          <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 20px 0;" />
          ${template.html}
          <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 20px 0;" />
          <p style="color: #64748b; font-size: 12px;">
            If you received this email, your SMTP configuration is working correctly.
          </p>
        </div>
      `,
    });

    if (!sent) {
      return NextResponse.json(
        {
          success: false,
          error: "SMTP connected, but the test message could not be sent.",
          code: "EMAIL_FAILED",
        },
        { status: 502 }
      );
    }

    return NextResponse.json(
      { success: true, message: `Test email sent to ${adminEmail}`, data: null },
      { status: 200 }
    );
  } catch (error) {
    console.error("Test email error:", error);
    return NextResponse.json(
      { success: false, error: "Failed to send test email", code: "SERVER_ERROR" },
      { status: 500 }
    );
  }
}
