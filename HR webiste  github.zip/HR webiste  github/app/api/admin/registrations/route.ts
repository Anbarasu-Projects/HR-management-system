import { NextRequest, NextResponse } from "next/server";
import connectDB from "@/lib/db";
import { requireAdmin } from "@/lib/middleware-helpers";
import User from "@/models/User";
import "@/models/Department";

// GET /api/admin/registrations - pending employee self-registration requests
export async function GET(request: NextRequest) {
  try {
    const admin = await requireAdmin(request);
    if (admin instanceof NextResponse) return admin;

    await connectDB();

    const registrations = await User.find({
      role: "employee",
      approvalStatus: "pending",
    })
      .select("name email department approvalStatus approvalRequestedAt createdAt")
      .populate("department", "name")
      .sort({ approvalRequestedAt: -1, createdAt: -1 })
      .lean();

    return NextResponse.json({
      success: true,
      data: registrations,
      count: registrations.length,
    });
  } catch (error) {
    console.error("Pending registrations error:", error);
    return NextResponse.json(
      { success: false, error: "Failed to load registration requests" },
      { status: 500 }
    );
  }
}
