import { NextRequest, NextResponse } from "next/server";
import connectDB from "@/lib/db";
import { requireAdmin } from "@/lib/middleware-helpers";
import { createNotification } from "@/lib/notifications";
import { emailTemplates, sendEmail } from "@/lib/email";
import User from "@/models/User";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const admin = await requireAdmin(request);
    if (admin instanceof NextResponse) return admin;

    await connectDB();
    const { id } = await params;

    const applicant = await User.findOne({ _id: id, role: "employee" });
    if (!applicant) {
      return NextResponse.json({ success: false, error: "Registration request not found" }, { status: 404 });
    }

    if (applicant.approvalStatus !== "pending") {
      return NextResponse.json(
        { success: false, error: `This registration is already ${applicant.approvalStatus || "approved"}.` },
        { status: 409 }
      );
    }

    applicant.approvalStatus = "rejected";
    applicant.isActive = false;
    applicant.approvalReviewedAt = new Date();
    applicant.approvalReviewedBy = admin.userId as any;
    await applicant.save();

    await createNotification({
      userId: applicant._id,
      title: "Registration not approved",
      message: "Your registration request was not approved. Please contact the administrator if you need more information. You may submit a new registration request later.",
      type: "error",
      dedupeKey: `registration:${applicant._id}:rejected`,
    });

    const rejectionEmail = emailTemplates.accountRejected(applicant.name);
    await sendEmail({
      to: applicant.email,
      subject: rejectionEmail.subject,
      text: rejectionEmail.text,
      html: rejectionEmail.html,
    });

    return NextResponse.json({
      success: true,
      message: `${applicant.name}'s registration was rejected`,
      data: { id: applicant._id.toString(), approvalStatus: applicant.approvalStatus },
    });
  } catch (error) {
    console.error("Reject registration error:", error);
    return NextResponse.json({ success: false, error: "Failed to reject registration" }, { status: 500 });
  }
}
