import { NextRequest, NextResponse } from "next/server";
import connectDB from "@/lib/db";
import { requireAdmin } from "@/lib/middleware-helpers";
import { createNotification } from "@/lib/notifications";
import { emailTemplates, sendEmail } from "@/lib/email";
import User from "@/models/User";

async function generateEmployeeId(): Promise<string> {
  const users = await User.find({ employeeId: { $regex: /^EMP-\d+$/i } })
    .select("employeeId")
    .lean();

  const maxNumber = users.reduce((max: number, user: any) => {
    const match = String(user.employeeId || "").match(/EMP-(\d+)/i);
    return match ? Math.max(max, Number(match[1])) : max;
  }, 0);

  let nextNumber = maxNumber + 1;
  let candidate = `EMP-${String(nextNumber).padStart(3, "0")}`;
  while (await User.exists({ employeeId: candidate })) {
    nextNumber += 1;
    candidate = `EMP-${String(nextNumber).padStart(3, "0")}`;
  }
  return candidate;
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const admin = await requireAdmin(request);
    if (admin instanceof NextResponse) return admin;

    await connectDB();
    const { id } = await params;

    const applicant = await User.findOne({ _id: id, role: "employee" });
    if (!applicant) {
      return NextResponse.json({ success: false, error: "Registration request not found" }, { status: 404 });
    }

    if (applicant.approvalStatus !== "pending") {
      return NextResponse.json(
        { success: false, error: `This registration is already ${applicant.approvalStatus || "approved"}.` },
        { status: 409 }
      );
    }

    if (!applicant.employeeId) {
      applicant.employeeId = await generateEmployeeId();
    }
    applicant.approvalStatus = "approved";
    applicant.isActive = true;
    applicant.approvalReviewedAt = new Date();
    applicant.approvalReviewedBy = admin.userId as any;
    if (!applicant.joiningDate) applicant.joiningDate = new Date();
    await applicant.save();

    await createNotification({
      userId: applicant._id,
      title: "Account approved",
      message: `Welcome ${applicant.name}! Your registration has been approved. You can now sign in with your email or Employee ID ${applicant.employeeId}.`,
      type: "success",
      link: "/employee",
      dedupeKey: `registration:${applicant._id}:approved`,
    });

    const approvalEmail = emailTemplates.accountApproved(applicant.name, String(applicant.employeeId));
    await sendEmail({
      to: applicant.email,
      subject: approvalEmail.subject,
      text: approvalEmail.text,
      html: approvalEmail.html,
    });

    return NextResponse.json({
      success: true,
      message: `${applicant.name} has been approved`,
      data: {
        id: applicant._id.toString(),
        name: applicant.name,
        email: applicant.email,
        employeeId: applicant.employeeId,
        approvalStatus: applicant.approvalStatus,
      },
    });
  } catch (error) {
    console.error("Approve registration error:", error);
    return NextResponse.json({ success: false, error: "Failed to approve registration" }, { status: 500 });
  }
}
