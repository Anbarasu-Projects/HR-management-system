import { NextRequest, NextResponse } from "next/server";
import connectDB from "@/lib/db";
import { requireAdmin } from "@/lib/middleware-helpers";
import User from "@/models/User";
import Leave from "@/models/Leave";
import "@/models/Department";

interface BirthdayHighlight {
  _id: string;
  name: string;
  employeeId?: string;
  department: string | null;
  birthday: string;
  nextBirthday: string;
  daysUntil: number;
}

function startOfTodayUtc(): Date {
  const now = new Date();
  return new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
}

function getNextBirthday(birthday: Date, today: Date): Date {
  let next = new Date(
    Date.UTC(today.getUTCFullYear(), birthday.getUTCMonth(), birthday.getUTCDate())
  );

  if (next.getTime() < today.getTime()) {
    next = new Date(
      Date.UTC(today.getUTCFullYear() + 1, birthday.getUTCMonth(), birthday.getUTCDate())
    );
  }

  return next;
}

// GET /api/admin/highlights
// Provides small, fast dashboard highlights: upcoming birthdays and pending leave requests.
export async function GET(request: NextRequest) {
  try {
    const authResult = await requireAdmin(request);
    if (authResult instanceof NextResponse) return authResult;

    await connectDB();

    const today = startOfTodayUtc();
    const birthdayWindowDays = 30;

    const [employeesWithBirthdays, pendingLeaves, pendingLeaveCount] = await Promise.all([
      User.find({
        role: "employee",
        isActive: { $ne: false },
        birthday: { $ne: null },
      })
        .select("name employeeId birthday department")
        .populate("department", "name")
        .lean(),
      Leave.find({ status: "pending" })
        .select("userId leaveType startDate endDate totalDays appliedAt")
        .populate("userId", "name employeeId department")
        .sort({ appliedAt: -1 })
        .limit(8)
        .lean(),
      Leave.countDocuments({ status: "pending" }),
    ]);

    const upcomingBirthdays: BirthdayHighlight[] = employeesWithBirthdays
      .map((employee: any) => {
        const birthday = new Date(employee.birthday);
        const nextBirthday = getNextBirthday(birthday, today);
        const daysUntil = Math.round(
          (nextBirthday.getTime() - today.getTime()) / (1000 * 60 * 60 * 24)
        );

        return {
          _id: String(employee._id),
          name: employee.name,
          employeeId: employee.employeeId,
          department:
            employee.department && typeof employee.department === "object"
              ? employee.department.name
              : null,
          birthday: birthday.toISOString(),
          nextBirthday: nextBirthday.toISOString(),
          daysUntil,
        };
      })
      .filter((employee) => employee.daysUntil <= birthdayWindowDays)
      .sort((a, b) => a.daysUntil - b.daysUntil)
      .slice(0, 8);

    return NextResponse.json({
      success: true,
      data: {
        upcomingBirthdays,
        pendingLeaves,
        pendingLeaveCount,
      },
    });
  } catch (error) {
    console.error("Admin highlights error:", error);
    return NextResponse.json(
      { success: false, error: "Failed to load dashboard highlights" },
      { status: 500 }
    );
  }
}
