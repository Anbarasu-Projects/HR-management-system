import { createHash, randomBytes } from "crypto";
import { NextRequest, NextResponse } from "next/server";
import connectDB from "@/lib/db";
import { getEmailStatus, sendEmail } from "@/lib/email";
import User from "@/models/User";

const GENERIC_MESSAGE =
  "If an active account matches those details, password reset instructions have been prepared.";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const identifier = typeof body.identifier === "string" ? body.identifier.trim() : "";

    if (!identifier) {
      return NextResponse.json(
        { success: false, error: "Enter your email or Employee ID." },
        { status: 400 }
      );
    }

    await connectDB();

    const escapedIdentifier = identifier.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const user = await User.findOne({
      $or: [
        { email: identifier.toLowerCase() },
        { employeeId: { $regex: new RegExp(`^${escapedIdentifier}$`, "i") } },
      ],
      isActive: { $ne: false },
      approvalStatus: { $ne: "rejected" },
    });

    // Always return the same public message so the endpoint does not reveal
    // whether an email/employee ID exists.
    if (!user) {
      return NextResponse.json({ success: true, message: GENERIC_MESSAGE });
    }

    const rawToken = randomBytes(32).toString("hex");
    const hashedToken = createHash("sha256").update(rawToken).digest("hex");
    const expiresAt = new Date(Date.now() + 30 * 60 * 1000);

    await User.updateOne(
      { _id: user._id },
      {
        $set: {
          resetPasswordToken: hashedToken,
          resetPasswordExpires: expiresAt,
        },
      }
    );

    const baseUrl = (process.env.APP_URL || request.nextUrl.origin).replace(/\/$/, "");
    const resetUrl = `${baseUrl}/reset-password?token=${encodeURIComponent(rawToken)}`;

    const smtpStatus = getEmailStatus();
    const emailSent = await sendEmail({
      to: user.email,
      subject: "Reset your AttendEase password",
      text: `Hi ${user.name}, reset your AttendEase password using this link: ${resetUrl}. The link expires in 30 minutes.`,
      html: `
        <div style="font-family:Arial,sans-serif;line-height:1.6;color:#111827">
          <h2>Reset your AttendEase password</h2>
          <p>Hi ${user.name},</p>
          <p>Use the button below to choose a new password. This link expires in 30 minutes.</p>
          <p><a href="${resetUrl}" style="display:inline-block;padding:12px 18px;border-radius:10px;background:#7c5cff;color:#fff;text-decoration:none;font-weight:700">Reset password</a></p>
          <p>If you did not request this, you can ignore this email.</p>
        </div>
      `,
    });

    return NextResponse.json({
      success: true,
      message: emailSent
        ? "If an active account matches those details, a reset link has been sent to its email address."
        : process.env.NODE_ENV !== "production"
          ? smtpStatus.configured
            ? "Reset link created, but email delivery failed. Use the development link below and test SMTP in Admin → Settings."
            : "Reset link created. SMTP is not configured yet, so use the development reset link below."
          : GENERIC_MESSAGE,
      ...(process.env.NODE_ENV !== "production" && !emailSent ? { devResetUrl: resetUrl } : {}),
    });
  } catch (error) {
    console.error("Forgot password error:", error);
    return NextResponse.json(
      { success: false, error: "Unable to prepare a password reset right now." },
      { status: 500 }
    );
  }
}
