import { createHash } from "crypto";
import { NextRequest, NextResponse } from "next/server";
import connectDB from "@/lib/db";
import { hashPassword, normalizePassword } from "@/lib/auth";
import User from "@/models/User";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const token = typeof body.token === "string" ? body.token.trim() : "";
    const password = typeof body.password === "string" ? normalizePassword(body.password) : "";

    if (!token || !password) {
      return NextResponse.json(
        { success: false, error: "Reset token and new password are required." },
        { status: 400 }
      );
    }

    if (password.length < 6) {
      return NextResponse.json(
        { success: false, error: "Password must be at least 6 characters long." },
        { status: 400 }
      );
    }

    await connectDB();

    const hashedToken = createHash("sha256").update(token).digest("hex");
    const user = await User.findOne({
      resetPasswordToken: hashedToken,
      resetPasswordExpires: { $gt: new Date() },
    }).select("+resetPasswordToken +resetPasswordExpires");

    if (!user) {
      return NextResponse.json(
        { success: false, error: "This reset link is invalid or has expired. Request a new one." },
        { status: 400 }
      );
    }

    const newHash = await hashPassword(password);
    await User.updateOne(
      { _id: user._id },
      {
        $set: { password: newHash },
        $unset: { resetPasswordToken: 1, resetPasswordExpires: 1 },
      }
    );

    return NextResponse.json({
      success: true,
      message: "Password updated successfully. You can now sign in with your new password.",
    });
  } catch (error) {
    console.error("Reset password error:", error);
    return NextResponse.json(
      { success: false, error: "Unable to reset the password right now." },
      { status: 500 }
    );
  }
}
