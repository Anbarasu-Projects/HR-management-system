import { NextRequest, NextResponse } from "next/server";
import connectDB from "@/lib/db";
import { getAuthUser } from "@/lib/middleware-helpers";
import User from "@/models/User";
import "@/models/Department";
import { ApiResponse } from "@/types";

export async function GET(
  request: NextRequest
): Promise<NextResponse<ApiResponse<unknown>>> {
  try {
    const authUser = await getAuthUser(request);

    if (!authUser) {
      return NextResponse.json<ApiResponse<never>>(
        { success: false, error: "Authentication required" },
        { status: 401 }
      );
    }

    await connectDB();

    // lean() avoids building a full Mongoose document for this read-only request.
    const user = await User.findById(authUser.userId)
      .select("name email role employeeId salary department leaveBalance createdAt")
      .populate("department", "name")
      .lean<any>();

    if (!user) {
      return NextResponse.json<ApiResponse<never>>(
        { success: false, error: "User not found" },
        { status: 404 }
      );
    }

    const leaveBalance = {
      annual: user.leaveBalance?.annual ?? 20,
      sick: user.leaveBalance?.sick ?? 10,
      casual: user.leaveBalance?.casual ?? 5,
    };

    const balanceNeedsBackfill =
      user.leaveBalance?.annual == null ||
      user.leaveBalance?.sick == null ||
      user.leaveBalance?.casual == null;

    // Older records are upgraded once without slowing every subsequent request.
    if (balanceNeedsBackfill) {
      await User.updateOne({ _id: user._id }, { $set: { leaveBalance } });
    }

    const departmentName =
      user.department && typeof user.department === "object"
        ? user.department.name || null
        : null;
    const departmentId =
      user.department && typeof user.department === "object"
        ? user.department._id?.toString?.() || null
        : null;

    return NextResponse.json<ApiResponse<unknown>>(
      {
        success: true,
        data: {
          _id: user._id,
          name: user.name,
          email: user.email,
          role: user.role,
          employeeId: user.employeeId || null,
          salary: user.salary ?? 0,
          department: departmentName,
          departmentId,
          leaveBalance,
          createdAt: user.createdAt,
        },
      },
      {
        status: 200,
        headers: {
          "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
          Pragma: "no-cache",
          Expires: "0",
          Vary: "Cookie",
        },
      }
    );
  } catch (error) {
    console.error("Get user error:", error);
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: "Internal server error" },
      { status: 500 }
    );
  }
}
