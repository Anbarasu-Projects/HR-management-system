import { NextRequest, NextResponse } from "next/server";
import connectDB from "@/lib/db";
import { hashPassword, normalizePassword } from "@/lib/auth";
import { createNotification } from "@/lib/notifications";
import User from "@/models/User";
import Department from "@/models/Department";
import mongoose from "mongoose";

async function resolveDepartment(department?: string) {
  if (!department) return null;

  if (mongoose.Types.ObjectId.isValid(department)) {
    return department;
  }

  const departmentName = department.trim();
  if (!departmentName) return null;

  const existing = await Department.findOne({ name: departmentName });

  if (existing) return existing._id;
  const created = await Department.create({ name: departmentName });
  return created._id;
}

async function notifyAdmins(userId: string, name: string, email: string) {
  const admins = await User.find({ role: "admin", isActive: { $ne: false } }).select("_id").lean();

  await Promise.all(
    admins.map((admin: any) =>
      createNotification({
        userId: admin._id,
        title: "New registration request",
        message: `${name} (${email}) registered and is waiting for your approval.`,
        type: "warning",
        link: "/admin/employees#pending-registrations",
        dedupeKey: `registration:${userId}:pending`,
      })
    )
  );
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, email, password, department } = body;
    const normalizedPassword = typeof password === "string" ? normalizePassword(password) : "";
    const normalizedEmail = typeof email === "string" ? email.toLowerCase().trim() : "";
    const normalizedName = typeof name === "string" ? name.trim() : "";

    if (!normalizedName || !normalizedEmail || !normalizedPassword) {
      return NextResponse.json(
        { success: false, error: "Name, email, and password are required", code: "VALIDATION_ERROR" },
        { status: 400 }
      );
    }

    if (normalizedPassword.length < 6) {
      return NextResponse.json(
        { success: false, error: "Password must be at least 6 characters long", code: "VALIDATION_ERROR" },
        { status: 400 }
      );
    }

    await connectDB();

    const userCount = await User.countDocuments();
    const hashedPassword = await hashPassword(normalizedPassword);
    const finalDepartmentId = await resolveDepartment(department);

    // Keep the original bootstrap behaviour: the very first account becomes the active admin.
    if (userCount === 0) {
      const firstAdmin = await User.create({
        name: normalizedName,
        email: normalizedEmail,
        password: hashedPassword,
        role: "admin",
        employeeId: "EMP-001",
        department: finalDepartmentId,
        isActive: true,
        approvalStatus: "approved",
        approvalReviewedAt: new Date(),
      });

      return NextResponse.json(
        {
          success: true,
          message: "Admin account created successfully",
          data: {
            user: { id: firstAdmin._id.toString(), name: firstAdmin.name, role: firstAdmin.role },
            requiresApproval: false,
          },
        },
        { status: 201 }
      );
    }

    const existingUser = await User.findOne({ email: normalizedEmail }).select("+password");

    if (existingUser) {
      if (existingUser.approvalStatus === "pending") {
        return NextResponse.json(
          {
            success: false,
            error: "Your registration is already waiting for admin approval.",
            code: "REGISTRATION_PENDING",
          },
          { status: 409 }
        );
      }

      if (existingUser.approvalStatus !== "rejected") {
        return NextResponse.json(
          { success: false, error: "An account with this email already exists.", code: "DUPLICATE_ERROR" },
          { status: 409 }
        );
      }

      // A rejected applicant may submit a fresh request using the same email.
      existingUser.name = normalizedName;
      existingUser.password = hashedPassword;
      existingUser.department = finalDepartmentId;
      existingUser.role = "employee";
      existingUser.isActive = false;
      existingUser.approvalStatus = "pending";
      existingUser.approvalRequestedAt = new Date();
      existingUser.approvalReviewedAt = undefined;
      existingUser.approvalReviewedBy = undefined;
      await existingUser.save();

      await notifyAdmins(existingUser._id.toString(), existingUser.name, existingUser.email);

      return NextResponse.json(
        {
          success: true,
          message: "Registration submitted for admin approval",
          data: {
            user: { id: existingUser._id.toString(), name: existingUser.name, role: existingUser.role },
            requiresApproval: true,
          },
        },
        { status: 201 }
      );
    }

    const newUser = await User.create({
      name: normalizedName,
      email: normalizedEmail,
      password: hashedPassword,
      role: "employee",
      department: finalDepartmentId,
      isActive: false,
      approvalStatus: "pending",
      approvalRequestedAt: new Date(),
      leaveBalance: { annual: 20, sick: 10, casual: 5 },
    });

    await notifyAdmins(newUser._id.toString(), newUser.name, newUser.email);

    return NextResponse.json(
      {
        success: true,
        message: "Registration submitted for admin approval",
        data: {
          user: { id: newUser._id.toString(), name: newUser.name, role: newUser.role },
          requiresApproval: true,
        },
      },
      { status: 201 }
    );
  } catch (error: any) {
    console.error("Registration error:", error);

    if (error?.code === 11000) {
      return NextResponse.json(
        { success: false, error: "An account with this email already exists.", code: "DUPLICATE_ERROR" },
        { status: 409 }
      );
    }

    return NextResponse.json(
      {
        success: false,
        error: error.message || "An unexpected error occurred during registration",
        code: "SERVER_ERROR",
      },
      { status: 500 }
    );
  }
}
