import { NextRequest, NextResponse } from "next/server";
import { cookies } from "next/headers";
import connectDB from "@/lib/db";
import { comparePassword, generateToken, hashPassword, normalizePassword } from "@/lib/auth";
import User from "@/models/User";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, password } = body;
    const identifier = typeof email === "string" ? email.trim() : "";
    const normalizedPassword = typeof password === "string" ? normalizePassword(password) : "";

    // Validate required fields. The login box accepts either email or employee ID.
    if (!identifier || !normalizedPassword) {
      return NextResponse.json(
        { success: false, error: "Email/Employee ID and password are required", code: "VALIDATION_ERROR" },
        { status: 400 }
      );
    }

    // Connect to database
    await connectDB();

    // Find the user by either email or employee ID and include the password hash.
    // Email is normalized so accidental leading/trailing spaces do not break login.
    const normalizedIdentifier = identifier.toLowerCase();
    const escapedIdentifier = identifier.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const user = await User.findOne({
      $or: [
        { email: normalizedIdentifier },
        { employeeId: { $regex: new RegExp(`^${escapedIdentifier}$`, "i") } },
      ],
    }).select("+password");

    if (!user) {
      return NextResponse.json(
        { success: false, error: "Invalid email/employee ID or password", code: "AUTH_ERROR" },
        { status: 401 }
      );
    }

    // Compare password. Older local test data may contain a legacy plain-text value
    // from an early project version; if so, verify it once and migrate it to bcrypt.
    let isPasswordValid = false;
    const storedPassword = typeof user.password === "string" ? user.password : "";
    const looksLikeBcrypt = /^\$2[aby]\$\d{2}\$/.test(storedPassword);

    if (looksLikeBcrypt) {
      isPasswordValid = await comparePassword(normalizedPassword, storedPassword);
    } else if (storedPassword && storedPassword.trim() === normalizedPassword) {
      const migratedHash = await hashPassword(normalizedPassword);
      await User.updateOne({ _id: user._id }, { $set: { password: migratedHash } });
      isPasswordValid = true;
    }

    if (!isPasswordValid) {
      return NextResponse.json(
        { success: false, error: "Invalid email/employee ID or password", code: "AUTH_ERROR" },
        { status: 401 }
      );
    }

    if (user.approvalStatus === "pending") {
      return NextResponse.json(
        {
          success: false,
          error: "Your account is waiting for admin approval. You can sign in after it is approved.",
          code: "ACCOUNT_PENDING",
        },
        { status: 403 }
      );
    }

    if (user.approvalStatus === "rejected") {
      return NextResponse.json(
        {
          success: false,
          error: "Your registration was rejected. Please contact the administrator or submit a new registration request.",
          code: "ACCOUNT_REJECTED",
        },
        { status: 403 }
      );
    }

    if (!user.isActive) {
      return NextResponse.json(
        { success: false, error: "Account is inactive", code: "ACCOUNT_INACTIVE" },
        { status: 403 }
      );
    }

    // Sign JWT token
    const token = generateToken(user._id.toString(), user.email, user.role);

    // Set HTTP-only cookie
    const cookieStore = await cookies();
    cookieStore.set("rbeas_token", token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "strict",
      maxAge: 60 * 60 * 24 * 7, // 7 days
      path: "/",
    });

    // Return user data (without password)
    return NextResponse.json(
      {
        success: true,
        message: "Login successful",
        data: {
          user: {
            id: user._id.toString(),
            name: user.name,
            role: user.role,
          },
          token,
        },
      },
      {
        status: 200,
        headers: {
          "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
          Pragma: "no-cache",
        },
      }
    );
  } catch (error: any) {
    console.error("Login error:", error);

    const isDatabaseConnectionError =
      error?.name === "MongoServerSelectionError" ||
      error?.name === "MongooseServerSelectionError" ||
      /ECONNREFUSED|ENOTFOUND|querySrv|Server selection timed out/i.test(error?.message || "");

    return NextResponse.json(
      {
        success: false,
        error: isDatabaseConnectionError
          ? "Database unavailable. For the included local setup, make sure MongoDB is running on 127.0.0.1:27017, then restart npm run dev."
          : "Internal server error",
        code: isDatabaseConnectionError ? "DATABASE_UNAVAILABLE" : "SERVER_ERROR",
      },
      { status: 500 }
    );
  }
}
