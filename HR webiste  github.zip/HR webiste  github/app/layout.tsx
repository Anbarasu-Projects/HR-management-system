import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { ToastProvider } from "@/components/ui/neu-toast";
import { SidebarProvider } from "@/lib/SidebarContext";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "AttendEase — HR, Leave & Payroll",
  description:
    "Role-based HR platform for attendance, leave approvals, department calendars and payroll — with separate portals for employees, managers and HR.",
  icons: {
    icon: "/logo.png",
    shortcut: "/logo.png",
    apple: "/logo.png",
  },
};

export const viewport = {
  themeColor: "#070912",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      {/*
        The animated aurora backdrop now lives in globals.css (body::before),
        so no canvas renderer is mounted on data-heavy dashboard screens.
      */}
      <body className="flex min-h-full flex-col">
        <SidebarProvider>
          <ToastProvider>{children}</ToastProvider>
        </SidebarProvider>
      </body>
    </html>
  );
}
