/**
 * Standalone MongoDB connection check.
 *
 *   npx tsx scripts/test-db.ts
 *
 * Reads MONGODB_URI from the environment. No credentials are hardcoded here —
 * put them in .env, which is gitignored.
 */
import "dotenv/config";
import { MongoClient } from "mongodb";

const uri = process.env.MONGODB_URI;

async function testConnection() {
  if (!uri) {
    console.error("❌ MONGODB_URI is not set.");
    console.log("   Copy .env.example to .env and fill in your connection string.");
    process.exit(1);
  }

  console.log("Testing MongoDB connection...");
  console.log("URI:", uri.replace(/:([^:@]+)@/, ":****@")); // never print the password

  const client = new MongoClient(uri, {
    serverSelectionTimeoutMS: 5000,
    family: 4,
  });

  try {
    await client.connect();
    console.log("✅ Connection successful.");

    const db = client.db();
    const collections = await db.listCollections().toArray();
    console.log("Collections:", collections.map((c) => c.name).join(", ") || "(none yet)");
  } catch (err) {
    console.error("❌ Connection failed:", err instanceof Error ? err.message : err);
    console.log("\nThings to check:");
    console.log("1. Your IP is whitelisted in MongoDB Atlas → Network Access");
    console.log("2. The cluster is active and not paused");
    console.log("3. Try a local instance: mongodb://localhost:27017/attendance");
    console.log("4. Firewall or DNS is not blocking the SRV lookup");
    process.exit(1);
  } finally {
    await client.close();
  }
}

testConnection();
