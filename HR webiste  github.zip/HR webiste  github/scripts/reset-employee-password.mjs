import mongoose from "mongoose";
import bcrypt from "bcryptjs";
import dotenv from "dotenv";

// Load the same local environment file used by Next.js.
dotenv.config({ path: ".env.local" });

const [, , rawIdentifier, rawPassword] = process.argv;
const identifier = (rawIdentifier || "").trim();
const password = (rawPassword || "").trim();

if (!identifier || !password) {
  console.error("Usage: npm run reset-password -- <email-or-employee-id> <new-password>");
  process.exit(1);
}

if (password.length < 6) {
  console.error("Password must be at least 6 characters.");
  process.exit(1);
}

const uri = process.env.MONGODB_URI;
if (!uri) {
  console.error("MONGODB_URI is missing from .env.local");
  process.exit(1);
}

try {
  await mongoose.connect(uri, {
    serverSelectionTimeoutMS: 3000,
    family: 4,
  });

  const users = mongoose.connection.collection("users");
  const email = identifier.toLowerCase();
  const escaped = identifier.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const user = await users.findOne({
    $or: [
      { email },
      { employeeId: { $regex: new RegExp(`^${escaped}$`, "i") } },
    ],
  });

  if (!user) {
    console.error(`No employee found for: ${identifier}`);
    process.exitCode = 2;
  } else {
    const hash = await bcrypt.hash(password, 12);
    await users.updateOne(
      { _id: user._id },
      { $set: { password: hash, isActive: true, updatedAt: new Date() } }
    );

    const saved = await users.findOne({ _id: user._id });
    const verified = Boolean(saved?.password && await bcrypt.compare(password, saved.password));

    if (!verified) {
      console.error("Password reset was written but could not be verified.");
      process.exitCode = 3;
    } else {
      console.log(`✅ Password reset verified for ${user.name || identifier}`);
      console.log(`   Email: ${user.email || "N/A"}`);
      console.log(`   Employee ID: ${user.employeeId || "N/A"}`);
      console.log("   Account status: Active");
    }
  }
} catch (error) {
  console.error("Password reset failed:", error instanceof Error ? error.message : error);
  process.exitCode = 4;
} finally {
  await mongoose.disconnect().catch(() => {});
}
