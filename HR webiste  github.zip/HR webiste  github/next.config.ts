import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Hide the Next.js development indicator/badge from the application UI.
  devIndicators: false,

  // Small production-oriented defaults for a cleaner local demo.
  poweredByHeader: false,
  compress: true,
};

export default nextConfig;
