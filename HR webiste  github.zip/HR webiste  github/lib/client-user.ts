"use client";

export interface CurrentUser {
  _id: string;
  name: string;
  email: string;
  role: "admin" | "employee";
  employeeId?: string | null;
  department?: string | null;
  departmentId?: string | null;
  salary?: number;
  leaveBalance?: {
    annual: number;
    sick: number;
    casual: number;
  };
  createdAt?: string;
}

let cachedUser: CurrentUser | null = null;
let cachedAt = 0;
let inflight: Promise<CurrentUser | null> | null = null;
const CACHE_TTL_MS = 5_000;

/**
 * Share the current-user request across header + dashboard components while
 * still forcing the browser to ask the server for the active session.
 *
 * The short in-memory TTL prevents duplicate requests during a single render,
 * but `cache: "no-store"` prevents a previous employee response from being
 * reused after a different employee signs in in the same browser tab.
 */
export function getCurrentUser(force = false): Promise<CurrentUser | null> {
  const cacheIsFresh = cachedUser && Date.now() - cachedAt < CACHE_TTL_MS;
  if (!force && cacheIsFresh) return Promise.resolve(cachedUser);
  if (!force && inflight) return inflight;

  inflight = fetch("/api/auth/me", {
    credentials: "same-origin",
    cache: "no-store",
    headers: { "x-attendease-session-read": String(Date.now()) },
  })
    .then(async (response) => {
      if (!response.ok) {
        cachedUser = null;
        cachedAt = 0;
        return null;
      }
      const data = await response.json();
      if (!data.success || !data.data) {
        cachedUser = null;
        cachedAt = 0;
        return null;
      }
      cachedUser = data.data as CurrentUser;
      cachedAt = Date.now();
      return cachedUser;
    })
    .catch(() => {
      cachedUser = null;
      cachedAt = 0;
      return null;
    })
    .finally(() => {
      inflight = null;
    });

  return inflight;
}

export function clearCurrentUserCache() {
  cachedUser = null;
  cachedAt = 0;
  inflight = null;
}
