import bcrypt from "bcryptjs";
import jwt, { SignOptions } from "jsonwebtoken";
import { JWTPayload } from "@/types";

const JWT_SECRET = process.env.JWT_SECRET;

if (!JWT_SECRET) {
  throw new Error(
    "Please define the JWT_SECRET environment variable inside .env.local"
  );
}

/**
 * Normalize passwords entered through the UI.
 * We only remove accidental whitespace around the password; internal spaces remain valid.
 */
export function normalizePassword(password: string): string {
  return password.trim();
}

/**
 * Hash a password using bcrypt with 12 rounds
 */
export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(normalizePassword(password), 12);
}

/**
 * Compare a plain text password with a hashed password
 */
export async function comparePassword(
  password: string,
  hash: string
): Promise<boolean> {
  return bcrypt.compare(normalizePassword(password), hash);
}

/**
 * Generate a JWT token with 7 days expiry
 */
export function generateToken(userId: string, email: string, role: string): string {
  const payload: JWTPayload = { userId, email, role: role as JWTPayload["role"] };
  const expiresIn = (process.env.JWT_EXPIRES_IN || "7d") as SignOptions["expiresIn"];
  const options: SignOptions = { expiresIn };
  return jwt.sign(payload, JWT_SECRET!, options);
}

/**
 * Verify a JWT token and return the payload
 */
export function verifyToken(token: string): JWTPayload | null {
  try {
    const decoded = jwt.verify(token, JWT_SECRET!) as JWTPayload;
    return decoded;
  } catch {
    return null;
  }
}
