import nodemailer from "nodemailer";
import type { Transporter } from "nodemailer";

interface EmailOptions {
  to: string;
  subject: string;
  html: string;
  text?: string;
}

export interface EmailStatus {
  configured: boolean;
  host: string;
  port: number;
  secure: boolean;
  sender: string;
  missing: string[];
}

type SMTPConfig = EmailStatus & {
  user: string;
  pass: string;
  from: string;
};

let cachedTransporter: Transporter | null = null;
let cachedTransporterKey = "";

function smtpConfig(): SMTPConfig {
  const host = (process.env.SMTP_HOST || "smtp.gmail.com").trim();
  const port = Number.parseInt(process.env.SMTP_PORT || "587", 10) || 587;
  const secure = process.env.SMTP_SECURE
    ? process.env.SMTP_SECURE === "true"
    : port === 465;
  const user = (process.env.SMTP_USER || "").trim();
  let pass = process.env.SMTP_PASS || "";

  // Google displays App Passwords grouped with spaces. People often paste the
  // displayed value directly; Gmail expects the same 16 characters without
  // those formatting spaces.
  if (host.toLowerCase().includes("gmail.com")) {
    pass = pass.replace(/\s+/g, "");
  }

  const from = (process.env.SMTP_FROM || user).trim();
  const missing: string[] = [];
  if (!host) missing.push("SMTP_HOST");
  if (!user) missing.push("SMTP_USER");
  if (!pass) missing.push("SMTP_PASS");

  return {
    configured: missing.length === 0,
    host,
    port,
    secure,
    sender: from || user,
    missing,
    user,
    pass,
    from: from || user,
  };
}

function getTransporter(): Transporter | null {
  const config = smtpConfig();
  if (!config.configured) return null;

  const key = [
    config.host,
    config.port,
    config.secure,
    config.user,
    config.pass,
  ].join("|");

  if (!cachedTransporter || cachedTransporterKey !== key) {
    cachedTransporter = nodemailer.createTransport({
      host: config.host,
      port: config.port,
      secure: config.secure,
      auth: {
        user: config.user,
        pass: config.pass,
      },
      connectionTimeout: 5_000,
      greetingTimeout: 5_000,
      socketTimeout: 8_000,
    });
    cachedTransporterKey = key;
  }

  return cachedTransporter;
}

export function getEmailStatus(): EmailStatus {
  const config = smtpConfig();
  return {
    configured: config.configured,
    host: config.host,
    port: config.port,
    secure: config.secure,
    sender: config.sender,
    missing: config.missing,
  };
}

export async function verifyEmailTransport(): Promise<{
  success: boolean;
  error?: string;
}> {
  const config = smtpConfig();
  if (!config.configured) {
    return {
      success: false,
      error: `Missing ${config.missing.join(", ")}`,
    };
  }

  try {
    const transporter = getTransporter();
    if (!transporter) return { success: false, error: "SMTP is not configured" };
    await transporter.verify();
    return { success: true };
  } catch (error) {
    const message = error instanceof Error ? error.message : "SMTP connection failed";
    console.error("SMTP verify error:", error);
    return { success: false, error: message };
  }
}

export async function sendEmail(options: EmailOptions): Promise<boolean> {
  const config = smtpConfig();
  if (!config.configured) {
    console.warn(`SMTP not configured (${config.missing.join(", ")})`);
    return false;
  }

  try {
    const transporter = getTransporter();
    if (!transporter) return false;

    await transporter.sendMail({
      from: `"AttendEase" <${config.from}>`,
      to: options.to,
      subject: options.subject,
      html: options.html,
      text: options.text,
    });

    return true;
  } catch (error) {
    console.error("Send email error:", error);
    return false;
  }
}

// Email templates
export const emailTemplates = {
  welcome: (name: string) => ({
    subject: "Welcome to AttendEase",
    html: `<h1>Welcome ${name}!</h1><p>Your employee account has been created. You can now log in and start using AttendEase.</p>`,
  }),

  accountApproved: (name: string, employeeId: string) => ({
    subject: "Your AttendEase account has been approved",
    text: `Hi ${name}, your AttendEase registration has been approved. Your Employee ID is ${employeeId}. You can now sign in.`,
    html: `<h2>Account approved ✅</h2><p>Hi ${name},</p><p>Your AttendEase registration has been approved.</p><p><strong>Employee ID: ${employeeId}</strong></p><p>You can now sign in using your email address or Employee ID.</p>`,
  }),

  accountRejected: (name: string) => ({
    subject: "Update on your AttendEase registration",
    text: `Hi ${name}, your AttendEase registration was not approved. Please contact your administrator if you need more information.`,
    html: `<h2>Registration update</h2><p>Hi ${name},</p><p>Your AttendEase registration was not approved. Please contact your administrator if you need more information.</p>`,
  }),

  leaveApproved: (name: string, startDate: string, endDate: string) => ({
    subject: "Leave Request Approved",
    html: `<h1>Hello ${name},</h1><p>Your leave request from ${startDate} to ${endDate} has been <strong>approved</strong>.</p>`,
  }),

  leaveRejected: (name: string, startDate: string, endDate: string) => ({
    subject: "Leave Request Rejected",
    html: `<h1>Hello ${name},</h1><p>Your leave request from ${startDate} to ${endDate} has been <strong>rejected</strong>.</p>`,
  }),

  payrollGenerated: (name: string, month: string, year: number, netSalary: number) => ({
    subject: `Payslip for ${month} ${year}`,
    html: `<h1>Hello ${name},</h1><p>Your payslip for ${month} ${year} is ready.</p><p><strong>Net Salary: $${netSalary.toFixed(2)}</strong></p><p>Log in to view details.</p>`,
  }),

  lateCheckIn: (name: string, date: string, checkInTime: string) => ({
    subject: "Late Check-in Notice",
    html: `<h1>Hello ${name},</h1><p>You checked in at ${checkInTime} on ${date}, which is recorded as late.</p>`,
  }),
};
