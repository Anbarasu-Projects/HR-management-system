import Notification from "@/models/Notification";

export async function createNotification(params: {
  userId: string | any;
  title: string;
  message: string;
  type?: "info" | "success" | "warning" | "error";
  link?: string;
  dedupeKey?: string;
}) {
  try {
    const payload = {
      userId: params.userId,
      title: params.title,
      message: params.message,
      type: params.type || "info",
      link: params.link || null,
      isRead: false,
      ...(params.dedupeKey ? { dedupeKey: params.dedupeKey } : {}),
    };

    if (params.dedupeKey) {
      await Notification.updateOne(
        { userId: params.userId, dedupeKey: params.dedupeKey },
        { $set: payload },
        { upsert: true }
      );
    } else {
      await Notification.create(payload);
    }

    return true;
  } catch (error) {
    console.error("Error creating notification:", error);
    return false;
  }
}
