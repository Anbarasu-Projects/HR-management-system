export const APP_TIME_ZONE = process.env.APP_TIME_ZONE || "Asia/Singapore";

function partsFor(date: Date) {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: APP_TIME_ZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  }).formatToParts(date);

  const map = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  return {
    year: map.year,
    month: map.month,
    day: map.day,
    hour: Number(map.hour || 0),
    minute: Number(map.minute || 0),
  };
}

export function getAppDateString(date = new Date()): string {
  const { year, month, day } = partsFor(date);
  return `${year}-${month}-${day}`;
}

export function getAppTimeMinutes(date = new Date()): number {
  const { hour, minute } = partsFor(date);
  return hour * 60 + minute;
}
